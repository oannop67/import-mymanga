-- MyManga Tracker PRO V11
-- Import this file from the phpMyAdmin root page:
-- http://localhost/phpmyadmin/
-- phpMyAdmin > Import > choose this file > Go
-- The script creates manga_tracker automatically if it does not exist.
-- It does NOT DROP existing tables or existing data.

CREATE DATABASE IF NOT EXISTS `manga_tracker`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `manga_tracker`;
SET NAMES utf8mb4;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `manga` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `alt_title` VARCHAR(255) NULL,
  `cover_url` VARCHAR(1000) NULL,
  `source_url` VARCHAR(1000) NOT NULL,
  `category_id` INT NULL,
  `type_id` INT NULL,
  `current_chapter` VARCHAR(50) NOT NULL DEFAULT '0',
  `last_chapter` VARCHAR(50) NULL,
  `status` ENUM('reading','completed','planned','paused','dropped') NOT NULL DEFAULT 'reading',
  `rating` TINYINT NULL,
  `favorite` TINYINT(1) NOT NULL DEFAULT 0,
  `note` TEXT NULL,
  `last_read_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_m_source` (`source_url`(255)),
  KEY `idx_m_updated` (`updated_at`),
  KEY `idx_m_read` (`last_read_at`),
  KEY `idx_m_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(80) NOT NULL,
  `adult` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_categories_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `genres` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(80) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_genres_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `collections` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(80) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_collections_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `manga_genres` (
  `manga_id` INT NOT NULL,
  `genre_id` INT NOT NULL,
  PRIMARY KEY (`manga_id`,`genre_id`), KEY `idx_mg_genre` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `manga_collections` (
  `manga_id` INT NOT NULL,
  `collection_id` INT NOT NULL,
  PRIMARY KEY (`manga_id`,`collection_id`), KEY `idx_mc_collection` (`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `chapters` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `manga_id` INT NOT NULL,
  `chapter` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NULL,
  `chapter_url` VARCHAR(1000) NOT NULL,
  `release_date` DATE NULL,
  `sort_order` DECIMAL(20,6) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_manga_chapter` (`manga_id`,`chapter`),
  KEY `idx_ch_manga` (`manga_id`),
  KEY `idx_ch_sort` (`manga_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reading_history` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `manga_id` INT NOT NULL,
  `chapter` VARCHAR(50) NOT NULL,
  `source_url` VARCHAR(1000) NULL,
  `detection_method` VARCHAR(30) NOT NULL DEFAULT 'web',
  `read_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hist_manga` (`manga_id`,`read_at`), KEY `idx_hist_time` (`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_settings` (
  `setting_key` VARCHAR(80) NOT NULL,
  `setting_value` TEXT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Safe migrations for older databases.
SET @db='manga_tracker';
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='last_read_at')=0,'ALTER TABLE manga ADD COLUMN last_read_at TIMESTAMP NULL AFTER note','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='favorite')=0,'ALTER TABLE manga ADD COLUMN favorite TINYINT(1) NOT NULL DEFAULT 0 AFTER rating','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='import_status')=0,'ALTER TABLE manga ADD COLUMN import_status VARCHAR(30) NOT NULL DEFAULT ''idle'' AFTER last_read_at','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='import_method')=0,'ALTER TABLE manga ADD COLUMN import_method VARCHAR(30) NULL AFTER import_status','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='import_error')=0,'ALTER TABLE manga ADD COLUMN import_error TEXT NULL AFTER import_method','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='manga' AND COLUMN_NAME='last_import_at')=0,'ALTER TABLE manga ADD COLUMN last_import_at TIMESTAMP NULL AFTER import_error','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='categories' AND COLUMN_NAME='adult')=0,'ALTER TABLE categories ADD COLUMN adult TINYINT(1) NOT NULL DEFAULT 0 AFTER name','SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

INSERT IGNORE INTO categories(name,adult) VALUES
('มังฮวา',0),('มังฮวา 18+',1),('มังงะ',0),('มังงะ 18+',1),('มันฮัว',0),('มันฮัว 18+',1),('นิยาย',0),('นิยาย 18+',1),('เว็บตูน',0),('เว็บตูน 18+',1),('โดจิน',0),('โดจิน 18+',1),('อื่นๆ',0);
INSERT IGNORE INTO genres(name) VALUES
('Action'),('Adventure'),('Comedy'),('Drama'),('Fantasy'),('Romance'),('Harem'),('Historical'),('Horror'),('Isekai'),('Martial Arts'),('Mystery'),('Psychology'),('School Life'),('Sci-Fi'),('Shounen'),('Sports'),('Supernatural'),('System'),('Reincarnation'),('Office'),('NTR'),('Mature'),('Smut'),('Slice of Life'),('Adult'),('Ecchi'),('Josei'),('Seinen');
INSERT IGNORE INTO collections(name) VALUES
('⭐ รายการโปรด'),('🔥 กำลังตาม'),('🎯 อยากอ่าน'),('📦 Archive');
UPDATE manga SET type_id=category_id WHERE (type_id IS NULL OR type_id=0) AND category_id IS NOT NULL;

SET FOREIGN_KEY_CHECKS=1;
