จุดหลักของ V11
- ทดสอบ Local XAMPP ได้ทันทีโดยไม่ต้องแก้ Token ใหม่ทุกครั้ง
- SQL ติดตั้งจาก http://localhost/phpmyadmin/ ระดับหน้าแรกได้
- SQL สร้าง database manga_tracker เองหากยังไม่มี
- ไม่ DROP ตารางหรือข้อมูลเดิม
- รองรับ Browser Import เป็น fallback เมื่อเว็บต้นทางตอบ 403/ต้องใช้ JavaScript
- เก็บสถานะ import_status/import_method/import_error/last_import_at สำหรับตรวจปัญหา
