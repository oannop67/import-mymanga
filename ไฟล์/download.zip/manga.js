// MyManga Tracker PRO v17.6.1 — restored reader script + loading/error states
const API='api/api.php';
const $=id=>document.getElementById(id);try{const perf=localStorage.getItem('manga_performance_mode')==='1';document.documentElement.classList.toggle('mmt-performance-mode',perf);if(perf){const pauseVideos=root=>{if(root?.matches?.('video.cover-motion-video,video.tcg-art-video'))try{root.pause()}catch{};root?.querySelectorAll?.('video.cover-motion-video,video.tcg-art-video').forEach(v=>{try{v.pause()}catch{}})};pauseVideos(document);if('MutationObserver'in window&&document.body){const mo=new MutationObserver(records=>records.forEach(r=>r.addedNodes.forEach(n=>{if(n.nodeType===1)pauseVideos(n)})));mo.observe(document.body,{childList:true,subtree:true})}}}catch{};const mangaId=Number(new URLSearchParams(location.search).get('id')||0);
let manga=null,chapters=[],types=[],genres=[],collections=[],selectedCollections=[];
class ApiError extends Error{constructor(message,status=0,data=null){super(message);this.status=status;this.data=data}}
let tokenPromptPromise=null;
function getStoredToken(){return (localStorage.getItem('manga_token')||'').trim()}
function promptToken(){
  if(tokenPromptPromise)return tokenPromptPromise;
  tokenPromptPromise=new Promise(resolve=>{
    setTimeout(()=>{
      const v=prompt('ใส่ API Token (ค่าเดียวกับ $MANGA_API_TOKEN ใน api/config.php):');
      if(v===null){resolve(null);return}
      const t=v.trim();
      if(t)localStorage.setItem('manga_token',t);
      resolve(t||null);
    },0);
  }).finally(()=>{tokenPromptPromise=null});
  return tokenPromptPromise;
}

// InfinityFree: ถ้าได้หน้าตรวจบอท (aes.js) แทน JSON ให้ให้เบราว์เซอร์ผ่านด่านผ่าน iframe แล้วลองใหม่
let challengePromise=null;
function isHostChallenge(t){return /slowAES|toNumbers\s*\(|__test/.test(t)}
function solveHostChallenge(){
  if(challengePromise)return challengePromise;
  challengePromise=new Promise(resolve=>{
    const f=document.createElement('iframe');
    f.style.cssText='display:none;width:0;height:0;border:0';
    let loads=0,finished=false;
    const done=()=>{if(finished)return;finished=true;try{f.remove()}catch{}resolve()};
    f.onload=()=>{loads++;if(loads>=2)done()};
    setTimeout(done,8000);
    f.src=API+(String(API).includes('?')?'&':'?')+'warm='+Date.now();
    document.body.appendChild(f);
  }).finally(()=>{challengePromise=null});
  return challengePromise;
}
async function api(action,payload={},retry=true,solved=false){
  const token=getStoredToken();let r;
  try{r=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json','X-Manga-Token':token,'Authorization':token?`Bearer ${token}`:''},body:JSON.stringify({action,...payload,token}),cache:'no-store'})}catch{throw new ApiError('เชื่อมต่อ API ไม่ได้',0)}
  let d;const raw=await r.text();try{d=JSON.parse(raw)}catch{if(!solved&&isHostChallenge(raw)){await solveHostChallenge();return api(action,payload,retry,true)}throw new ApiError(`API ตอบกลับไม่ใช่ JSON (HTTP ${r.status}): `+raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,160),r.status)}
  if(!r.ok||!d.ok){
    if(r.status===401&&retry){
      const current=getStoredToken();
      if(current&&current!==token)return api(action,payload,false);
      const t=await promptToken();
      if(t)return api(action,payload,false);
    }
    throw new ApiError(d.message||'เกิดข้อผิดพลาด',r.status,d);
  }
  return d;
}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function ch(v){const m=String(v??'').match(/(\d+(?:\.\d+)?)/);return m?parseFloat(m[1]):0}
function typeIcon(n){return ({'มังฮวา':'🖌','มังฮวา 18+':'🔞','มังงะ':'📕','มังงะ 18+':'🔞','มันฮัว':'🇨🇳','มันฮัว 18+':'🔞','นิยาย':'📚','นิยาย 18+':'🔞','เว็บตูน':'🌐','เว็บตูน 18+':'🔞','โดจิน':'🎨','โดจิน 18+':'🔞','อื่นๆ':'📁'})[n]||'🏷'}
function adult(t){return !!(t?.adult||/18\s*\+/i.test(t?.name||''))}
function statusName(s){return ({reading:'กำลังอ่าน',completed:'อ่านจบแล้ว',planned:'วางแผนอ่าน',paused:'พักการอ่าน',dropped:'เลิกอ่าน'})[s]||s}
function completionStatusName(s){return s==='completed'?'🔵 จบแล้ว':'🟢 ยังไม่จบ'}
const GENRE_TH={
 Action:'แอ็กชัน',Adult:'ผู้ใหญ่',Adventure:'ผจญภัย',Comedy:'ตลก',Drama:'ดราม่า',Ecchi:'เอคจิ',
 Fantasy:'แฟนตาซี',Harem:'ฮาเร็ม',Historical:'ประวัติศาสตร์',Horror:'สยองขวัญ',Isekai:'ต่างโลก',
 Josei:'โชโจวัยผู้ใหญ่','Martial Arts':'ศิลปะการต่อสู้',Mature:'ผู้ใหญ่/เนื้อหาเข้มข้น',Mystery:'ลึกลับ',
 NTR:'นอกใจ/แย่งคู่',Office:'ออฟฟิศ',Psychology:'จิตวิทยา',Reincarnation:'เกิดใหม่',Romance:'โรแมนซ์',
 'School Life':'ชีวิตในโรงเรียน','Sci-Fi':'ไซไฟ',Seinen:'เซเน็น',Shounen:'โชเน็น','Slice of Life':'ชีวิตประจำวัน',
 Smut:'อีโรติก',Sports:'กีฬา',Supernatural:'เหนือธรรมชาติ',System:'ระบบ','Oneshot':'จบในตอนเดียว','Anthology':'รวมเรื่องสั้น','Academy':'สถาบัน/อคาเดมี','Animals':'สัตว์','Boys Love':'ชายรักชาย','Girls Love':'หญิงรักหญิง','Business':'ธุรกิจ','Coming of Age':'การเติบโต','Cooking':'ทำอาหาร','Crime':'อาชญากรรม','Cultivation':'บำเพ็ญเพียร','Cyberpunk':'ไซเบอร์พังก์','Delinquents':'นักเลง','Demons':'ปีศาจ','Dungeon':'ดันเจี้ยน','Family':'ครอบครัว','Gender Bender':'สลับเพศ','Ghosts':'วิญญาณ','Gore':'โหดเลือดสาด','Gyaru':'สาวแกลล','Hentai':'เฮ็นไท','Housewife':'แม่บ้าน','Hunter':'นักล่า','Idol':'ไอดอล','Magic':'เวทมนตร์','Magical Girls':'สาวน้อยเวทมนตร์','Mecha':'หุ่นยนต์','Medical':'การแพทย์','Military':'ทหาร','Monster Girls':'สาวมอนสเตอร์','Monsters':'สัตว์ประหลาด','Music':'ดนตรี','Overpowered':'ตัวเอกเทพ','Palace Intrigue':'ชิงอำนาจในวัง','Post-Apocalyptic':'โลกหลังล่มสลาย','Regression':'ย้อนเวลากลับมาแก้ตัว','Revenge':'แก้แค้น','Romantic Comedy':'โรแมนติกคอมเมดี้','Royalty':'ราชวงศ์','Samurai':'ซามูไร','Shoujo':'โชโจ','Survival':'เอาชีวิตรอด','Thriller':'ระทึกขวัญ','Time Travel':'ย้อนเวลา','Tower Climbing':'ปีนหอคอย','Tragedy':'โศกนาฏกรรม','Vampires':'แวมไพร์','Vanilla':'รักหวาน','Video Games':'เกม','Villainess':'นางร้าย','Wuxia':'กำลังภายใน','Zombies':'ซอมบี้'
};
function genreLabel(n){const s=String(n||'');return GENRE_TH[s]?`${s} - ${GENRE_TH[s]}`:s}
function leadTypeLabel(v){const x=String(v||'').toLowerCase();return ({male:'👨 Male Lead - ตัวเอกชาย',female:'👩 Female Lead - ตัวเอกหญิง',yaoi:'🏳️‍🌈 (Gay) เกย์',gay:'🏳️‍🌈 (Gay) เกย์',lesbian:'🏳️‍🌈 (Lesbian) เลสเบี้ยน'})[x]||'ไม่ระบุ'}
function chapterSortKey(v){const s=String(v??'').trim();let m=s.match(/^(?:SS|Season)\s*(\d+)$/i);if(m)return Number(m[1])*1000000000;m=s.match(/^(\d+)(?:\.(\d+))?(?:\s*(?:SS|Season)\s*(\d+))?$/i);if(m){const season=Number(m[3]||0),major=Number(m[1]),minor=m[2]===undefined?0:Number(m[2]);return season*1000000000+major+minor/1000000}return null}
function compareChapters(a,b){const A=chapterSortKey(a),B=chapterSortKey(b);if(A!==null&&B!==null)return A-B;return String(a??'').localeCompare(String(b??''),undefined,{numeric:true,sensitivity:'base'})}
function pct(){if(!chapters.length)return 0;const ordered=[...chapters].sort((a,b)=>compareChapters(a.chapter,b.chapter));const read=ordered.filter(x=>compareChapters(x.chapter,manga.current_chapter)<=0).length;return Math.min(100,Math.round(read/ordered.length*100))}
function unread(){return chapters.filter(x=>compareChapters(x.chapter,manga.current_chapter)>0).length}
function nextChapter(){return [...chapters].sort((a,b)=>compareChapters(a.chapter,b.chapter)).find(x=>compareChapters(x.chapter,manga.current_chapter)>0)||null}
function linkFor(c){const raw=String(c?.chapter_url||'').trim();if(!raw)throw new Error('Chapter นี้ไม่มี URL ต้นทาง');const u=new URL(raw,manga?.source_url||location.href);if(!['http:','https:'].includes(u.protocol))throw new Error('URL ของ Chapter ไม่ถูกต้อง');u.hash=`mt=1&manga=${encodeURIComponent(manga.id)}&chapter=${encodeURIComponent(c.chapter)}`;return u.toString()}
function toast(msg,error=false){const x=$('toast');x.textContent=msg;x.style.background=error?'#b91c1c':'#111820';x.classList.add('show');clearTimeout(window.__t);window.__t=setTimeout(()=>x.classList.remove('show'),3200)}
function applyTheme(t){t=t==='light'?'light':'dark';document.documentElement.dataset.theme=t;localStorage.setItem('manga_theme',t);const b=$('themeBtn');if(b){b.textContent=t==='light'?'☀':'☾';b.setAttribute('aria-label',t==='light'?'สลับเป็นโหมดมืด':'สลับเป็นโหมดสว่าง');b.title=t==='light'?'สลับเป็นโหมดมืด':'สลับเป็นโหมดสว่าง'}const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute('content',t==='light'?'#f3f6fa':'#090c11')}
function timeAgo(v){if(!v)return 'ยังไม่มีการอ่าน';const d=new Date(String(v).replace(' ','T'));if(Number.isNaN(d.getTime()))return String(v);const diff=Math.max(0,Date.now()-d.getTime()),m=Math.floor(diff/60000);if(m<1)return 'เมื่อสักครู่';if(m<60)return `${m} นาทีที่แล้ว`;const h=Math.floor(m/60);if(h<24)return `${h} ชั่วโมงที่แล้ว`;return `${Math.floor(h/24)} วันที่แล้ว`}
async function reload({timeoutMs=25000,showLoading=false}={}){
 if(showLoading)renderDetailLoading();
 let timer;
 try{
  const d=await Promise.race([
   api('get_manga',{id:mangaId}),
   new Promise((_,reject)=>{timer=setTimeout(()=>reject(new ApiError('โหลดรายละเอียดเรื่องนานเกินไป อาจเกิดจากอินเทอร์เน็ตหรือ API ตอบช้า กรุณาลองอีกครั้ง',408)),timeoutMs)})
  ]);
  if(!d||!d.manga)throw new ApiError('ไม่พบเรื่องนี้ในคลัง หรือข้อมูลเรื่องยังโหลดไม่สำเร็จ',404,d);
  manga=d.manga;chapters=Array.isArray(d.chapters)?d.chapters:[];types=d.types||d.categories||[];genres=d.genres||[];collections=d.collections||[];selectedCollections=d.collections_selected||[];render();
  return d;
 } finally {if(timer)clearTimeout(timer)}
}
function renderDetailLoading(){
 const root=$('detail');if(!root)return;
 root.innerHTML=`<section class="detail-load-state" role="status" aria-live="polite"><div class="detail-load-head"><span class="detail-load-spinner" aria-hidden="true"></span><div><h2>กำลังโหลดรายละเอียดเรื่อง…</h2><p>กำลังดึงข้อมูลเรื่องและ Chapter จากคลังของคุณ</p></div></div><div class="detail-load-skeleton"><i></i><div><b></b><b></b><b></b><span></span><span></span></div></div><p class="detail-load-foot">หากใช้เวลานาน ระบบจะแสดงสาเหตุและปุ่มลองใหม่ให้อัตโนมัติ</p></section>`;
}
function renderDetailError(message,canRetry=true){
 const root=$('detail');if(!root)return;
 root.innerHTML=`<section class="detail-load-state detail-load-error" role="alert"><div class="detail-error-icon" aria-hidden="true">!</div><h2>ยังเปิดรายละเอียดเรื่องไม่ได้</h2><p>${esc(message||'เกิดข้อผิดพลาดระหว่างโหลดข้อมูล')}</p><div class="detail-load-actions">${canRetry?'<button type="button" class="red btn" id="retryDetailBtn">↻ ลองโหลดอีกครั้ง</button>':''}<a class="btn ghost" href="index.html#library">← กลับไปคลังการ์ตูน</a></div><small>หากลองใหม่แล้วยังไม่ได้ ให้ตรวจการเชื่อมต่ออินเทอร์เน็ตหรือ API ของเว็บไซต์</small></section>`;
 const retry=$('retryDetailBtn');if(retry)retry.onclick=async()=>{retry.disabled=true;renderDetailLoading();try{await reload({timeoutMs:25000})}catch(e){renderDetailError(e.message,true)}};
}
function openNoReferrer(url){try{const target=new URL(String(url||''),location.href);if(!['http:','https:'].includes(target.protocol))return false;const a=document.createElement('a');a.href=target.href;a.target='_blank';a.rel='noopener noreferrer';a.referrerPolicy='no-referrer';a.style.display='none';document.body.appendChild(a);a.click();a.remove();return true}catch{return false}}
async function startRead(c){let url='';try{url=linkFor(c);if(!openNoReferrer(url)){toast('เปิด URL ของ Chapter ไม่สำเร็จ กรุณาตรวจสอบลิงก์ตอนนี้',true);return}}catch(e){toast('URL ของ Chapter ไม่ถูกต้อง',true);return}try{const d=await api('read_chapter',{id:manga.id,chapter:c.chapter,source_url:c.chapter_url,detection_method:'chapter-list'});manga.current_chapter=c.chapter;manga.last_read_at=new Date().toISOString();render()}catch(e){toast(`เปิด Chapter แล้ว แต่บันทึกประวัติการอ่านไม่สำเร็จ: ${e.message}`,true)}}
async function toggleFav(){try{const d=await api('toggle_favorite',{id:manga.id});manga.favorite=d.favorite;render()}catch(e){toast(e.message,true)}}
async function syncNow(){
 let preview;
 const prog=mmtSyncProgress('กำลังเริ่มซิงก์',manga.title);
 prog.step(6,'กำลังเริ่มซิงก์','เตรียมซิงก์');
 prog.creep(58,'กำลังอ่านเว็บต้นทาง','อ่านรายการ Chapter','กำลังตรวจรายการ Chapter จากเว็บต้นทาง');
 try{
  preview=await api('sync_preview',{id:manga.id,force:true});
  prog.step(64,'ตรวจรายการ Chapter','ตรวจความครบถ้วน',`พบ ${preview.chapter_count??0} ตอน${Number(preview.expected_chapters)>0?` จาก ${preview.expected_chapters}`:''}`);
  const labels=(preview.chapters||[]).map(c=>String(c.chapter||''));
  const valid=v=>/^(?:(?:\d+)(?:\.\d+)?(?:\s*(?:SS|Season|Part)\s*\d+)?|(?:SS|Season)\s*\d+)$/i.test(v.trim());
  const current=chapterSortKey(manga.last_chapter||manga.latest_chapter||''),latest=chapterSortKey(preview.last_found||'');
  const suspicious=preview.sync_state!=='complete'||Number(preview.unparsed_chapter_count||0)>0||!!preview.duplicate_chapter_labels||labels.some(v=>!valid(v))||new Set(labels).size!==labels.length||(current!==null&&latest!==null&&current-latest>50);
  let allowPartial=preview.sync_state!=='complete';let preserveExisting=false;
  if(true){ // v17.17.13: ซิงก์เองจากหน้ารายละเอียด แสดงหน้าตรวจสอบก่อนบันทึกทุกครั้ง
   prog.hide();
   const modal=document.createElement('div');modal.className='modal';
   const rows=(preview.chapters||[]).slice(-12).reverse().map(c=>`<div class="sync-review-row"><strong>Chapter ${esc(c.chapter)}</strong><a href="${esc(c.chapter_url||'#')}" target="_blank" rel="noopener">เปิด URL ↗</a></div>`).join('')||'<div class="empty">ไม่พบตอนที่อ่านเลขได้</div>';
   modal.innerHTML=`<div class="modal-box sync-review-box"><div class="modal-head"><div><div class="section-kicker">SYNC REVIEW</div><h2>ตรวจสอบก่อนซิงก์</h2><p class="modal-note">${esc(manga.title)}</p></div><button type="button" class="close-btn" data-review-cancel>×</button></div><div class="review-status review-${esc(preview.sync_state)}"><b>${preview.sync_state==='complete'?'ดึงครบ':preview.sync_state==='partial'?'ดึงไม่ครบ':'ตรวจสอบไม่ได้'}</b><span>${Number(preview.unparsed_chapter_count||0)>0?`อ่านเลข Chapter ไม่ได้ ${preview.unparsed_chapter_count} รายการ`:preview.sync_state==='partial'?`เว็บแจ้ง ${preview.expected_chapters} ตอน แต่พบ ${preview.chapter_count} ตอน`:preview.sync_state==='unverifiable'?'เว็บไม่แจ้งจำนวนตอนทั้งหมด จึงยืนยันความครบถ้วนไม่ได้':(suspicious?'พบเลขตอนซ้ำหรือเลขล่าสุดผิดปกติ':'ตรวจแล้วไม่พบความผิดปกติ — ตรวจรายการก่อนบันทึก')}</span></div><div class="sync-review-stats"><div><small>คาดไว้</small><b>${preview.expected_chapters>0?preview.expected_chapters:'ไม่ระบุ'}</b></div><div><small>พบ</small><b>${preview.chapter_count||0}</b></div><div><small>ขาด</small><b>${preview.missing_chapters===null?'ไม่ทราบ':preview.missing_chapters}</b></div></div><p class="modal-note">ตอนล่าสุดที่พบ: <b>${esc(preview.last_found||'-')}</b> · ล่าสุดในคลัง: <b>${esc(manga.last_chapter||manga.latest_chapter||'-')}</b></p><div class="sync-review-list">${rows}</div><div class="review-safe-note">การบันทึกแบบปลอดภัยจะเพิ่มเฉพาะ Chapter ใหม่ และไม่ลบหรือเขียนทับ Chapter เดิมจากรอบที่ข้อมูลไม่ครบ</div><div class="modal-actions"><button type="button" class="btn ghost" data-review-cancel>ข้ามและเก็บข้อมูลเดิม</button><button type="button" class="red btn" data-review-confirm>บันทึกตอนที่พบแบบปลอดภัย</button></div></div>`;
   document.body.appendChild(modal);
   const approved=await new Promise(resolve=>{let done=false;const finish=v=>{if(done)return;done=true;modal.remove();resolve(v)};modal.querySelectorAll('[data-review-cancel]').forEach(b=>b.onclick=()=>finish(false));modal.querySelector('[data-review-confirm]').onclick=()=>finish(true);modal.onclick=e=>{if(e.target===modal)finish(false)}});
   if(!approved){toast('ข้ามการซิงก์ • เก็บข้อมูลเดิมไว้');return}
   allowPartial=preview.sync_state!=='complete';preserveExisting=suspicious;
  }
  prog.step(74,'กำลังบันทึก Chapter','บันทึกตอนใหม่',`พบ ${preview.chapter_count??0} ตอน`);prog.creep(96);
  const d=await api('sync_manga',{id:manga.id,force:true,allow_partial:allowPartial,preserve_existing:preserveExisting});
  try{const h=JSON.parse(localStorage.getItem('manga_sync_history')||'[]');h.unshift({id:Number(manga.id),title:manga.title,status:d.sync_status||'success',message:d.sync_error||d.sync_state||preview.sync_state,found:preview.chapter_count,expected:preview.expected_chapters,last:d.last_chapter||preview.last_found,at:new Date().toISOString()});localStorage.setItem('manga_sync_history',JSON.stringify(h.slice(0,100)))}catch{}
  const added=Number(d.new_chapters||d.new_chapter_count||0),st=mmtSyncResultState(d.sync_status);
  prog.done(st,st==='partial'?'ซิงก์แล้ว แต่ควรตรวจสอบ':'ซิงก์สำเร็จ',`พบ ${preview.chapter_count??'-'} ตอน · ${added?`เพิ่ม ${added} ตอนใหม่`:'ไม่มีตอนใหม่'}`);await reload();
 }catch(e){try{const h=JSON.parse(localStorage.getItem('manga_sync_history')||'[]');h.unshift({id:Number(mangaId),title:manga?.title||'',status:e.data?.browser_required?'blocked':'error',message:e.message,at:new Date().toISOString()});localStorage.setItem('manga_sync_history',JSON.stringify(h.slice(0,100)))}catch{}prog.done('error',e.data?.browser_required?'เว็บต้นทางบล็อกการดึงข้อมูล':'ซิงก์ไม่สำเร็จ',String(e.message||'').slice(0,180),{canBrowser:!!e.data?.browser_required})}
}
// v17.17.16 — แก้ไขชื่อตอน/ลิงก์ตอน (ตอนที่แก้เองจะถูกล็อก ซิงก์ไม่เขียนทับและไม่ลบ)
function openChapterEdit(c){
 const old=document.getElementById('chapterEditModal');if(old)old.remove();
 const modal=document.createElement('div');modal.className='modal';modal.id='chapterEditModal';
 modal.innerHTML=`<div class="modal-box chapter-edit-box"><div class="modal-head"><div><div class="section-kicker">EDIT CHAPTER</div><h2>แก้ไข Chapter ${esc(c.chapter)}</h2><p class="modal-note">${esc(manga.title)}</p></div><button type="button" class="close-btn" data-ce-close>×</button></div>
  <form id="chapterEditForm"><div class="form-grid"><label>ชื่อตอน<input id="ceTitle" maxlength="255" value="${esc(c.title||'')}" placeholder="เว้นว่างได้"></label>
  <label>ลิงก์ตอน<input id="ceUrl" type="url" required maxlength="1000" value="${esc(c.chapter_url||'')}" placeholder="https://..."></label></div>
  <p class="modal-note chapter-edit-hint">🔒 เลขตอน (Chapter ${esc(c.chapter)}) แก้ไม่ได้ · เมื่อบันทึก ระบบซิงก์จะไม่เขียนทับหรือลบตอนนี้อีก</p>
  <div class="modal-actions"><a class="btn ghost" id="ceOpen" href="${esc(c.chapter_url||'#')}" target="_blank" rel="noopener noreferrer">↗ ทดสอบลิงก์</a><button type="button" class="btn ghost" data-ce-close>ยกเลิก</button><button type="submit" class="red btn" id="ceSave">บันทึก</button></div></form></div>`;
 document.body.appendChild(modal);
 const close=()=>modal.remove();
 modal.onclick=e=>{if(e.target===modal)close()};
 modal.querySelectorAll('[data-ce-close]').forEach(b=>b.onclick=close);
 const url=modal.querySelector('#ceUrl');url.addEventListener('input',()=>{modal.querySelector('#ceOpen').href=url.value||'#'});
 modal.querySelector('#chapterEditForm').onsubmit=async e=>{
  e.preventDefault();const btn=modal.querySelector('#ceSave');btn.disabled=true;
  try{await api('edit_chapter',{id:c.id,title:modal.querySelector('#ceTitle').value.trim(),chapter_url:url.value.trim()});close();toast('บันทึกตอนแล้ว');await reload()}
  catch(err){btn.disabled=false;toast(err.message,true)}
 };
 setTimeout(()=>modal.querySelector('#ceTitle')?.focus(),30);
}
async function deleteChapter(id){if(!confirm('ลบ Chapter นี้หรือไม่?'))return;try{await api('delete_chapter',{id});toast('ลบ Chapter แล้ว');await reload()}catch(e){toast(e.message,true)}}
async function addChapter(e){e.preventDefault();try{await api('add_chapter',{manga_id:manga.id,chapter:$('newChapter').value.trim(),title:$('newChapterTitle').value.trim(),chapter_url:$('newChapterUrl').value.trim(),release_date:$('newChapterDate').value||''});e.target.reset();toast('เพิ่ม Chapter แล้ว');await reload()}catch(e){toast(e.message,true)}}
function mmConfirm({icon='!',kicker='',title='',lead='',items=[],note='',okText='ตกลง',cancelText='ยกเลิก',tone='danger'}){
 return new Promise(res=>{
  const m=document.createElement('div');m.className='modal mm-confirm-modal';
  m.innerHTML=`<div class="modal-box mm-confirm mm-${tone}" role="alertdialog" aria-modal="true"><div class="mm-confirm-icon" aria-hidden="true">${icon}</div>${kicker?`<div class="mm-confirm-kicker">${esc(kicker)}</div>`:''}<h2>${title}</h2>${lead?`<p class="mm-confirm-lead">${lead}</p>`:''}${items.length?`<ul class="mm-confirm-list">${items.map(x=>`<li><i>${x[0]}</i><span>${x[1]}</span></li>`).join('')}</ul>`:''}${note?`<div class="mm-confirm-note">${note}</div>`:''}<div class="mm-confirm-actions"><button type="button" class="btn ghost" data-no>${esc(cancelText)}</button><button type="button" class="btn mm-confirm-ok" data-yes>${esc(okText)}</button></div></div>`;
  const done=v=>{document.removeEventListener('keydown',key);m.remove();res(v)};
  const key=e=>{if(e.key==='Escape')done(false)};
  m.addEventListener('click',e=>{if(e.target===m||e.target.closest('[data-no]'))done(false);else if(e.target.closest('[data-yes]'))done(true)});
  document.addEventListener('keydown',key);document.body.appendChild(m);
  const y=m.querySelector('[data-yes]');if(y)y.focus();
 });
}
async function resetReading(){
 const ok=await mmConfirm({icon:'↺',kicker:'RESET READING',title:'รีเซ็ตการอ่านเรื่องนี้?',lead:`<b>${esc(manga.title||'')}</b>`,
  items:[['🗑','ล้างประวัติการอ่านของเรื่องนี้'],['0','ตอนที่อ่านถึงกลับเป็น <b>0</b>'],['📌','ถ้าสถานะเป็น <b>“กำลังอ่าน”</b> จะเปลี่ยนเป็น <b>“วางแผนอ่าน”</b> และหลุดจากรายการอ่านต่อ']],
  note:'✓ ตอนและลิงก์ของเรื่องยังอยู่ครบ ไม่ถูกลบ',okText:'↺ รีเซ็ตเลย',cancelText:'ยกเลิก',tone:'danger'});
 if(!ok)return;
 try{
  const d=await api('reset_reading',{id:manga.id});
  manga.current_chapter='0';manga.last_read_at=null;if(d.status)manga.status=d.status;
  toast('รีเซ็ตการอ่านแล้ว');render();
 }catch(e){toast(e.message,true)}
}
async function historyShow(){
 try{
  const d=await api('manga_history',{manga_id:manga.id});
  const items=d.items||[];
  const old=document.getElementById('historyModal');if(old)old.remove();
  const fmt=v=>{const t=new Date(String(v||'').replace(' ','T'));return isNaN(t)?'-':t.toLocaleString('th-TH',{dateStyle:'medium',timeStyle:'short'})};
  const methodName=v=>({web:'เว็บ',manual:'กดเอง',bookmarklet:'บุ๊กมาร์ก',extension:'ส่วนเสริม'}[String(v||'web')]||String(v||'เว็บ'));
  const rows=items.map((x,i)=>`<div class="history-row"><span class="history-ch">Chapter ${esc(x.chapter)}</span><small>${esc(methodName(x.detection_method))}</small><span class="history-when">${esc(fmt(x.read_at))}</span></div>`).join('');
  const modal=document.createElement('div');modal.className='modal';modal.id='historyModal';
  modal.innerHTML=`<div class="modal-box history-box"><div class="modal-head"><div><div class="section-kicker">READING HISTORY</div><h2>ประวัติการอ่าน</h2><p class="modal-note">${esc(manga.title||'')} · ${items.length} รายการ</p></div><button type="button" class="close-btn" data-history-close aria-label="ปิด">×</button></div><div class="history-list">${rows||'<div class="empty">ยังไม่มีประวัติการอ่าน เมื่อกด “อ่านต่อ” หรือเปิดตอนจากหน้านี้ ระบบจะบันทึกไว้ที่นี่</div>'}</div>${(items.length||manga.last_read_at||String(manga.current_chapter||'0')!=='0')?'<button type="button" class="history-reset-btn" data-history-reset><i>↺</i><span>รีเซ็ตการอ่านเรื่องนี้</span></button>':''}</div>`;
  const close=()=>modal.remove();
  modal.addEventListener('click',e=>{if(e.target===modal||e.target.closest('[data-history-close]'))close();else if(e.target.closest('[data-history-reset]')){close();resetReading()}});
  document.addEventListener('keydown',function esc2(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',esc2)}});
  document.body.appendChild(modal);
 }catch(e){toast(e.message,true)}
}
async function deleteManga(){try{await api('delete_manga',{id:manga.id});location.href='index.html'}catch(e){toast(e.message,true)}}

/* v17.13 — per-story card theme picker for the detail-page edit modal.
   Same storage key as the library (localStorage 'manga_card_themes'), so the choice shows on the library card. */
const MMT_THEME_GROUPS=[["ชมพู · แดง",[["rose","Rose — ชมพูโรแมนติก"],["sakura","Sakura — ชมพูซากุระ"],["coral","Coral — ส้มปะการัง"],["peach","Peach — พีชนุ่ม"],["crimson","Crimson — แดงเข้ม"],["ruby","Ruby — ทับทิม"],["wine","Wine — ไวน์แดง"],["bubblegum","Bubblegum — ชมพูหมากฝรั่ง"],["blush","Blush — ชมพูแก้มอ่อน"],["flamingo","Flamingo — ชมพูฟลามิงโก"],["cherry","Cherry — เชอร์รี่"],["scarlet","Scarlet — แดงสด"],["burgundy","Burgundy — เบอร์กันดี"],["salmon","Salmon — ส้มแซลมอน"]]],["ส้ม · เหลือง · ทอง",[["amber","Amber — ทองอำพัน"],["tangerine","Tangerine — ส้มสด"],["gold","Gold — ทองคำ"],["lemon","Lemon — เหลืองมะนาว"],["bronze","Bronze — สัมฤทธิ์"],["sand","Sand — ทรายอุ่น"],["apricot","Apricot — ส้มแอปริคอต"],["honey","Honey — เหลืองน้ำผึ้ง"],["mustard","Mustard — เหลืองมัสตาร์ด"],["copper","Copper — ทองแดง"],["caramel","Caramel — คาราเมล"],["cream","Cream — ครีมนุ่ม"],["pumpkin","Pumpkin — ส้มฟักทอง"]]],["เขียว",[["emerald","Emerald — เขียวมรกต"],["mint","Mint — เขียวมิ้นต์"],["lime","Lime — เขียวมะนาว"],["forest","Forest — เขียวป่า"],["matcha","Matcha — เขียวมัทฉะ"],["teal","Teal — เขียวน้ำทะเล"],["pine","Pine — เขียวสน"],["olive","Olive — เขียวมะกอก"],["sage","Sage — เขียวเซจ"],["pistachio","Pistachio — เขียวพิสตาชิโอ"],["seafoam","Seafoam — เขียวฟองคลื่น"],["jungle","Jungle — เขียวป่าดิบ"]]],["ฟ้า · น้ำเงิน · คราม",[["ocean","Ocean — ฟ้า/น้ำเงิน"],["sky","Sky — ฟ้าใส"],["cyan","Cyan — ฟ้าไซเบอร์"],["cobalt","Cobalt — น้ำเงินโคบอลต์"],["indigo","Indigo — ครามเข้ม"],["midnight","Midnight — น้ำเงินเที่ยงคืน"],["ink","Ink — หมึกเทาฟ้า"],["azure","Azure — ฟ้าอาซัวร์"],["arctic","Arctic — ฟ้าอาร์กติก"],["denim","Denim — ยีนส์"],["navy","Navy — กรมท่า"],["electric","Electric Blue — น้ำเงินไฟฟ้า"],["periwinkle","Periwinkle — ฟ้าอมม่วง"],["steel","Steel — เหล็กฟ้า"]]],["ม่วง",[["violet","Violet — ม่วงพรีเมียม"],["amethyst","Amethyst — อเมทิสต์"],["lavender","Lavender — ลาเวนเดอร์"],["orchid","Orchid — กล้วยไม้"],["magenta","Magenta — บานเย็น"],["grape","Grape — ม่วงองุ่น"],["plum","Plum — ม่วงพลัม"],["mauve","Mauve — ม่วงมอฟ"],["lilac","Lilac — ม่วงไลแลค"],["royalpurple","Royal Purple — ม่วงราชวงศ์"],["berry","Berry — ม่วงเบอร์รี่"],["thistle","Thistle — ม่วงหม่นนุ่ม"]]],["เมทัลลิก · เรียบ",[["mono","Monochrome — ขาวดำ"],["silver","Silver — เงิน"],["rosegold","Rose Gold — โรสโกลด์"],["pearl","Pearl — ไข่มุก"],["platinum","Platinum — แพลทินัม"],["titanium","Titanium — ไทเทเนียม"],["graphite","Graphite — กราไฟต์"],["champagne","Champagne — แชมเปญ"],["chrome","Chrome — โครเมียม"]]],["นีออน",[["neonpink","Neon Pink — นีออนชมพู"],["neonblue","Neon Blue — นีออนฟ้า"],["neongreen","Neon Green — นีออนเขียว"],["neonorange","Neon Orange — นีออนส้ม"],["neonviolet","Neon Violet — นีออนม่วง"],["neonyellow","Neon Yellow — นีออนเหลือง"]]],["ไล่สี 2 โทน",[["obsidian","Obsidian — ดำม่วงคราม"],["aurora","Aurora — ออโรรา เขียว→ม่วง"],["nebula","Nebula — เนบิวลา ม่วง→ฟ้า"],["lagoon","Lagoon — ลากูน เขียวน้ำ→น้ำเงิน"],["sunset","Sunset — พระอาทิตย์ตก ส้ม→ชมพู"],["ember","Ember — ถ่านไฟ แดง→ส้ม"],["candy","Candy — แคนดี้ ชมพู→ฟ้า"],["twilight","Twilight — ทไวไลท์ ม่วง→ชมพู"],["deepsea","Deep Sea — ทะเลลึก ฟ้า→น้ำเงิน"],["mango","Mango — มะม่วง เหลือง→ส้ม"],["berrypop","Berry Pop — เบอร์รี่ ชมพู→ม่วง"],["frost","Frost — น้ำแข็ง ฟ้า→ลาเวนเดอร์"],["blossom","Blossom — ดอกซากุระ ชมพู→ลาเวนเดอร์"],["royalgold","Royal Gold — ทอง→ม่วงหลวง"],["toxic","Toxic — เขียวพิษ มะนาว→มิ้นต์"],["galaxy","Galaxy — กาแล็กซี่ คราม→ม่วงบานเย็น"],["sunrise","Sunrise — รุ่งอรุณ ส้ม→ชมพู"],["peacock","Peacock — นกยูง เขียวน้ำ→ม่วง"],["mist","Mist — หมอก ฟ้า→เทา"],["dusk","Dusk — สนธยา น้ำเงิน→ชมพู"],["mojito","Mojito — โมฮิโต้ มิ้นต์→มะนาว"]]]];
const MMT_THEME_SHADE_GROUPS=[["เฉดสี · ชมพูพิงก์ / Pink",[["pink-100","Pink 100 — ชมพูพิงก์ เฉด 100"],["pink-200","Pink 200 — ชมพูพิงก์ เฉด 200"],["pink-300","Pink 300 — ชมพูพิงก์ เฉด 300"],["pink-400","Pink 400 — ชมพูพิงก์ เฉด 400"],["pink-500","Pink 500 — ชมพูพิงก์ เฉด 500"],["pink-600","Pink 600 — ชมพูพิงก์ เฉด 600"],["pink-700","Pink 700 — ชมพูพิงก์ เฉด 700"],["pink-800","Pink 800 — ชมพูพิงก์ เฉด 800"],["pink-900","Pink 900 — ชมพูพิงก์ เฉด 900"]]],["เฉดสี · ชมพูโรส / Rose",[["rose-100","Rose 100 — ชมพูโรส เฉด 100"],["rose-200","Rose 200 — ชมพูโรส เฉด 200"],["rose-300","Rose 300 — ชมพูโรส เฉด 300"],["rose-400","Rose 400 — ชมพูโรส เฉด 400"],["rose-500","Rose 500 — ชมพูโรส เฉด 500"],["rose-600","Rose 600 — ชมพูโรส เฉด 600"],["rose-700","Rose 700 — ชมพูโรส เฉด 700"],["rose-800","Rose 800 — ชมพูโรส เฉด 800"],["rose-900","Rose 900 — ชมพูโรส เฉด 900"]]],["เฉดสี · แดง / Red",[["red-100","Red 100 — แดง เฉด 100"],["red-200","Red 200 — แดง เฉด 200"],["red-300","Red 300 — แดง เฉด 300"],["red-400","Red 400 — แดง เฉด 400"],["red-500","Red 500 — แดง เฉด 500"],["red-600","Red 600 — แดง เฉด 600"],["red-700","Red 700 — แดง เฉด 700"],["red-800","Red 800 — แดง เฉด 800"],["red-900","Red 900 — แดง เฉด 900"]]],["เฉดสี · ส้มคอรัล / Coral",[["coral-100","Coral 100 — ส้มคอรัล เฉด 100"],["coral-200","Coral 200 — ส้มคอรัล เฉด 200"],["coral-300","Coral 300 — ส้มคอรัล เฉด 300"],["coral-400","Coral 400 — ส้มคอรัล เฉด 400"],["coral-500","Coral 500 — ส้มคอรัล เฉด 500"],["coral-600","Coral 600 — ส้มคอรัล เฉด 600"],["coral-700","Coral 700 — ส้มคอรัล เฉด 700"],["coral-800","Coral 800 — ส้มคอรัล เฉด 800"],["coral-900","Coral 900 — ส้มคอรัล เฉด 900"]]],["เฉดสี · ส้ม / Orange",[["orange-100","Orange 100 — ส้ม เฉด 100"],["orange-200","Orange 200 — ส้ม เฉด 200"],["orange-300","Orange 300 — ส้ม เฉด 300"],["orange-400","Orange 400 — ส้ม เฉด 400"],["orange-500","Orange 500 — ส้ม เฉด 500"],["orange-600","Orange 600 — ส้ม เฉด 600"],["orange-700","Orange 700 — ส้ม เฉด 700"],["orange-800","Orange 800 — ส้ม เฉด 800"],["orange-900","Orange 900 — ส้ม เฉด 900"]]],["เฉดสี · อำพัน / Amber",[["amber-100","Amber 100 — อำพัน เฉด 100"],["amber-200","Amber 200 — อำพัน เฉด 200"],["amber-300","Amber 300 — อำพัน เฉด 300"],["amber-400","Amber 400 — อำพัน เฉด 400"],["amber-500","Amber 500 — อำพัน เฉด 500"],["amber-600","Amber 600 — อำพัน เฉด 600"],["amber-700","Amber 700 — อำพัน เฉด 700"],["amber-800","Amber 800 — อำพัน เฉด 800"],["amber-900","Amber 900 — อำพัน เฉด 900"]]],["เฉดสี · เหลือง / Yellow",[["yellow-100","Yellow 100 — เหลือง เฉด 100"],["yellow-200","Yellow 200 — เหลือง เฉด 200"],["yellow-300","Yellow 300 — เหลือง เฉด 300"],["yellow-400","Yellow 400 — เหลือง เฉด 400"],["yellow-500","Yellow 500 — เหลือง เฉด 500"],["yellow-600","Yellow 600 — เหลือง เฉด 600"],["yellow-700","Yellow 700 — เหลือง เฉด 700"],["yellow-800","Yellow 800 — เหลือง เฉด 800"],["yellow-900","Yellow 900 — เหลือง เฉด 900"]]],["เฉดสี · เขียวมะนาว / Lime",[["lime-100","Lime 100 — เขียวมะนาว เฉด 100"],["lime-200","Lime 200 — เขียวมะนาว เฉด 200"],["lime-300","Lime 300 — เขียวมะนาว เฉด 300"],["lime-400","Lime 400 — เขียวมะนาว เฉด 400"],["lime-500","Lime 500 — เขียวมะนาว เฉด 500"],["lime-600","Lime 600 — เขียวมะนาว เฉด 600"],["lime-700","Lime 700 — เขียวมะนาว เฉด 700"],["lime-800","Lime 800 — เขียวมะนาว เฉด 800"],["lime-900","Lime 900 — เขียวมะนาว เฉด 900"]]],["เฉดสี · เขียว / Green",[["green-100","Green 100 — เขียว เฉด 100"],["green-200","Green 200 — เขียว เฉด 200"],["green-300","Green 300 — เขียว เฉด 300"],["green-400","Green 400 — เขียว เฉด 400"],["green-500","Green 500 — เขียว เฉด 500"],["green-600","Green 600 — เขียว เฉด 600"],["green-700","Green 700 — เขียว เฉด 700"],["green-800","Green 800 — เขียว เฉด 800"],["green-900","Green 900 — เขียว เฉด 900"]]],["เฉดสี · เขียวมรกต / Emerald",[["emerald-100","Emerald 100 — เขียวมรกต เฉด 100"],["emerald-200","Emerald 200 — เขียวมรกต เฉด 200"],["emerald-300","Emerald 300 — เขียวมรกต เฉด 300"],["emerald-400","Emerald 400 — เขียวมรกต เฉด 400"],["emerald-500","Emerald 500 — เขียวมรกต เฉด 500"],["emerald-600","Emerald 600 — เขียวมรกต เฉด 600"],["emerald-700","Emerald 700 — เขียวมรกต เฉด 700"],["emerald-800","Emerald 800 — เขียวมรกต เฉด 800"],["emerald-900","Emerald 900 — เขียวมรกต เฉด 900"]]],["เฉดสี · มิ้นต์ / Mint",[["mint-100","Mint 100 — มิ้นต์ เฉด 100"],["mint-200","Mint 200 — มิ้นต์ เฉด 200"],["mint-300","Mint 300 — มิ้นต์ เฉด 300"],["mint-400","Mint 400 — มิ้นต์ เฉด 400"],["mint-500","Mint 500 — มิ้นต์ เฉด 500"],["mint-600","Mint 600 — มิ้นต์ เฉด 600"],["mint-700","Mint 700 — มิ้นต์ เฉด 700"],["mint-800","Mint 800 — มิ้นต์ เฉด 800"],["mint-900","Mint 900 — มิ้นต์ เฉด 900"]]],["เฉดสี · เขียวอมฟ้า / Teal",[["teal-100","Teal 100 — เขียวอมฟ้า เฉด 100"],["teal-200","Teal 200 — เขียวอมฟ้า เฉด 200"],["teal-300","Teal 300 — เขียวอมฟ้า เฉด 300"],["teal-400","Teal 400 — เขียวอมฟ้า เฉด 400"],["teal-500","Teal 500 — เขียวอมฟ้า เฉด 500"],["teal-600","Teal 600 — เขียวอมฟ้า เฉด 600"],["teal-700","Teal 700 — เขียวอมฟ้า เฉด 700"],["teal-800","Teal 800 — เขียวอมฟ้า เฉด 800"],["teal-900","Teal 900 — เขียวอมฟ้า เฉด 900"]]],["เฉดสี · ไซแอน / Cyan",[["cyan-100","Cyan 100 — ไซแอน เฉด 100"],["cyan-200","Cyan 200 — ไซแอน เฉด 200"],["cyan-300","Cyan 300 — ไซแอน เฉด 300"],["cyan-400","Cyan 400 — ไซแอน เฉด 400"],["cyan-500","Cyan 500 — ไซแอน เฉด 500"],["cyan-600","Cyan 600 — ไซแอน เฉด 600"],["cyan-700","Cyan 700 — ไซแอน เฉด 700"],["cyan-800","Cyan 800 — ไซแอน เฉด 800"],["cyan-900","Cyan 900 — ไซแอน เฉด 900"]]],["เฉดสี · ฟ้าสกาย / Sky",[["sky-100","Sky 100 — ฟ้าสกาย เฉด 100"],["sky-200","Sky 200 — ฟ้าสกาย เฉด 200"],["sky-300","Sky 300 — ฟ้าสกาย เฉด 300"],["sky-400","Sky 400 — ฟ้าสกาย เฉด 400"],["sky-500","Sky 500 — ฟ้าสกาย เฉด 500"],["sky-600","Sky 600 — ฟ้าสกาย เฉด 600"],["sky-700","Sky 700 — ฟ้าสกาย เฉด 700"],["sky-800","Sky 800 — ฟ้าสกาย เฉด 800"],["sky-900","Sky 900 — ฟ้าสกาย เฉด 900"]]],["เฉดสี · น้ำเงิน / Blue",[["blue-100","Blue 100 — น้ำเงิน เฉด 100"],["blue-200","Blue 200 — น้ำเงิน เฉด 200"],["blue-300","Blue 300 — น้ำเงิน เฉด 300"],["blue-400","Blue 400 — น้ำเงิน เฉด 400"],["blue-500","Blue 500 — น้ำเงิน เฉด 500"],["blue-600","Blue 600 — น้ำเงิน เฉด 600"],["blue-700","Blue 700 — น้ำเงิน เฉด 700"],["blue-800","Blue 800 — น้ำเงิน เฉด 800"],["blue-900","Blue 900 — น้ำเงิน เฉด 900"]]],["เฉดสี · โคบอลต์ / Cobalt",[["cobalt-100","Cobalt 100 — โคบอลต์ เฉด 100"],["cobalt-200","Cobalt 200 — โคบอลต์ เฉด 200"],["cobalt-300","Cobalt 300 — โคบอลต์ เฉด 300"],["cobalt-400","Cobalt 400 — โคบอลต์ เฉด 400"],["cobalt-500","Cobalt 500 — โคบอลต์ เฉด 500"],["cobalt-600","Cobalt 600 — โคบอลต์ เฉด 600"],["cobalt-700","Cobalt 700 — โคบอลต์ เฉด 700"],["cobalt-800","Cobalt 800 — โคบอลต์ เฉด 800"],["cobalt-900","Cobalt 900 — โคบอลต์ เฉด 900"]]],["เฉดสี · คราม / Indigo",[["indigo-100","Indigo 100 — คราม เฉด 100"],["indigo-200","Indigo 200 — คราม เฉด 200"],["indigo-300","Indigo 300 — คราม เฉด 300"],["indigo-400","Indigo 400 — คราม เฉด 400"],["indigo-500","Indigo 500 — คราม เฉด 500"],["indigo-600","Indigo 600 — คราม เฉด 600"],["indigo-700","Indigo 700 — คราม เฉด 700"],["indigo-800","Indigo 800 — คราม เฉด 800"],["indigo-900","Indigo 900 — คราม เฉด 900"]]],["เฉดสี · ม่วงไวโอเลต / Violet",[["violet-100","Violet 100 — ม่วงไวโอเลต เฉด 100"],["violet-200","Violet 200 — ม่วงไวโอเลต เฉด 200"],["violet-300","Violet 300 — ม่วงไวโอเลต เฉด 300"],["violet-400","Violet 400 — ม่วงไวโอเลต เฉด 400"],["violet-500","Violet 500 — ม่วงไวโอเลต เฉด 500"],["violet-600","Violet 600 — ม่วงไวโอเลต เฉด 600"],["violet-700","Violet 700 — ม่วงไวโอเลต เฉด 700"],["violet-800","Violet 800 — ม่วงไวโอเลต เฉด 800"],["violet-900","Violet 900 — ม่วงไวโอเลต เฉด 900"]]],["เฉดสี · ม่วง / Purple",[["purple-100","Purple 100 — ม่วง เฉด 100"],["purple-200","Purple 200 — ม่วง เฉด 200"],["purple-300","Purple 300 — ม่วง เฉด 300"],["purple-400","Purple 400 — ม่วง เฉด 400"],["purple-500","Purple 500 — ม่วง เฉด 500"],["purple-600","Purple 600 — ม่วง เฉด 600"],["purple-700","Purple 700 — ม่วง เฉด 700"],["purple-800","Purple 800 — ม่วง เฉด 800"],["purple-900","Purple 900 — ม่วง เฉด 900"]]],["เฉดสี · แมเจนตา / Magenta",[["magenta-100","Magenta 100 — แมเจนตา เฉด 100"],["magenta-200","Magenta 200 — แมเจนตา เฉด 200"],["magenta-300","Magenta 300 — แมเจนตา เฉด 300"],["magenta-400","Magenta 400 — แมเจนตา เฉด 400"],["magenta-500","Magenta 500 — แมเจนตา เฉด 500"],["magenta-600","Magenta 600 — แมเจนตา เฉด 600"],["magenta-700","Magenta 700 — แมเจนตา เฉด 700"],["magenta-800","Magenta 800 — แมเจนตา เฉด 800"],["magenta-900","Magenta 900 — แมเจนตา เฉด 900"]]],["เฉดสี · น้ำตาล / Brown",[["brown-100","Brown 100 — น้ำตาล เฉด 100"],["brown-200","Brown 200 — น้ำตาล เฉด 200"],["brown-300","Brown 300 — น้ำตาล เฉด 300"],["brown-400","Brown 400 — น้ำตาล เฉด 400"],["brown-500","Brown 500 — น้ำตาล เฉด 500"],["brown-600","Brown 600 — น้ำตาล เฉด 600"],["brown-700","Brown 700 — น้ำตาล เฉด 700"],["brown-800","Brown 800 — น้ำตาล เฉด 800"],["brown-900","Brown 900 — น้ำตาล เฉด 900"]]],["เฉดสี · เทาหินชนวน / Slate",[["slate-100","Slate 100 — เทาหินชนวน เฉด 100"],["slate-200","Slate 200 — เทาหินชนวน เฉด 200"],["slate-300","Slate 300 — เทาหินชนวน เฉด 300"],["slate-400","Slate 400 — เทาหินชนวน เฉด 400"],["slate-500","Slate 500 — เทาหินชนวน เฉด 500"],["slate-600","Slate 600 — เทาหินชนวน เฉด 600"],["slate-700","Slate 700 — เทาหินชนวน เฉด 700"],["slate-800","Slate 800 — เทาหินชนวน เฉด 800"],["slate-900","Slate 900 — เทาหินชนวน เฉด 900"]]]];
function mmtCardThemeMap(){try{return JSON.parse(localStorage.getItem('manga_card_themes')||'{}')}catch{return {}}}
function mmtSaveCardTheme(id,theme){const map=mmtCardThemeMap();if(!theme||theme==='auto')delete map[String(id)];else map[String(id)]=theme;try{localStorage.setItem('manga_card_themes',JSON.stringify(map))}catch{}}
function mmtThemeFieldHtml(){
 const cur=mmtCardThemeMap()[String(manga.id)]||'auto';
 const opts=[...MMT_THEME_GROUPS,...MMT_THEME_SHADE_GROUPS].map(g=>`<optgroup label="${esc(g[0])}">${g[1].map(o=>`<option value="${esc(o[0])}" ${o[0]===cur?'selected':''}>${esc(o[1])}</option>`).join('')}</optgroup>`).join('');
 return `<label class="full-field card-theme-field">ธีมสีการ์ดประจำเรื่อง<select id="eCardTheme"><option value="auto" ${cur==='auto'?'selected':''}>Auto — เลือกอัตโนมัติจากทุกธีม</option>${opts}</select><small>บันทึกธีมไว้ในเบราว์เซอร์เครื่องนี้ ใช้กับการ์ดของเรื่องนี้ในหน้าคลัง หากเลือก Auto ระบบจะเลือกสีจากชื่อเรื่อง</small></label><label class="full-field theme-search-field">ค้นหาเฉดสี<input type="search" id="eThemeSearch" class="theme-swatch-search" placeholder="พิมพ์ชื่อสี เช่น blue 400, เขียว, ชมพู 700" autocomplete="off" aria-label="ค้นหาเฉดสีการ์ด"></label><div class="full-field theme-swatches" id="eThemeSwatches" aria-label="เลือกสีธีมการ์ด"></div>`;
}
function mmtSyncThemeSwatches(){const sel=$('eCardTheme'),host=$('eThemeSwatches');if(!sel||!host)return;host.querySelectorAll('[data-theme-pick]').forEach(b=>{const on=b.dataset.themePick===sel.value;b.classList.toggle('active',on);if(on&&host.dataset.ready==='2')b.scrollIntoView({block:'nearest',inline:'nearest'})})}
function mmtInitThemePicker(){
 const sel=$('eCardTheme'),host=$('eThemeSwatches');if(!sel||!host)return;
 host.innerHTML=[...sel.options].map(o=>{
  const name=esc(o.textContent.trim());
  if(o.value==='auto')return `<button type="button" class="theme-swatch auto" data-theme-pick="auto" title="${name}" aria-label="${name}"><span>A</span></button>`;
  return `<button type="button" class="theme-swatch manga-theme-${esc(o.value)}" data-theme-pick="${esc(o.value)}" data-theme-label="${name.toLowerCase()}" title="${name}" aria-label="${name}"></button>`;
 }).join('');
 host.addEventListener('click',e=>{const b=e.target.closest('[data-theme-pick]');if(!b)return;sel.value=b.dataset.themePick;mmtSyncThemeSwatches()});
 const search=$('eThemeSearch');const filter=()=>{const q=(search?.value||'').trim().toLowerCase();host.querySelectorAll('[data-theme-pick]').forEach(b=>{b.hidden=!!q&&!(`${b.dataset.themePick||''} ${b.dataset.themeLabel||b.title||''}`).toLowerCase().includes(q)})};search?.addEventListener('input',filter);
 sel.addEventListener('change',mmtSyncThemeSwatches);mmtSyncThemeSwatches();host.dataset.ready='2';
}

/* v17.14.3 — the detail page has no bottom dock; also covers a stale cached manga.html that still contains one */
try{document.body.classList.add('page-detail');document.querySelectorAll('.bottom-nav').forEach(n=>n.remove())}catch{}
/* v17.14 — detail page uses the story's card theme (same pool/order/hash as the library, so Auto matches) */
const MMT_THEME_SHADE_IDS=["pink-100", "pink-200", "pink-300", "pink-400", "pink-500", "pink-600", "pink-700", "pink-800", "pink-900", "rose-100", "rose-200", "rose-300", "rose-400", "rose-500", "rose-600", "rose-700", "rose-800", "rose-900", "red-100", "red-200", "red-300", "red-400", "red-500", "red-600", "red-700", "red-800", "red-900", "coral-100", "coral-200", "coral-300", "coral-400", "coral-500", "coral-600", "coral-700", "coral-800", "coral-900", "orange-100", "orange-200", "orange-300", "orange-400", "orange-500", "orange-600", "orange-700", "orange-800", "orange-900", "amber-100", "amber-200", "amber-300", "amber-400", "amber-500", "amber-600", "amber-700", "amber-800", "amber-900", "yellow-100", "yellow-200", "yellow-300", "yellow-400", "yellow-500", "yellow-600", "yellow-700", "yellow-800", "yellow-900", "lime-100", "lime-200", "lime-300", "lime-400", "lime-500", "lime-600", "lime-700", "lime-800", "lime-900", "green-100", "green-200", "green-300", "green-400", "green-500", "green-600", "green-700", "green-800", "green-900", "emerald-100", "emerald-200", "emerald-300", "emerald-400", "emerald-500", "emerald-600", "emerald-700", "emerald-800", "emerald-900", "mint-100", "mint-200", "mint-300", "mint-400", "mint-500", "mint-600", "mint-700", "mint-800", "mint-900", "teal-100", "teal-200", "teal-300", "teal-400", "teal-500", "teal-600", "teal-700", "teal-800", "teal-900", "cyan-100", "cyan-200", "cyan-300", "cyan-400", "cyan-500", "cyan-600", "cyan-700", "cyan-800", "cyan-900", "sky-100", "sky-200", "sky-300", "sky-400", "sky-500", "sky-600", "sky-700", "sky-800", "sky-900", "blue-100", "blue-200", "blue-300", "blue-400", "blue-500", "blue-600", "blue-700", "blue-800", "blue-900", "cobalt-100", "cobalt-200", "cobalt-300", "cobalt-400", "cobalt-500", "cobalt-600", "cobalt-700", "cobalt-800", "cobalt-900", "indigo-100", "indigo-200", "indigo-300", "indigo-400", "indigo-500", "indigo-600", "indigo-700", "indigo-800", "indigo-900", "violet-100", "violet-200", "violet-300", "violet-400", "violet-500", "violet-600", "violet-700", "violet-800", "violet-900", "purple-100", "purple-200", "purple-300", "purple-400", "purple-500", "purple-600", "purple-700", "purple-800", "purple-900", "magenta-100", "magenta-200", "magenta-300", "magenta-400", "magenta-500", "magenta-600", "magenta-700", "magenta-800", "magenta-900", "brown-100", "brown-200", "brown-300", "brown-400", "brown-500", "brown-600", "brown-700", "brown-800", "brown-900", "slate-100", "slate-200", "slate-300", "slate-400", "slate-500", "slate-600", "slate-700", "slate-800", "slate-900"];
const MMT_THEME_POOL=["rose", "sakura", "coral", "peach", "crimson", "ruby", "wine", "amber", "tangerine", "gold", "lemon", "bronze", "sand", "emerald", "mint", "lime", "forest", "matcha", "teal", "ocean", "sky", "cyan", "cobalt", "indigo", "midnight", "ink", "violet", "amethyst", "lavender", "orchid", "magenta", "mono", "silver", "rosegold", "obsidian", "aurora", "nebula", "lagoon", "sunset", "ember", "candy", "bubblegum", "blush", "flamingo", "cherry", "scarlet", "burgundy", "salmon", "apricot", "honey", "mustard", "copper", "caramel", "cream", "pumpkin", "pine", "olive", "sage", "pistachio", "seafoam", "jungle", "azure", "arctic", "denim", "navy", "electric", "periwinkle", "steel", "grape", "plum", "mauve", "lilac", "royalpurple", "berry", "thistle", "pearl", "platinum", "titanium", "graphite", "champagne", "chrome", "neonpink", "neonblue", "neongreen", "neonorange", "neonviolet", "neonyellow", "twilight", "deepsea", "mango", "berrypop", "frost", "blossom", "royalgold", "toxic", "galaxy", "sunrise", "peacock", "mist", "dusk", "mojito"].concat(MMT_THEME_SHADE_IDS);
function mmtThemeFor(m){
 const saved=mmtCardThemeMap()[String(m.id)];
 if(saved&&MMT_THEME_POOL.includes(saved))return saved;
 const title=String(m.title||m.id||'');let h=0;
 for(let i=0;i<title.length;i++)h=(h*31+title.charCodeAt(i))|0;
 return MMT_THEME_POOL[Math.abs(h)%MMT_THEME_POOL.length];
}
function mmtApplyThemeContrast(){
 const el=document.querySelector('.detail-card');if(!el)return;
 const cs=getComputedStyle(el);
 const lum=hex=>{const m=/^#?([0-9a-f]{6})$/i.exec(String(hex||'').trim());if(!m)return null;const n=parseInt(m[1],16),f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f((n>>16)&255)+.7152*f((n>>8)&255)+.0722*f(n&255)};
 const a=lum(cs.getPropertyValue('--manga-accent')),b=lum(cs.getPropertyValue('--manga-accent-2'));
 const L=a==null?0:(b==null?a:(a+b)/2);
 el.style.setProperty('--manga-on',L>0.42?'#0b0f14':'#ffffff');
}
function ratingStarsHtml(rating){
 const r=Math.max(0,Math.min(5,Math.round((Number(rating)||0)*2)/2));
 if(!r)return '☆☆☆☆☆';
 const full=Math.floor(r),half=r-full>=.5?1:0;
 return '★'.repeat(full)+(half?'<span class="half-star" aria-hidden="true">☆</span>':'')+'☆'.repeat(5-full-half);
}
let ratingSvgSequence=0;
function ratingSvgStarsHtml(value,{size=20,prefix='rating'}={}){
 const rating=Math.max(0,Math.min(5,Math.round((Number(value)||0)*2)/2));
 return `<span class="rating-svg-stars" style="--rating-star-size:${size}px" aria-hidden="true">${[1,2,3,4,5].map(i=>{
   const id=`mmt-rating-${prefix}-${++ratingSvgSequence}`;
   const fill=rating>=i?100:rating>i-1?(rating-(i-1))*100:0;
   const path='M12 2.2 14.9 8.4 21.7 9.2 16.7 13.9 18 20.8 12 17.4 6 20.8 7.3 13.9 2.3 9.2 9.1 8.4Z';
   return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" focusable="false"><defs><clipPath id="${id}"><rect x="0" y="0" width="${24*fill/100}" height="24"/></clipPath></defs><path d="${path}" class="rating-star-outline"/><path d="${path}" class="rating-star-fill" clip-path="url(#${id})"/></svg>`;
 }).join('')}</span>`;
}
function ratingPickerMarkup(selectId){
 return `<select id="${selectId}" class="rating-native-select" aria-hidden="true" tabindex="-1"><option value="">ไม่ให้คะแนน</option>${[5,4.5,4,3.5,3,2.5,2,1.5,1].map(v=>`<option value="${v}">${v.toFixed(1)}</option>`).join('')}</select><div class="rating-picker" id="${selectId}Picker"><button type="button" class="rating-trigger" id="${selectId}Trigger" aria-haspopup="listbox" aria-expanded="false" aria-controls="${selectId}Options"><span class="rating-trigger-main"><span id="${selectId}TriggerStars" class="rating-stars" aria-hidden="true"></span><span id="${selectId}TriggerText">ไม่ให้คะแนน</span></span><svg class="rating-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg></button><div class="rating-options" id="${selectId}Options" role="listbox" aria-label="เลือกระดับคะแนน" hidden></div></div>`;
}
function setupRatingPicker(selectId){
 const select=$(selectId),picker=$(selectId+'Picker'),trigger=$(selectId+'Trigger'),options=$(selectId+'Options'),text=$(selectId+'TriggerText'),stars=$(selectId+'TriggerStars');
 if(!select||!picker||!trigger||!options)return;
 const sync=()=>{const value=select.value,score=Number(value)||0;stars.innerHTML=ratingSvgStarsHtml(score,{size:19,prefix:'trigger'});text.textContent=value?score.toFixed(1)+' / 5':'ไม่ให้คะแนน';options.querySelectorAll('[data-rating-value]').forEach(b=>{const on=b.dataset.ratingValue===value;b.classList.toggle('is-selected',on);b.setAttribute('aria-selected',String(on))})};
 options.innerHTML=['','5','4.5','4','3.5','3','2.5','2','1.5','1'].map(v=>{if(!v)return `<button type="button" class="rating-option rating-option-none" role="option" aria-selected="false" data-rating-value=""><span class="rating-none-icon">○</span><span class="rating-option-label">ไม่ให้คะแนน</span><span class="rating-option-value">—</span></button>`;const s=Number(v);return `<button type="button" class="rating-option" role="option" aria-selected="false" data-rating-value="${v}"><span class="rating-option-stars">${ratingSvgStarsHtml(s,{size:22,prefix:'option'})}</span><span class="rating-option-value">${s.toFixed(1)}</span></button>`}).join('');
 const close=()=>{options.hidden=true;trigger.setAttribute('aria-expanded','false');picker.classList.remove('is-open')};
 const open=()=>{options.hidden=false;trigger.setAttribute('aria-expanded','true');picker.classList.add('is-open');options.scrollIntoView({block:'nearest'})};
 trigger.addEventListener('click',()=>options.hidden?open():close());
 options.addEventListener('click',e=>{const b=e.target.closest('[data-rating-value]');if(!b)return;select.value=b.dataset.ratingValue;sync();close();trigger.focus()});
 const outside=e=>{if(!picker.isConnected){document.removeEventListener('click',outside);return}if(!picker.contains(e.target))close()};
 document.addEventListener('click',outside);
 picker.addEventListener('keydown',e=>{if(e.key==='Escape'&&!options.hidden){e.stopPropagation();close();trigger.focus()}});
 sync();
}
function ratingSelectValue(v){const n=Number(v);return Number.isFinite(n)&&n>0?String(n):''}
function ratingOptionLabel(v){const f=Math.floor(v),h=v-f>0;return '★'.repeat(f)+(h?'½':'')+'☆'.repeat(5-f-(h?1:0))+' · '+v}
function openEditModal(){
 const currentG=String(manga.genre_ids||'').split(',').filter(Boolean).map(Number);selectedCollections=String(manga.collection_ids||'').split(',').filter(Boolean).map(Number);
 const modal=document.createElement('div');modal.className='modal';modal.id='modal';modal.innerHTML=`<div class="modal-box xl-modal"><div class="modal-head"><div><div class="section-kicker">EDIT LIBRARY ITEM</div><h2>แก้ไขเรื่อง</h2></div><button class="close-btn" id="closeEdit">×</button></div><form id="form"><div class="modal-form-scroll"><div class="form-grid two-col"><label>ชื่อเรื่อง<input id="eTitle" maxlength="255" required value="${esc(manga.title)}"></label><label>ชื่อสำรอง<input id="eAlt" maxlength="255" value="${esc(manga.alt_title||'')}"></label><label class="full-field">URL หน้าหลัก<input id="eSource" type="url" required value="${esc(manga.source_url)}"></label><label class="full-field">URL รูปปก<input id="eCover" type="url" value="${esc(manga.cover_url||'')}"></label><div class="taxonomy-picker full-field"><div class="picker-title"><strong>ประเภทหลัก</strong><small>เลือก 1</small></div><div id="eTypes" class="picker-grid">${types.map(t=>`<button type="button" class="pick ${String(t.id)===String(manga.type_id??manga.category_id)?'selected':''} ${adult(t)?'adult-pick':''}" data-e-type="${t.id}">${esc(typeIcon(t.name)+' '+t.name)}</button>`).join('')}</div></div><div class="taxonomy-picker full-field"><div class="picker-title"><strong>แนวเรื่อง</strong><small>เลือกได้หลายแนว</small></div><div id="eGenres" class="picker-grid">${genres.map(g=>`<button type="button" class="pick ${currentG.includes(Number(g.id))?'selected':''}" data-e-genre="${g.id}">${esc(genreLabel(g.name))}</button>`).join('')}</div></div><div class="taxonomy-picker full-field"><div class="picker-title"><strong>ลักษณะตัวเอก / คู่หลัก</strong><small>เลือก 1 แบบ</small></div><div id="eLead" class="picker-grid lead-picker">
<button type="button" class="pick ${!manga.lead_type?'selected':''}" data-e-lead="">⚪ ไม่ระบุ</button>
<button type="button" class="pick ${manga.lead_type==='male'?'selected':''}" data-e-lead="male">👨 Male Lead - ตัวเอกชาย</button>
<button type="button" class="pick ${manga.lead_type==='female'?'selected':''}" data-e-lead="female">👩 Female Lead - ตัวเอกหญิง</button>
<button type="button" class="pick ${['yaoi','gay'].includes(String(manga.lead_type||'').toLowerCase())?'selected':''}" data-e-lead="gay">🏳️‍🌈 (Gay) เกย์</button><button type="button" class="pick ${String(manga.lead_type||'').toLowerCase()==='lesbian'?'selected':''}" data-e-lead="lesbian">🏳️‍🌈 (Lesbian) เลสเบี้ยน</button>
</div></div><div class="taxonomy-picker full-field"><div class="picker-title"><strong>Collection</strong><small>เลือกได้หลายกลุ่ม</small></div><div id="eCollections" class="picker-grid">${collections.map(c=>`<button type="button" class="pick ${selectedCollections.includes(Number(c.id))?'selected':''}" data-e-col="${c.id}">${esc(c.name)}</button>`).join('')}</div></div><div class="taxonomy-picker full-field"><div class="picker-title"><strong>สถานะเรื่อง</strong><small>เรื่องต้นทางจบแล้วหรือยัง</small></div><div id="eCompletion" class="picker-grid completion-picker"><button type="button" class="pick completion-pick ${((manga.completion_status||'ongoing')==='ongoing')?'selected':''}" data-e-completion="ongoing">🟢 ยังไม่จบ</button><button type="button" class="pick completion-pick ${((manga.completion_status||'ongoing')==='completed')?'selected':''}" data-e-completion="completed">🔵 จบแล้ว</button></div></div><label>สถานะการอ่าน<select id="eStatus"><option value="reading">กำลังอ่าน</option><option value="planned">วางแผนอ่าน</option><option value="completed">อ่านจบแล้ว</option><option value="paused">พักการอ่าน</option><option value="dropped">เลิกอ่าน</option></select></label><div class="rating-field"><span class="rating-field-label">คะแนน</span>${ratingPickerMarkup('eRating')}</div>${mmtThemeFieldHtml()}<label class="full-field">หมายเหตุ<textarea id="eNote" rows="4">${esc(manga.note||'')}</textarea></label></div></div><div class="modal-actions add-manga-sticky-actions"><button class="btn ghost" type="button" id="cancelEdit" data-close="">ยกเลิก</button><button class="red btn save-progress-btn" id="saveBtn" type="submit" data-status="idle" aria-live="polite"><span class="save-progress-fill" aria-hidden="true"></span><span class="save-progress-content"><span id="saveBtnIcon" aria-hidden="true">↓</span><span id="saveBtnLabel">บันทึกการเปลี่ยนแปลง</span></span></button></div></form></div>`;
 document.body.appendChild(modal);mmtInitThemePicker();$('eStatus').value=manga.status;$('eRating').value=ratingSelectValue(manga.rating);setupRatingPicker('eRating');$('closeEdit').onclick=$('cancelEdit').onclick=()=>modal.remove();modal.onclick=e=>{if(e.target===modal)modal.remove()};
 document.querySelectorAll('[data-e-type]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-e-type]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});document.querySelectorAll('[data-e-genre]').forEach(b=>b.onclick=()=>b.classList.toggle('selected'));document.querySelectorAll('[data-e-col]').forEach(b=>b.onclick=()=>b.classList.toggle('selected'));document.querySelectorAll('[data-e-lead]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-e-lead]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});document.querySelectorAll('[data-e-completion]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-e-completion]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
 $('form').onsubmit=async e=>{e.preventDefault();const tb=document.querySelector('[data-e-type].selected');if(!tb)return toast('กรุณาเลือกประเภท',true);const sb=$('saveBtn'),sl=$('saveBtnLabel');if(sb){sb.dataset.status='downloading';sb.disabled=true}if(sl)sl.textContent='กำลังบันทึก...';try{const d=await api('update_manga',{id:manga.id,title:$('eTitle').value.trim(),alt_title:$('eAlt').value.trim(),source_url:$('eSource').value.trim(),cover_url:$('eCover').value.trim(),type_id:Number(tb.dataset.eType),lead_type:document.querySelector('[data-e-lead].selected')?.dataset.eLead||'',completion_status:document.querySelector('[data-e-completion].selected')?.dataset.eCompletion||'ongoing',status:$('eStatus').value,rating:$('eRating').value,note:$('eNote').value.trim(),genre_ids:[...document.querySelectorAll('[data-e-genre].selected')].map(b=>Number(b.dataset.eGenre)),collection_ids:[...document.querySelectorAll('[data-e-col].selected')].map(b=>Number(b.dataset.eCol))});mmtSaveCardTheme(manga.id,$('eCardTheme')?.value||'auto');modal.remove();toast('บันทึกการแก้ไขแล้ว');await reload();if(d.reward_unlocked&&d.completion_card)showCompletionReward(d.completion_card)}catch(err){if(sb){sb.dataset.status='idle';sb.disabled=false}if(sl)sl.textContent='บันทึกการเปลี่ยนแปลง';toast(err.message,true)}}
}
function showCompletionReward(card){
  const m=document.createElement('div');m.className='modal reward-overlay';
  const num=String(card.card_number||card.id||0).padStart(3,'0');
  const r=Number(card.rating||0);
  const rating=r>0?`<span class="reward-stars">${ratingStarsHtml(r)}</span><b>${r.toFixed(1)}</b>`:`<span class="reward-stars">☆☆☆☆☆</span><b>—</b>`;
  const cover=card.cover_snapshot?`<img src="${esc(card.cover_snapshot)}" alt="" class="reward-unlock-cover" referrerpolicy="no-referrer">`:'<div class="reward-unlock-cover reward-cover-fallback">🏆</div>';
  m.innerHTML=`<div class="modal-box reward-unlock-box"><button class="close-btn reward-local-close">×</button><div class="reward-unlock-kicker">🎉 COMPLETION UNLOCKED</div><h2>ยินดีด้วย!</h2><p>คุณอ่านเรื่องนี้จบแล้ว</p><div class="reward-unlock-card"><div class="reward-unlock-art">${cover}<span>COMPLETED #${num}</span></div><div class="reward-unlock-info"><h3>${esc(card.title_snapshot)}</h3><p>📚 ${Number(card.chapter_count||0)} Chapters</p><div class="reward-unlock-rating">${rating}</div><strong>${esc(card.message||'🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว')}</strong></div></div><div class="modal-actions"><button class="btn ghost reward-local-close">ไว้ดูทีหลัง</button><a class="red btn" href="index.html#rewards">🏆 ดูการ์ดสะสม</a></div></div>`;
  document.body.appendChild(m);m.querySelectorAll('.reward-local-close').forEach(b=>b.onclick=()=>m.remove());m.onclick=e=>{if(e.target===m)m.remove()}
}

function render(){
 const type=types.find(t=>Number(t.id)===Number(manga.type_id??manga.category_id));
 const g=String(manga.genre_names||'').split('||').filter(Boolean);
 const u=unread();
 const nxt=nextChapter();
 const p=pct();

 const isVidCover=/\.(mp4|webm|m4v)(?:[?#].*)?$/i.test(String(manga.cover_url||'').trim());
 const hasCover=!!String(manga.cover_url||'').trim();
 const coverUrl=hasCover?String(manga.cover_url):'';
 const ratingValue=(manga.rating===null||manga.rating===undefined||manga.rating==='')?0:Number(manga.rating||0);
 const ratingStars=ratingValue>0?ratingStarsHtml(ratingValue):'ยังไม่มีคะแนน';

 const cover=hasCover&&isVidCover
   ? `<video class="detail-cover-img detail-cover-video" src="${esc(coverUrl)}" autoplay muted loop playsinline preload="metadata" aria-label="${esc(manga.title||'')}" onerror="this.classList.add('is-broken');this.parentElement.classList.add('cover-broken')"></video>`
   : hasCover
   ? `<div class="detail-cover-bg" style="background-image:url('${esc(coverUrl)}')"></div>
      <img class="detail-cover-img" src="${esc(coverUrl)}" alt="${esc(manga.title||'')}" loading="eager" decoding="async" referrerpolicy="no-referrer"
        onerror="this.classList.add('is-broken');this.parentElement.classList.add('cover-broken')">
      <span class="cover-fallback" ${hasCover?'style="display:none"':''}>${esc(String(manga.title||'').slice(0,55))}</span>`
   : `<span class="cover-fallback">${esc(String(manga.title||'').slice(0,55))}</span>`;

 const rows=[...chapters].sort((a,b)=>compareChapters(b.chapter,a.chapter)).map(c=>{
   const isRead=compareChapters(c.chapter,manga.current_chapter)<=0;
   const isNext=nxt&&Number(nxt.id)===Number(c.id);
   return `<div class="chapter-item ${isRead?'read':''} ${isNext?'next-chapter':''}">
     <button class="chapter-open" data-id="${c.id}">
       <strong>Chapter ${esc(c.chapter)} ${c.title?`— ${esc(c.title)}`:''}${Number(c.user_edited)===1?'<span class="chapter-edited-tag">แก้เอง</span>':''}${isNext?'<span class="next-label">ต่อจากที่อ่าน</span>':''}</strong>
       <small>${isRead?'✓ อ่านแล้ว':'ยังไม่อ่าน'}${c.release_date?' • '+esc(c.release_date):''}</small>
     </button>
     <button class="chapter-edit" data-edit-chapter="${c.id}" title="แก้ไขชื่อตอน/ลิงก์ตอน" aria-label="แก้ไขตอน ${esc(c.chapter)}">✎ แก้ไข</button>
     <button class="chapter-del" data-delete="${c.id}">ลบ</button>
   </div>`;
 }).join('');

 $('detail').innerHTML=`
 <section class="detail-card manga-theme-${mmtThemeFor(manga)}">
   <div class="detail-head">

     <div class="big-cover-wrap">${hasCover&&!isVidCover?`<div class="detail-cover-glow" aria-hidden="true" style="background-image:url(&quot;${esc(coverUrl)}&quot;)"></div>`:''}
     <div class="big-cover ${hasCover?'has-cover':''}">
       ${cover}
       ${u?`<b class="detail-new-badge">＋${u} ตอนใหม่</b>`:''}
       ${hasCover && ratingValue>0 ? `<div class="cover-rating-badge"><span>${ratingStars}</span><b>${ratingValue.toFixed(1)}</b></div>`:''}
     </div></div>

     <div class="detail-info">

       <div class="detail-topline">
         <div class="detail-title-block">
           <div class="detail-labels">
             <div class="category-label ${adult(type)?'adult-label':''}">
               ${esc(typeIcon(type?.name||'')+' '+(type?.name||'ยังไม่จัดประเภท'))}
             </div>
             <div class="completion-status-badge ${manga.completion_status==='completed'?'completed':''}">
               ${completionStatusName(manga.completion_status||'ongoing')}
             </div>
             ${manga.lead_type?`<div class="lead-detail-badge">${esc(leadTypeLabel(manga.lead_type))}</div>`:''}
           </div>

           <h1>${esc(manga.title)}</h1>

           ${manga.alt_title?`<div class="alt-title">${esc(manga.alt_title)}</div>`:''}

           <div class="detail-rating" aria-label="คะแนน ${ratingValue>0?ratingValue:'ยังไม่มีคะแนน'}">
             <span class="detail-rating-stars">${ratingValue>0?ratingStars:esc(ratingStars)}</span>
             <b>${ratingValue>0?ratingValue.toFixed(1):'—'}</b>
             <small>${ratingValue>0?'คะแนนส่วนตัว':'ยังไม่ได้ให้คะแนน'}</small>
           </div>
         </div>

         <div class="detail-actions">
           <button id="favBtn" class="btn ghost ${Number(manga.favorite)?'favorite-active':''}">
             ★ ${Number(manga.favorite)?'รายการโปรด':'เพิ่มโปรด'}
           </button>
           <button id="editBtn" class="btn ghost">✎ แก้ไข</button>
           <button id="deleteBtn" class="btn ghost">🗑 ลบ</button>
           ${manga.completion_card?'<a class="btn ghost" href="index.html#rewards">🏆 การ์ดรางวัล</a>':''}
         </div>
       </div>

       <p>${esc(manga.note||'ติดตามตอนจากเว็บต้นทางและบันทึกความคืบหน้าอัตโนมัติ')}</p>

       <div class="tags">
         ${g.map(x=>`<span>${esc(genreLabel(x))}</span>`).join('')}
       </div>

       <div class="meta-grid">
         <div><span>สถานะ</span><b>${esc(statusName(manga.status))}</b></div>
         <div><span>อ่านถึง</span><b>Chapter ${esc(manga.current_chapter||'0')}</b></div>
         <div><span>ตอนล่าสุด</span><b>${esc(manga.last_chapter||manga.latest_chapter||'-')}</b></div>
         <div><span>ทั้งหมด</span><b>${Number(manga.chapter_count||chapters.length)} Chapter</b></div>
       </div>

       <div class="detail-progress">
         <div class="progress-label"><span>ความคืบหน้า</span><b>${p}%</b></div>
         <div class="progress-track large"><i style="width:${p}%"></i></div>
       </div>

       <div class="read-next">
         ${nxt
           ? `<button id="readNext" class="red big">▶ อ่านต่อ Chapter ${esc(nxt.chapter)}</button>`
           : '<span class="muted read-done">✓ อ่านถึงตอนล่าสุดแล้ว</span>'}
         <button id="syncBtn" class="btn ghost act-btn act-sync"><i>↻</i><span>ซิงก์ Chapter</span></button>
         <button id="browserImportBtn" class="btn ghost act-btn act-import"><i>⚡</i><span>Browser Import</span></button>
         <button id="historyBtn" class="btn ghost act-btn act-history"><i>◷</i><span>ประวัติ</span></button>
         <button id="sourceBtn" class="btn ghost act-btn act-source"><i>↗</i><span>เว็บต้นทาง</span></button>
       </div>

       ${manga.last_read_at?`<div class="last-read-note">อ่านล่าสุด ${esc(timeAgo(manga.last_read_at))}</div>`:''}

     </div>
   </div>

   <div class="chapter-toolbar">
     <div>
       <h2 style="margin:0">Chapters</h2>
       <p style="margin:4px 0 0;color:var(--muted);font-size:12px">${u?`มี ${u} ตอนที่ยังไม่ได้อ่าน`:'คุณอ่านถึงตอนล่าสุดแล้ว'}</p>
     </div>
     <button id="toggleAddChapter" class="btn ghost">＋ เพิ่มตอนเอง</button>
   </div>

   <form id="chapterForm" class="chapter-form hidden">
     <input id="newChapter" required placeholder="35">
     <input id="newChapterTitle" placeholder="ชื่อตอน">
     <input id="newChapterUrl" type="url" required placeholder="https://.../chapter-35">
     <input id="newChapterDate" type="date">
     <button class="red" type="submit">＋ เพิ่มตอน</button>
   </form>

   <div class="chapter-list">${rows||'<div class="empty">ยังไม่มี Chapter ให้แสดง</div>'}</div>
   <div id="history" class="history"></div>
 </section>`;

 document.querySelectorAll('.chapter-open').forEach(b=>b.onclick=()=>{
   const c=chapters.find(x=>Number(x.id)===Number(b.dataset.id));
   if(c)startRead(c);
 });

 document.querySelectorAll('.chapter-edit').forEach(b=>b.onclick=()=>{
   const c=chapters.find(x=>Number(x.id)===Number(b.dataset.editChapter));
   if(c)openChapterEdit(c);
 });

 document.querySelectorAll('.chapter-del').forEach(b=>b.onclick=()=>{
   deleteChapter(Number(b.dataset.delete));
 });

 mmtApplyThemeContrast();$('favBtn').onclick=toggleFav;
 $('editBtn').onclick=openEditModal;
 (function(){const b=$('deleteBtn');let t=null,cancel=null;const reset=()=>{clearTimeout(t);b.classList.remove('delete-armed');b.innerHTML=`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg><span>ลบ</span>`;cancel?.remove();cancel=null};reset();
  b.onclick=()=>{if(b.classList.contains('delete-armed')){clearTimeout(t);deleteManga();return}b.classList.add('delete-armed');b.innerHTML=`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg><span>ยืนยันลบ</span>`;cancel=document.createElement('button');cancel.type='button';cancel.className='btn ghost delete-cancel';cancel.setAttribute('aria-label','ยกเลิกการลบ');cancel.innerHTML=`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`;cancel.onclick=reset;b.after(cancel);t=setTimeout(reset,5000)}})();
 $('syncBtn').onclick=syncNow;

 $('browserImportBtn').onclick=()=>{
   const u=new URL(manga.source_url);
   u.hash=`mymanga_import=${encodeURIComponent(manga.id)}`;
   const a=document.createElement('a');
   a.href=u.toString();
   a.target='_blank';
   a.rel='noopener noreferrer';
   a.referrerPolicy='no-referrer';
   a.click();
 };

 $('historyBtn').onclick=historyShow;
 $('sourceBtn').onclick=()=>{if(!openNoReferrer(manga.source_url))toast('เปิดเว็บต้นทางไม่ได้ กรุณาตรวจสอบ URL',true)};

 const rb=$('readNext');
 if(rb)rb.onclick=()=>startRead(nxt);

 $('toggleAddChapter').onclick=()=>$('chapterForm').classList.toggle('hidden');
 $('chapterForm').onsubmit=addChapter;

 const q=$('chapterSearch');
 if(q){
   q.oninput=()=>{
     const v=q.value.toLowerCase();
     document.querySelectorAll('.chapter-item').forEach(x=>{
       x.style.display=x.innerText.toLowerCase().includes(v)?'flex':'none';
     });
   };
 }
}

document.addEventListener('DOMContentLoaded',async()=>{applyTheme(localStorage.getItem('manga_theme')||'dark');if($('backBtn'))$('backBtn').onclick=()=>history.back();if($('themeBtn'))$('themeBtn').onclick=()=>applyTheme(document.documentElement.dataset.theme==='light'?'dark':'light');if(!mangaId){renderDetailError('ไม่พบรหัสเรื่องใน URL กรุณากลับไปเลือกเรื่องจากคลัง',false);return}renderDetailLoading();try{await reload({timeoutMs:25000})}catch(e){renderDetailError(e.message,true)}});

// --- แผงสถานะ (ชุดเดียวกับหน้าแรก) ---
function clearBackgroundImportTimers(){clearTimeout(window.__backgroundImportHideTimer);clearTimeout(window.__backgroundImportExitTimer);window.__backgroundImportHideTimer=0;window.__backgroundImportExitTimer=0}
function setBackgroundImportPanel({state='downloading',progress=0,title='',detail='',id=0,url='',canBrowser=false,percentLabel=''}={}){
 const panel=$('backgroundImportPanel');if(!panel)return;clearBackgroundImportTimers();panel.classList.remove('is-hiding');panel.hidden=false;panel.dataset.state=state;
 $('backgroundImportTitle').textContent=title;$('backgroundImportDetail').textContent=detail||'';
 $('backgroundImportSymbol').textContent=state==='success'?'✓':state==='error'?'!':state==='partial'?'⚠':'↻';
 $('backgroundImportFill').style.width=`${Math.max(0,Math.min(100,Number(progress)||0))}%`;
 $('backgroundImportPercent').textContent=percentLabel||`${Math.round(progress)}%`;
 const b=$('backgroundImportBrowser');if(b)b.hidden=!canBrowser;
 if(state!=='downloading')window.__backgroundImportHideTimer=setTimeout(()=>hideBackgroundImportPanel(true),state==='success'?5000:9000);
}
function hideBackgroundImportPanel(animate=true){
 const p=$('backgroundImportPanel');if(!p)return;clearBackgroundImportTimers();if(p.hidden)return;
 if(!animate){p.classList.remove('is-hiding');p.hidden=true;return}
 p.classList.add('is-hiding');window.__backgroundImportExitTimer=setTimeout(()=>{p.hidden=true;p.classList.remove('is-hiding')},240);
}

// v17.17.11 — แผงเปอร์เซ็นต์ตอนซิงก์ (ใช้แผงเดียวกับตอนเพิ่มเรื่อง)
// ขั้นตอนจริง: เริ่ม → อ่านเว็บต้นทาง → ตรวจรายการ → บันทึก → เสร็จ  ช่วงรอเว็บตอบจะค่อยๆ ไต่เปอร์เซ็นต์ให้เห็นว่ายังทำงานอยู่
function mmtSyncProgress(title,subtitle){
 let pct=0,timer=0,label='',stage=title,name=subtitle||'',sub='';const detail=()=>name?(sub?`${name} · ${sub}`:name):sub;
 const paint=(state='downloading',extra={})=>setBackgroundImportPanel({state,progress:pct,title:stage,detail:detail(),percentLabel:`${Math.round(pct)}% · ${label}`,...extra});
 const stop=()=>{if(timer){clearInterval(timer);timer=0}};
 return {
  step(p,t,l,d){stop();pct=Math.max(pct,p);if(t)stage=t;if(l)label=l;if(d!==undefined)sub=d;paint()},
  creep(to,t,l,d){stop();if(t)stage=t;if(l)label=l;if(d!==undefined)sub=d;paint();timer=setInterval(()=>{pct+=(to-pct)*.09;paint()},450)},
  done(state,t,d,extra){stop();pct=100;stage=t;if(d!==undefined)sub=d;label=state==='success'?'เสร็จแล้ว':state==='error'?'ไม่สำเร็จ':'เสร็จแล้ว · ควรตรวจสอบ';paint(state,extra||{})},
  hide(){stop();hideBackgroundImportPanel(true)}
 };
}
function mmtSyncResultState(status){return ['partial','unverifiable','review'].includes(status)?'partial':'success'}

(function(){const d=document.getElementById('backgroundImportDismiss');if(d)d.onclick=()=>hideBackgroundImportPanel(true);
 const b=document.getElementById('backgroundImportBrowser');if(b)b.onclick=()=>{const t=document.getElementById('browserImportBtn');if(t)t.click()}})();
