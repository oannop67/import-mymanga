<?php
declare(strict_types=1);
ob_start(); // กัน Warning/Deprecated ของ PHP หลุดไปปนกับ JSON
require __DIR__ . '/config.php';

// MyManga Tracker: force MySQL/PHP to use Thailand time (Asia/Bangkok, UTC+7)
// This keeps TIMESTAMP values such as completion_cards.completed_at aligned with the real Thai date.
date_default_timezone_set('Asia/Bangkok');
try { $pdo->exec("SET time_zone = '+07:00'"); } catch (Throwable $e) {}
ini_set('display_errors', '0');
register_shutdown_function(function () {
  $e = error_get_last();
  if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
    while (ob_get_level()) ob_end_clean();
    if (!headers_sent()) { http_response_code(500); header('Content-Type: application/json; charset=utf-8'); }
    echo json_encode(['ok' => false, 'message' => 'PHP error: ' . $e['message']], JSON_UNESCAPED_UNICODE);
  }
});

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Manga-Token, Authorization');
header('Access-Control-Allow-Methods: POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

function out(array $data, int $status = 200): never {
  while (ob_get_level()) ob_end_clean();
  http_response_code($status);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function body(): array {
  $d = json_decode(file_get_contents('php://input') ?: '{}', true);
  return is_array($d) ? $d : [];
}

function clean(mixed $v, int $max = 1000): string {
  $s = trim((string)$v);
  return function_exists('mb_substr') ? trim(mb_substr($s, 0, $max)) : substr($s, 0, $max);
}

// คะแนน 1–5 เพิ่มทีละ 0.5 (ว่าง/0 = ไม่ให้คะแนน)
function normalizeRating(mixed $v): ?float {
  if ($v === null || $v === '') return null;
  $f = (float)$v;
  if ($f <= 0) return null;
  return max(1.0, min(5.0, round($f * 2) / 2));
}

function numChapter(mixed $v): float {
  return preg_match('/(?<![\p{L}\d])(?:chapter|chap\.?|ch\.?|ตอน(?:ที่)?|episode|ep(?:isode)?\.?)?\s*[#:\-]?\s*(\d+(?:\.\d+)?)/iu', (string)$v, $m) ? (float)$m[1] : 0.0;
}

function chapterLabel(mixed $v): string {
  $s = trim(preg_replace('/\s+/u', ' ', html_entity_decode((string)$v, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
  if (preg_match('/(?<![\p{L}\d])(?:chapter|chap\.?|ch\.?|ตอน(?:ที่)?|episode|ep(?:isode)?\.?)\s*[#:\-]?\s*(\d+(?:\.\d+)?(?:\s*(?:SS|Season|Part)\s*\d+)?)/iu', $s, $m)) return trim($m[1]);
  if (preg_match('/^(?:SS|Season)\s*(\d+)$/iu', $s, $m)) return 'SS' . $m[1];
  // รับเลขเดี่ยว/เลขทศนิยมเฉพาะเมื่อข้อความทั้งก้อนเป็นเลขจริง ๆ
  // เพื่อไม่ให้ยอดวิว/วันที่ที่ติดอยู่กับลิงก์ถูกตีความเป็นเลขตอน
  if (preg_match('/^#?\s*(\d+(?:\.\d+)?(?:\s*(?:SS|Season|Part)\s*\d+)?)$/iu', $s, $m)) return trim($m[1]);
  return '';
}

// Sort chapter labels by major chapter + ordinal part, so 15.10 sorts after 15.2 instead of as decimal 15.1.
function chapterSortOrder(mixed $v): float {
  $s = trim((string)$v);
  if (preg_match('/^(?:SS|Season)\s*(\d+)$/iu', $s, $seasonOnly)) {
    return 1000000000 * max(0, (int)$seasonOnly[1]);
  }
  if (preg_match('/^(\d+)(?:\.(\d+))?(?:\s*(?:SS|Season)\s*(\d+))?$/iu', $s, $m)) {
    $major = (float)$m[1];
    $minor = isset($m[2]) && $m[2] !== '' ? (int)$m[2] : 0;
    $season = isset($m[3]) && $m[3] !== '' ? (int)$m[3] : 0;
    return 1000000000 * max(0, $season) + $major + min(999999, max(0, $minor)) / 1000000;
  }
  return numChapter($v);
}

// v17.17.9 — Sync safety net. Compares what the source returned with the chapters we already hold.
// - overlap: share of OUR existing chapters that the source list also contains (low = scraper mis-parsed / site renumbered)
// - kept/dropped: new labels absurdly far above our latest chapter (e.g. an id like 165005 mistaken for a chapter number) are dropped
function syncSafetyReport(array $existing, float $maxSort, array $scraped): array {
  $have = array_flip(array_map('strval', $existing));
  $n = count($have);
  $labels = [];
  foreach ($scraped as $c) { $l = chapterLabel($c['chapter'] ?? ''); if ($l !== '') $labels[$l] = true; }
  $matched = 0;
  foreach ($have as $l => $_) { if (isset($labels[(string)$l])) $matched++; }
  $kept = []; $dropped = [];
  foreach ($scraped as $c) {
    $l = chapterLabel($c['chapter'] ?? '');
    if ($l !== '' && $n > 0 && !isset($have[$l]) && $maxSort > 0) {
      $so = chapterSortOrder($l);
      if ($so < 1000000000 && $so > $maxSort + 30) { $dropped[] = $l; continue; }
    }
    $kept[] = $c;
  }
  return ['existing_count' => $n, 'matched' => $matched, 'overlap' => $n > 0 ? $matched / $n : 1.0, 'kept' => $kept, 'dropped' => $dropped];
}

function syncExistingChapters(PDO $pdo, int $mangaId): array {
  $q = $pdo->prepare('SELECT chapter,sort_order FROM chapters WHERE manga_id=?');
  $q->execute([$mangaId]);
  $labels = []; $max = 0.0;
  foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) { $labels[] = (string)$r['chapter']; $max = max($max, (float)$r['sort_order']); }
  return [$labels, $max];
}

function chapterLabelFromUrl(string $url, string $baseUrl = ''): string {
  $p = parse_url($url);
  if (!$p) return '';
  $path = rawurldecode((string)($p['path'] ?? ''));
  $basePath = rtrim(rawurldecode((string)(parse_url($baseUrl)['path'] ?? '')), '/');
  $host = strtolower((string)($p['host'] ?? ''));

  // Site-specific URL rules first: these are more trustworthy than visible text,
  // which often contains views, dates, badges, or END/VIP markers.
  if ($basePath !== '') {
    if (str_contains($host, 'toonbun.com')) {
      if (preg_match('~^' . preg_quote($basePath, '~') . '/episode/(\d+(?:\.\d+)?)$~iu', rtrim($path, '/'), $m)) {
        return $m[1];
      }
    }
    if (str_contains($host, 'divetoon.com')) {
      if (preg_match('~^' . preg_quote($basePath, '~') . '/(\d+(?:\.\d+)?)$~', rtrim($path, '/'), $m)) {
        return $m[1];
      }
    }

    // Generic exact child URL: /content/slug/102 or /content/slug/69.5
    if (str_starts_with(strtolower(rtrim($path, '/')), strtolower($basePath) . '/')) {
      $tail = trim(substr(rtrim($path, '/'), strlen($basePath)), '/');
      if (preg_match('/^(\d+(?:\.\d+)?)$/', $tail, $m)) return $m[1];
      if (preg_match('/^(?:chapter|chap|ch|episode|ep)[-_]?(\d+(?:\.\d+)?)$/iu', $tail, $m)) return $m[1];
      // Also allow one known chapter segment: /.../episode/102
      if (preg_match('/^(?:chapter|chap|ch|episode|ep)\/(\d+(?:\.\d+)?)$/iu', $tail, $m)) return $m[1];
    }
  }

  // Madara/WordPress style slugs: /manga/x/chapter-26/ , /x-chapter-26-5/ , /ch_12 (26-5 => 26.5)
  if (preg_match('~(?:^|[/_-])(?:chapter|chap|ch|episode|ep)[-_]?(\d+)(?:[-_](\d{1,2}))?$~iu', rtrim($path, '/'), $m)) {
    return $m[1] . (isset($m[2]) && $m[2] !== '' ? '.' . $m[2] : '');
  }
  // Generic chapter-like URLs on other sites.
  if (preg_match('~/(?:chapter|chap|ch|episode|ep)[-_]?(\d+(?:\.\d+)?)$~iu', rtrim($path, '/'), $m)) return $m[1];
  if (preg_match('~/(?:SS|Season)[-_]?(\d+)$~iu', rtrim($path, '/'), $m)) return 'SS' . $m[1];
  if (isset($p['query'])) {
    parse_str((string)$p['query'], $q);
    foreach (['chapter','chap','ch','episode','ep'] as $key) {
      if (isset($q[$key]) && preg_match('/^\d+(?:\.\d+)?$/', (string)$q[$key])) return (string)$q[$key];
    }
  }
  return '';
}

function stripFragment(string $url): string {
  $p = parse_url($url);
  if (!$p) return $url;
  unset($p['fragment']);
  $s = ($p['scheme'] ?? '') . '://' . ($p['host'] ?? '') . (isset($p['port']) ? ':' . $p['port'] : '') . ($p['path'] ?? '');
  if (isset($p['query'])) $s .= '?' . $p['query'];
  return $s;
}

function canon(string $url): string {
  return rtrim(stripFragment(trim($url)), '/');
}

function absUrl(string $base, string $href): string {
  $href = trim(html_entity_decode($href, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
  if ($href === '' || str_starts_with($href, '#') || preg_match('~^(javascript:|mailto:|tel:)~i', $href)) return '';
  if (preg_match('~^https?://~i', $href)) return canon($href);
  $bp = parse_url($base);
  if (!$bp) return '';
  $scheme = $bp['scheme'] ?? 'https';
  $host = $bp['host'] ?? '';
  $port = isset($bp['port']) ? ':' . $bp['port'] : '';
  if (str_starts_with($href, '//')) return canon($scheme . ':' . $href);
  if (str_starts_with($href, '?')) {
    // Query-only hrefs like ?page=2 retain the listing path; dirname() would wrongly move them to '/'.
    return canon($scheme . '://' . $host . $port . ((string)($bp['path'] ?? '/')) . $href);
  }
  $path = $bp['path'] ?? '/';
  $path = str_starts_with($href, '/') ? $href : rtrim(dirname($path), '/') . '/' . $href;
  $parts = [];
  foreach (explode('/', $path) as $part) {
    if ($part === '' || $part === '.') continue;
    if ($part === '..') array_pop($parts);
    else $parts[] = $part;
  }
  return canon($scheme . '://' . $host . $port . '/' . implode('/', $parts));
}

function requireToken(string $configured, array $payload = []): void {
  $provided = (string)($_SERVER['HTTP_X_MANGA_TOKEN'] ?? '');
  if ($provided === '') {
    $auth = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) $provided = trim($m[1]);
  }
  if ($provided === '') $provided = trim((string)($payload['token'] ?? ''));
  if ($provided === '' && isset($_GET['token'])) $provided = trim((string)$_GET['token']);
  if ($provided === '' || $configured === '' || $configured === 'CHANGE_ME_LONG_SECRET_TOKEN' || !hash_equals($configured, $provided)) {
    out(['ok' => false, 'message' => 'ไม่ได้รับอนุญาต'], 401);
  }
}

function safeRemote(string $url): string {
  if (!filter_var($url, FILTER_VALIDATE_URL)) out(['ok' => false, 'message' => 'URL ไม่ถูกต้อง'], 422);
  $p = parse_url($url);
  $scheme = strtolower((string)($p['scheme'] ?? ''));
  $host = strtolower((string)($p['host'] ?? ''));
  if (!in_array($scheme, ['http', 'https'], true) || $host === '') out(['ok' => false, 'message' => 'รองรับเฉพาะ http/https'], 422);
  if (in_array($host, ['localhost', '127.0.0.1', '::1'], true) || str_ends_with($host, '.local')) out(['ok' => false, 'message' => 'ไม่อนุญาต URL ภายในเครื่อง'], 422);
  return stripFragment($url);
}

function extractMangaSlug(string $url): string {
  $path = strtolower(trim((string)(parse_url($url)['path'] ?? ''), '/'));
  $parts = array_values(array_filter(explode('/', $path)));
  if (empty($parts)) return '';
  $generic = ['manga', 'series', 'comic', 'read', 'book', 'toon', 'webtoon', 'novel', 'chapter', 'episodes', 'episode'];
  $slug = end($parts);
  if (in_array($slug, $generic, true) && count($parts) > 1) {
    $slug = $parts[count($parts) - 2];
  }
  return rawurldecode($slug);
}

// Manghaha catalog pagination: the query parameter ?page=N is a list page, NOT a chapter number.
function normalizedHost(string $host): string {
  return preg_replace('/^www\\./i', '', strtolower(trim($host))) ?? strtolower(trim($host));
}

function isManghahaHost(string $host): bool {
  $host = normalizedHost($host);
  return $host === 'manghaha.com' || str_ends_with($host, '.manghaha.com');
}

function catalogPageInfo(string $url): ?array {
  $p = parse_url($url);
  if (!$p) return null;
  $query = [];
  parse_str((string)($p['query'] ?? ''), $query);
  foreach (['page', 'paged', 'pageno', 'page_no', 'page_num', 'pagenum', 'pg'] as $key) {
    if (!isset($query[$key]) || !is_scalar($query[$key])) continue;
    $value = trim((string)$query[$key]);
    if ($value !== '' && ctype_digit($value) && (int)$value >= 1 && (int)$value <= 10000) {
      return ['key' => $key, 'number' => (int)$value, 'query' => $query];
    }
  }
  return null;
}

function sameManghahaSeriesPath(string $url, string $seriesUrl): bool {
  $a = parse_url($url); $b = parse_url($seriesUrl);
  if (!$a || !$b) return false;
  if (!isManghahaHost((string)($a['host'] ?? '')) || normalizedHost((string)($a['host'] ?? '')) !== normalizedHost((string)($b['host'] ?? ''))) return false;
  $pathA = strtolower(rtrim(rawurldecode((string)($a['path'] ?? '/')), '/'));
  $pathB = strtolower(rtrim(rawurldecode((string)($b['path'] ?? '/')), '/'));
  return $pathA !== '' && $pathA === $pathB;
}

function isManghahaCatalogPageUrl(string $url, string $seriesUrl): bool {
  return sameManghahaSeriesPath($url, $seriesUrl) && catalogPageInfo($url) !== null;
}

function buildCatalogPageUrl(string $seriesUrl, string $pageKey, int $pageNumber): string {
  $p = parse_url($seriesUrl);
  if (!$p) return $seriesUrl;
  $query = [];
  parse_str((string)($p['query'] ?? ''), $query);
  $query[$pageKey !== '' ? $pageKey : 'page'] = max(1, $pageNumber);
  $scheme = (string)($p['scheme'] ?? 'https');
  $host = (string)($p['host'] ?? '');
  $port = isset($p['port']) ? ':' . $p['port'] : '';
  $path = (string)($p['path'] ?? '/');
  return $scheme . '://' . $host . $port . $path . '?' . http_build_query($query);
}

function discoverManghahaCatalogPages(string $html, string $currentUrl, string $seriesUrl): array {
  $pages = [];
  if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) return $pages;
  libxml_use_internal_errors(true);
  $dom = new DOMDocument();
  @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
  $xp = new DOMXPath($dom);
  foreach ($xp->query('//a[@href]') as $a) {
    $href = absUrl($currentUrl, (string)$a->getAttribute('href'));
    if ($href === '' || !isManghahaCatalogPageUrl($href, $seriesUrl)) continue;
    $info = catalogPageInfo($href);
    if (!$info) continue;
    $number = (int)$info['number'];
    if ($number >= 1 && $number <= 10000 && !isset($pages[$number])) $pages[$number] = $href;
  }
  ksort($pages, SORT_NUMERIC);
  return $pages;
}

function manghahaChapterKey(string $label): string {
  $label = trim($label);
  if (preg_match('/^0*(\\d+)(?:\\.(\\d+))?$/', $label, $m)) {
    return (string)(int)$m[1] . (isset($m[2]) && $m[2] !== '' ? '.' . $m[2] : '');
  }
  return strtolower($label);
}

function mergeManghahaChapterRows(array $base, array $more, string $seriesUrl): array {
  $byLabel = [];
  foreach (array_merge($base, $more) as $row) {
    if (!is_array($row)) continue;
    $label = chapterLabel($row['chapter'] ?? '');
    $url = canon((string)($row['chapter_url'] ?? ''));
    if ($label === '' || $url === '' || isManghahaCatalogPageUrl($url, $seriesUrl)) continue;
    $key = manghahaChapterKey($label);
    if ($key === '') continue;
    $candidate = $row;
    $candidate['chapter'] = $label;
    $candidate['chapter_url'] = $url;
    $candidate['sort_order'] = chapterSortOrder($label);
    if (!isset($byLabel[$key])) {
      $byLabel[$key] = $candidate;
      continue;
    }
    // Prefer a title/URL from a real chapter link over a sparse placeholder.
    $oldUrl = (string)($byLabel[$key]['chapter_url'] ?? '');
    $oldTitle = trim((string)($byLabel[$key]['title'] ?? ''));
    $newTitle = trim((string)($candidate['title'] ?? ''));
    if (($oldTitle === '' || preg_match('/^(?:chapter|ตอนที่)\\s*' . preg_quote($byLabel[$key]['chapter'], '/') . '$/iu', $oldTitle)) && $newTitle !== '') {
      $byLabel[$key] = $candidate;
    } elseif ($oldUrl === '' && $url !== '') {
      $byLabel[$key] = $candidate;
    }
  }
  $rows = array_values($byLabel);
  usort($rows, fn($a, $b) => ((float)($a['sort_order'] ?? 0) <=> (float)($b['sort_order'] ?? 0)) ?: strcasecmp((string)$a['chapter'], (string)$b['chapter']));
  return $rows;
}

function expandManghahaCatalogPages(string $html, string $baseUrl, array $initial): array {
  $startInfo = catalogPageInfo($baseUrl);
  $startPage = $startInfo ? (int)$startInfo['number'] : 1;
  $pageKey = $startInfo ? (string)$startInfo['key'] : 'page';
  $declaredTotal = chapterTotalFromHtml($html);
  $chapters = mergeManghahaChapterRows([], $initial, $baseUrl);
  $pageUrls = [$startPage => $baseUrl];
  foreach (discoverManghahaCatalogPages($html, $baseUrl, $baseUrl) as $number => $url) {
    $pageUrls[(int)$number] = $url;
    $info = catalogPageInfo($url);
    if ($info) $pageKey = (string)$info['key'];
  }
  $hasPagination = $startInfo !== null || count($pageUrls) > 1;
  if (!$hasPagination) {
    return ['handled' => false, 'chapters' => $chapters, 'total' => $declaredTotal, 'catalog_complete' => false, 'catalog_pages_scanned' => 0];
  }

  $visited = [$startPage => true];
  $failed = false;
  $fetchLimit = 35;
  $deadline = microtime(true) + 26.0;
  $capReached = false;

  while (microtime(true) < $deadline && count($visited) < $fetchLimit) {
    $knownNumbers = array_map('intval', array_keys($pageUrls));
    $maxKnown = $knownNumbers ? max($knownNumbers) : $startPage;
    if ($maxKnown > $fetchLimit) $capReached = true;
    $maxPage = min($fetchLimit, max(1, $maxKnown));
    for ($n = 1; $n <= $maxPage; $n++) {
      if (!isset($pageUrls[$n])) $pageUrls[$n] = buildCatalogPageUrl($baseUrl, $pageKey, $n);
    }
    $nextPage = null;
    for ($n = 1; $n <= $maxPage; $n++) {
      if (empty($visited[$n])) { $nextPage = $n; break; }
    }
    if ($nextPage === null) break;
    $url = (string)($pageUrls[$nextPage] ?? buildCatalogPageUrl($baseUrl, $pageKey, $nextPage));
    try {
      [$pageHtml, $finalUrl] = fetchHtml($url, 'GET', [], 8, 3);
      $effectiveUrl = $finalUrl ?: $url;
      $effectivePageInfo = catalogPageInfo($effectiveUrl);
      if (!sameManghahaSeriesPath($effectiveUrl, $baseUrl) || !$effectivePageInfo || (int)$effectivePageInfo['number'] !== $nextPage) {
        // If the host redirects/strips ?page=N, do not declare the catalog complete.
        $failed = true;
        $visited[$nextPage] = true;
        continue;
      }
      $dom = new DOMDocument();
      @$dom->loadHTML('<?xml encoding="UTF-8">' . $pageHtml, LIBXML_NOERROR | LIBXML_NOWARNING);
      $xp = new DOMXPath($dom);
      $pageRows = extractChaptersFromXpath($xp, $baseUrl, extractMangaSlug($baseUrl), strtolower((string)(parse_url($baseUrl, PHP_URL_HOST) ?? '')));
      $beforePageCount = count($chapters);
      $chapters = mergeManghahaChapterRows($chapters, $pageRows, $baseUrl);
      if (count($chapters) === $beforePageCount) $failed = true; // repeated/default page or no parseable chapter links
      foreach (discoverManghahaCatalogPages($pageHtml, $effectiveUrl, $baseUrl) as $number => $pageHref) {
        $number = (int)$number;
        if (!isset($pageUrls[$number]) || $number === $nextPage) $pageUrls[$number] = $pageHref;
        $info = catalogPageInfo($pageHref);
        if ($info) $pageKey = (string)$info['key'];
      }
      $visited[$nextPage] = true;
    } catch (Throwable $e) {
      $failed = true;
      $visited[$nextPage] = true;
    }
  }

  $knownNumbers = array_map('intval', array_keys($pageUrls));
  $maxKnown = $knownNumbers ? max($knownNumbers) : 1;
  if ($maxKnown > $fetchLimit) $capReached = true;
  $complete = !$failed && !$capReached && $maxKnown > 1;
  for ($n = 1; $n <= min($fetchLimit, $maxKnown); $n++) {
    if (empty($visited[$n])) { $complete = false; break; }
  }
  $chapters = normalizeChapterRows($chapters, $baseUrl);
  if ($complete && count($chapters) > 0) {
    // A complete traversal of every linked catalog page is our reliable count for this adapter.
    $total = count($chapters);
  } else {
    // Do not guess chapter numbers from the pagination index when a page is missing/blocked.
    $total = $declaredTotal > count($chapters) ? $declaredTotal : 0;
  }
  return [
    'handled' => true,
    'chapters' => $chapters,
    'total' => $total,
    'catalog_complete' => $complete,
    'catalog_pages_scanned' => count($visited),
  ];
}

function cleanTitle(string $t): string {
  $t = trim(html_entity_decode($t, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
  $t = preg_replace('/\s*(?:[-|•]\s*)?(?:NTR[- ]?Manga|ReadToon).*$/iu', '', $t);
  return trim((string)preg_replace('/\s+/u', ' ', $t));
}

function fetchHtml(string $url, string $method = 'GET', array $postData = [], int $timeoutSeconds = 30, int $connectTimeoutSeconds = 12): array {
  $GLOBALS['MMT_FETCH_PAGE_COUNT'] = (int)($GLOBALS['MMT_FETCH_PAGE_COUNT'] ?? 0) + 1;
  $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36';
  $last = '';
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    $opts = [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_MAXREDIRS => 8,
      CURLOPT_CONNECTTIMEOUT => max(1, $connectTimeoutSeconds),
      CURLOPT_TIMEOUT => max(2, $timeoutSeconds),
      CURLOPT_USERAGENT => $ua,
      CURLOPT_ENCODING => '',
      CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language: th,en;q=0.9']
    ];
    if (strtoupper($method) === 'POST') {
      $opts[CURLOPT_POST] = true;
      $opts[CURLOPT_POSTFIELDS] = http_build_query($postData);
    }
    curl_setopt_array($ch, $opts);
    $html = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $last = curl_error($ch);
    curl_close($ch);
    if (is_string($html) && $html !== '' && $code < 400) return [$html, $final ?: $url, $code];
    if (in_array($code, [403, 429], true)) throw new RuntimeException("เว็บต้นทางปฏิเสธคำขออัตโนมัติ (HTTP {$code})");
  }
  if (strtoupper($method) === 'GET' && filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) {
    $ctx = stream_context_create(['http' => ['method' => 'GET', 'header' => "User-Agent: {$ua}\r\nAccept: text/html\r\nAccept-Language: th,en;q=0.9\r\n", 'timeout' => max(2, $timeoutSeconds), 'follow_location' => 1, 'max_redirects' => 7]]);
    $html = @file_get_contents($url, false, $ctx);
    if (is_string($html) && $html !== '') return [$html, $url, 200];
  }
  throw new RuntimeException($last !== '' ? $last : 'ดึงหน้าเว็บต้นทางไม่สำเร็จ');
}

function extractChaptersFromXpath(DOMXPath $xp, string $baseUrl, string $mangaSlug, string $host): array {
  $anchors = $xp->query('//a[@href]');
  $chs = [];
  $seen = [];
  $basePath = strtolower(rtrim((string)(parse_url($baseUrl)['path'] ?? ''), '/'));
  $isDiveToon = str_contains($host, 'divetoon.com');
  $isToonbun = str_contains($host, 'toonbun.com');

  foreach ($anchors as $a) {
    $rawHref = (string)$a->getAttribute('href');
    $href = absUrl($baseUrl, $rawHref);
    if ($href === '') continue;

    $hrefHost = strtolower((string)(parse_url($href)['host'] ?? ''));
    if (normalizedHost($hrefHost) !== normalizedHost($host)) continue;
    // On Manghaha, ?page=1, ?page=2, ... are catalog pagination, not Chapter 1 / Chapter 2.
    if (isManghahaCatalogPageUrl($href, $baseUrl)) continue;

    $uPath = strtolower(rawurldecode((string)(parse_url($href)['path'] ?? '')));
    if ($isDiveToon && !preg_match('~^' . preg_quote($basePath, '~') . '/\d+(?:\.\d+)?/?$~i', $uPath)) continue;
    if ($isToonbun && !preg_match('~^' . preg_quote($basePath, '~') . '/episode/\d+(?:\.\d+)?/?$~i', $uPath)) continue;
    if ($uPath === '' || $uPath === $basePath || $uPath === $basePath . '/') continue;

    $isDirectChild = str_starts_with($uPath, $basePath . '/');
    $containsSlug = ($mangaSlug !== '' && str_contains($uPath, $mangaSlug));

    $inChapterContainer = false;
    $anc = $a;
    for ($i = 0; $i < 6 && $anc; $i++, $anc = $anc->parentNode) {
      if (!($anc instanceof DOMElement)) continue;
      $cls = strtolower($anc->getAttribute('class') . ' ' . $anc->getAttribute('id'));
      if (preg_match('/version-chap|wp-manga-chapter|listing-chapters_wrap|chapter-list|chapterlist|eplister|chap/i', $cls)) {
        $inChapterContainer = true;
        break;
      }
    }

    if (!$isDirectChild && !$containsSlug && !$inChapterContainer) {
      continue;
    }

    if (!$inChapterContainer) {
      $isExcluded = false;
      $anc = $a;
      for ($i = 0; $i < 6 && $anc; $i++, $anc = $anc->parentNode) {
        if (!($anc instanceof DOMElement)) continue;
        $cls = strtolower($anc->getAttribute('class') . ' ' . $anc->getAttribute('id') . ' ' . $anc->tagName);
        if (preg_match('/\b(related|recommend|recommended|popular|hot|footer|sidebar|comment|menu|header|navigation|nav|widget|trending|similar)\b/i', $cls)) {
          $isExcluded = true;
          break;
        }
      }
      if ($isExcluded) continue;
    }

    $txt = trim(preg_replace('/\s+/u', ' ', (string)$a->textContent));
    // ให้ URL เป็นแหล่งจริงของเลขตอนก่อนอ่านข้อความในปุ่ม/การ์ด
    // เพราะหลายเว็บใส่ยอดวิว/วันที่/Badge ต่อท้ายลิงก์ เช่น "ตอน 6 • 607"
    // ถ้าอ่าน textContent อย่างเดียวอาจได้เลขตอนผิดเป็น 607
    $label = chapterLabelFromUrl($href, $baseUrl);
    if ($label === '' && $isDirectChild) {
      $tail = trim(substr($uPath, strlen($basePath)), '/');
      if (preg_match('/^\d+(?:\.\d+)?$/', $tail)) $label = $tail;
    }
    if ($label === '') $label = chapterLabel($txt);
    if ($label === '') {
      $label = chapterLabel(str_replace(['/','-'], ' ', $uPath));
    }
    if ($label === '') continue;

    $n = numChapter($label);
    $key = strtolower($label) . '|' . canon($href);
    if (isset($seen[$key])) continue;
    $seen[$key] = 1;

    $chs[] = [
      'chapter' => $label,
      'title' => (function () use ($txt, $label): string {
        $ti = $txt !== '' ? cleanChapterTitle($txt, $label) : '';
        return ($ti !== '' && strlen($ti) < 100) ? $ti : 'Chapter ' . $label;
      })(),
      'chapter_url' => canon($href),
      'sort_order' => chapterSortOrder($label)
    ];
  }

  return $chs;
}


// ---- v12.2: อ่านจำนวนตอนจากหน้าที่ React/Next.js เรนเดอร์ และเติมตอนที่ถูกซ่อนไว้หลังปุ่ม "แสดงอีก N ตอน" ----
function pageTextForCounts(string $html): string {
  $t = preg_replace('~<(script|style|noscript)\b[^>]*>.*?</\1>~is', ' ', $html);
  $t = preg_replace('~<!--.*?-->~s', '', (string)$t); // React ใส่ <!-- --> คั่นระหว่างข้อความ เช่น (<!-- -->72<!-- -->)
  $t = preg_replace('~<[^>]+>~', ' ', (string)$t);
  $t = html_entity_decode((string)$t, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  return trim((string)preg_replace('/\s+/u', ' ', $t));
}

function chapterMoreCountFromHtml(string $html): int {
  $text = pageTextForCounts($html);
  if (preg_match('/(?:แสดงอีก|ดูเพิ่มอีก|โหลดเพิ่มอีก|show\s+(?:more|another)|load\s+more)\s*(\d{1,4})\s*(?:ตอน|chapters?|episodes?|eps?\b)/iu', $text, $m)) {
    return (int)$m[1];
  }
  return 0;
}

// ตัดข้อความ "4 วันที่แล้ว / ล็อกสำหรับ VIP" ที่ติดมากับลิงก์ตอน เหลือ "ตอนที่ N"
// ถ้ามีข้อความอื่นเหลืออยู่ (อาจเป็นชื่อตอนจริง) จะคงของเดิมไว้
function cleanChapterTitle(string $txt, string $label): string {
  $t = trim((string)preg_replace('/\s+/u', ' ', html_entity_decode($txt, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
  if ($t === '' || $label === '') return $t;

  $q = preg_quote($label, '/');
  // Remove the chapter label itself, then strip common source metadata.
  $rest = preg_replace('/.*?(?:ตอน\s*ที่?|chapter|chap\.?|ch\.?|episode|ep\.?)[\s#:\-]*' . $q . '/iu', ' ', $t, 1);
  if ($rest === null) $rest = $t;
  $rest = trim((string)$rest);

  // Toonbun/DiveToon commonly concatenate title + date + status without separators.
  $rest = preg_replace('/\bEND\b/iu', ' ', (string)$rest);
  $rest = preg_replace('/\b(?:VIP|NC|HD|HOT|NEW)\b/iu', ' ', (string)$rest);
  $rest = preg_replace('/\b\d{1,2}\s*(?:ม\.ค\.|ก\.พ\.|มี\.ค\.|เม\.ย\.|พ\.ค\.|มิ\.ย\.|ก\.ค\.|ส\.ค\.|ก\.ย\.|ต\.ค\.|พ\.ย\.|ธ\.ค\.)\s*\d{4}\b/u', ' ', (string)$rest);
  $rest = preg_replace('/\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b/', ' ', (string)$rest);
  $rest = preg_replace('/\b\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2}\b/', ' ', (string)$rest);
  $rest = preg_replace('/\d+\s*(?:วินาที|นาที|ชั่วโมง|วัน|สัปดาห์|เดือน|ปี)\s*(?:ที่แล้ว)?/u', ' ', (string)$rest);
  $rest = preg_replace('/\b\d+(?:\.\d+)?[KMB]?\b/iu', ' ', (string)$rest);
  $rest = trim((string)preg_replace('/[\s·•|+\-–—:()\[\]{}]+/u', ' ', (string)$rest));
  $rest = trim((string)preg_replace('/\s+/u', ' ', (string)$rest));

  // If what remains is only metadata/noise, use a stable canonical title.
  $noise = preg_replace('/[\d\s\.,]+/u', '', $rest);
  $noise = preg_replace('/(?:ตอน|chapter|chap|episode|ep|ที่แล้ว|วันที่|เดือน|ปี|มิ\.ย|ก\.ย|ต\.ค|พ\.ย|ธ\.ค|ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|ก\.ค|ส\.ค)\.?/iu', '', (string)$noise);
  if ($rest === '' || trim((string)$noise) === '') {
    return preg_match('/ตอน/u', $t) ? 'ตอนที่ ' . $label : 'Chapter ' . $label;
  }

  return $rest;
}

// การดึงข้อมูลจากเว็บต้นทางใช้เวลานาน ระหว่างนั้นการเชื่อมต่อ MySQL ที่เปิดไว้ตอนต้นอาจถูกเซิร์ฟเวอร์ตัดทิ้ง
// (SQLSTATE 2006 "MySQL server has gone away") จึงตรวจและต่อใหม่ก่อนเขียนฐานข้อมูล
// ซิงก์: ดึงหน้าเว็บต้นทางรอบเดียวต่อเรื่อง — sync_preview เก็บผลไว้ชั่วคราว 10 นาที แล้ว sync_manga (use_preview) ใช้ต่อ
// ถ้าโฮสต์เขียนไฟล์ชั่วคราวไม่ได้หรือแคชหมดอายุ จะดึงใหม่ตามปกติ (ปลอดภัย ผลลัพธ์เหมือนเดิม)
function syncScrapeCacheFile(string $source): string {
  return rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'mymanga_scrape_' . md5('v17.6.4|' . $source) . '.json';
}
function syncScrapeCached(string $source, bool $store, bool $useCache): array {
  $file = syncScrapeCacheFile($source);
  if ($useCache && is_file($file) && (time() - (int)@filemtime($file)) < 600) {
    $raw = @file_get_contents($file);
    $arr = (is_string($raw) && $raw !== '') ? json_decode($raw, true) : null;
    @unlink($file);
    if (is_array($arr) && isset($arr['chapters']) && is_array($arr['chapters']) && count($arr['chapters']) > 0) return $arr;
  }
  $imp = scrape($source);
  if ($store && is_array($imp)) {
    $json = json_encode($imp, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if (is_string($json) && $json !== '') @file_put_contents($file, $json, LOCK_EX);
  }
  return $imp;
}

function ensureDbAlive(PDO $pdo): PDO {
  try {
    $pdo->query('SELECT 1');
    return $pdo;
  } catch (Throwable $e) {
    global $host, $db, $user, $pass;
    return new PDO("mysql:host={$host};dbname={$db};charset=utf8mb4", $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
  }
}

function isTransientDbError(Throwable $e): bool {
  $m=strtolower($e->getMessage());
  return str_contains($m,'mysql server has gone away') || str_contains($m,'server has gone away') || str_contains($m,'lost connection') || str_contains($m,'error while sending query') || str_contains($m,'packets out of order') || str_contains($m,'2006') || str_contains($m,'2013');
}

// ตรวจว่าหน้าตอนเลข $n มีจริง: เปิดได้, ไม่ถูกเด้งไปหน้าอื่น, ไม่ใช่หน้า "ไม่พบ" และในหน้ามีเลขตอนนั้น
function chapterPageExists(string $baseUrl, array $pattern, int $n): int {
  $url = numericChapterUrl($baseUrl, $pattern, $n);
  try {
    [$pageHtml, $final] = fetchHtml($url);
  } catch (Throwable $e) {
    return 0;
  }
  $want = strtolower(rtrim((string)parse_url($url, PHP_URL_PATH), '/'));
  $got = strtolower(rtrim((string)parse_url((string)$final, PHP_URL_PATH), '/'));
  if ($got !== '' && $got !== $want) return 0;
  $text = pageTextForCounts($pageHtml);
  if (preg_match('/(?:ไม่พบ(?:หน้า|ตอน|เนื้อหา)|page\s*not\s*found|404\s*(?:not\s*found|error))/iu', mb_substr($text, 0, 800))) return 0;
  return preg_match('/(?:ตอน(?:ที่)?|chapter|chap\.?|ch\.?|episode|ep\.?)\s*' . $n . '(?!\d|\.\d)/iu', $text) ? 2 : 1;
}

// เติมตอนที่หายไปสำหรับเว็บที่ใช้ URL เลขตอนเรียงกัน เช่น /content/ชื่อเรื่อง/48
function chapterPageExistsLabel(string $baseUrl, array $pattern, string $label): int {
  $url = numericChapterUrl($baseUrl, $pattern, $label);
  try {
    [$pageHtml, $final] = fetchHtml($url);
  } catch (Throwable $e) {
    return 0;
  }
  $want = strtolower(rtrim((string)parse_url($url, PHP_URL_PATH), '/'));
  $got = strtolower(rtrim((string)parse_url((string)$final, PHP_URL_PATH), '/'));
  if ($got !== '' && $got !== $want) return 0;
  $text = pageTextForCounts($pageHtml);
  if (preg_match('/(?:ไม่พบ(?:หน้า|ตอน|เนื้อหา)|page\s*not\s*found|404\s*(?:not\s*found|error))/iu', mb_substr($text, 0, 800))) return 0;
  $quoted = preg_quote($label, '/');
  return preg_match('/(?:ตอน(?:ที่)?|chapter|chap\.?|ch\.?|episode|ep(?:isode)?\.?)\s*' . $quoted . '(?!\d)/iu', $text) ? 2 : 1;
}

// เติมตอนที่หายไปสำหรับซีรีส์ที่ใช้เลขย่อย เช่น 4.1, 4.2, 5.1, 5.2 ...
// เว็บ DiveToon ใช้รูปแบบนี้และซ่อนตอนเก่าไว้หลังปุ่ม "แสดงอีก N ตอน"
function completeDecimalPatternChapters(array $chapters, string $baseUrl, array $pattern, int $total): array {
  if ($total <= 0 || !$chapters) return [];
  $seen = [];
  $majors = [];
  $suffixes = [];
  foreach ($chapters as $c) {
    $label = trim((string)($c['chapter'] ?? ''));
    if (!preg_match('/^(\d+)\.(\d+)$/', $label, $m)) continue;
    $major = (int)$m[1];
    $suffix = (int)$m[2];
    $seen[$label] = true;
    $majors[$major] = true;
    $suffixes[$suffix] = true;
  }
  if (count($suffixes) < 2 || count($majors) < 2) return [];
  $suffixes = array_keys($suffixes);
  sort($suffixes, SORT_NUMERIC);
  $maxMajor = max(array_keys($majors));
  $perMajor = count($suffixes);
  $startMajor = max(1, $maxMajor - (int)ceil($total / $perMajor) + 1);

  $candidates = [];
  for ($major = $startMajor; $major <= $maxMajor; $major++) {
    foreach ($suffixes as $suffix) {
      $label = $major . '.' . $suffix;
      if (!isset($seen[$label])) $candidates[] = $label;
    }
  }
  $need = max(0, $total - count($chapters));
  if ($need <= 0) return [];
  $candidates = array_slice($candidates, 0, min($need, 120));

  $rows = [];
  foreach ($candidates as $label) {
    $score = chapterPageExistsLabel($baseUrl, $pattern, $label);
    if ($score === 2 || ($score === 1 && str_contains(strtolower((string)(parse_url($baseUrl)['host'] ?? '')), 'divetoon'))) {
      $rows[] = [
        'chapter' => $label,
        'title' => 'Chapter ' . $label,
        'chapter_url' => numericChapterUrl($baseUrl, $pattern, $label),
        'sort_order' => chapterSortOrder($label),
      ];
    }
    if (count($rows) >= $need) break;
  }
  return $rows;
}

function completeNumericChapters(array $chapters, string $baseUrl, array $pattern, int $total): array {
  $have = [];
  $highest = 0.0;
  $thai = false;
  foreach ($chapters as $c) {
    $n = numChapter($c['chapter'] ?? '');
    if ($n > $highest) $highest = $n;
    if ($n >= 0 && floor($n) == $n) $have[(int)$n] = true;
    if (!$thai && preg_match('/ตอนที่/u', (string)($c['title'] ?? ''))) $thai = true;
  }
  $top = (int)floor($highest);
  if ($top < 1 || $top > 5000) return [];

  $missing = [];
  for ($i = 1; $i <= $top; $i++) {
    if (!isset($have[$i])) $missing[] = $i;
  }
  $expected = count($chapters) + count($missing);
  $zeroMissing = !isset($have[0]);

  $makeRow = function (int $i) use ($baseUrl, $pattern, $thai): array {
    return [
      'chapter' => (string)$i,
      'title' => ($thai ? 'ตอนที่ ' : 'Chapter ') . $i,
      'chapter_url' => numericChapterUrl($baseUrl, $pattern, $i),
      'sort_order' => (float)$i,
    ];
  };

  // จำนวนที่นับได้ตรงกับ "ตอนทั้งหมด" (หรือขาดแค่ตอน 0) = เลขตอนเรียงต่อเนื่อง
  // สร้างลิงก์ตรงๆ ได้เลย ไม่ต้องโหลดทีละหน้า (เร็วและไม่โดนบล็อก)
  $rows = [];
  $diff = $total - $expected;
  if ($diff >= 0 && $diff <= 3) {
    foreach ($missing as $i) $rows[] = $makeRow($i);
    if ($diff >= 1) {
      // ตอนที่ซ่อนอยู่: ตอน 0 หรือตอนล่าสุดที่ถูกล็อก (VIP) ซึ่งไม่ได้เป็นลิงก์ในหน้ารายการ — ตรวจทีละหน้า (ไม่เกิน 4 หน้า)
      $cands = [];
      for ($k = 1; $k <= $diff; $k++) $cands[] = $top + $k;
      if ($zeroMissing) $cands[] = 0;
      $got = 0;
      $scores = [];
      foreach ($cands as $n) $scores[$n] = chapterPageExists($baseUrl, $pattern, $n);
      foreach ($cands as $n) {
        if ($got >= $diff) break;
        if (($scores[$n] ?? 0) === 2) { $rows[] = $makeRow($n); $got++; }
      }
      // หน้าตอน 0 มักไม่มีคำว่า "ตอนที่ 0" ในหน้า: ถ้าหน้าเปิดได้จริงและจำนวนยังขาดอยู่ ให้รับไว้
      if ($got < $diff && $zeroMissing && ($scores[0] ?? 0) === 1) { $rows[] = $makeRow(0); $got++; }
    }
    return $rows;
  }

  // เลขตอนมีช่องว่าง/ไม่ตรงกับจำนวนรวม: ตรวจเฉพาะเลขที่ขาดทีละหน้า (จำกัด 120 หน้ากัน timeout)
  $check = array_slice($missing, 0, 120);
  $urls = [];
  foreach ($check as $i) $urls[$i] = numericChapterUrl($baseUrl, $pattern, $i);
  $responses = $urls ? fetchHtmlMany(array_values($urls)) : [];
  $anyOk = false;
  foreach ($urls as $i => $u) {
    $res = $responses[$u] ?? null;
    if (!$res) continue;
    $anyOk = true;
    $row = chapterFromChapterPage($res[0], $u, '');
    if ($row && numChapter($row['chapter'] ?? '') == (float)$i) $rows[] = $row;
  }
  // ทุกหน้าถูกบล็อก: สร้างลิงก์ตรงๆ เฉพาะเลขที่ต่ำกว่าตอนสูงสุดที่เห็นจริง
  if (!$anyOk) {
    foreach ($check as $i) $rows[] = $makeRow($i);
  }
  return $rows;
}

function chapterTotalFromHtml(string $html): int {
  $text = pageTextForCounts($html);
  if (preg_match('/(?:ตอนทั้งหมด|ทั้งหมด\s*จำนวน\s*ตอน|total\s*chapters?|chapter\s*count)\s*[\(\[:：]?\s*(\d{1,5})/iu', $text, $tm)) {
    $tn = (int)$tm[1];
    if ($tn > 0 && $tn < 10000) return $tn;
  }
  $patterns = [
    '/(?:ตอนทั้งหมด|ทั้งหมด(?:\s*จำนวน)?ตอน|total\s*chapters?|chapter\s*count)\s*(?:\(|\[|:)?\s*(\d{1,5})/iu',
    '/(?:data-total(?:-chapters|-chapter-count)?|totalChapters|chapterCount)\s*=\s*["\']?(\d{1,5})/iu',
    '/["\'](?:total_chapters|chapter_count|totalChapters|chapterCount)["\']\s*[:=]\s*["\']?(\d{1,5})/iu',
  ];
  foreach ($patterns as $re) {
    if (preg_match($re, $html, $m)) {
      $n = (int)$m[1];
      if ($n > 0 && $n < 10000) return $n;
    }
  }
  if (preg_match('/ตอนทั้งหมด\s*\(\s*(\d{1,5})\s*\)/iu', html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8'), $m)) {
    return (int)$m[1];
  }
  return 0;
}

function mergeChapterRows(array $base, array $more): array {
  $map = [];
  foreach (array_merge($base, $more) as $c) {
    $label = trim((string)($c['chapter'] ?? ''));
    $url = canon((string)($c['chapter_url'] ?? ''));
    if ($label === '' || $url === '') continue;
    $key = strtolower($label) . '|' . $url;
    if (!isset($map[$key])) $map[$key] = $c;
  }
  $rows = array_values($map);
  usort($rows, fn($a, $b) => ((float)($a['sort_order'] ?? 0) <=> (float)($b['sort_order'] ?? 0)) ?: strcasecmp((string)$a['chapter'], (string)$b['chapter']));
  return $rows;
}

function numericChapterPattern(array $chapters, string $baseUrl): ?array {
  $basePath = rtrim((string)(parse_url($baseUrl)['path'] ?? ''), '/');
  if ($basePath === '') return null;
  $baseHost = strtolower((string)(parse_url($baseUrl)['host'] ?? ''));
  $isDiveToon = str_contains($baseHost, 'divetoon.com');
  $isToonbun = str_contains($baseHost, 'toonbun.com');
  foreach ($chapters as $c) {
    $u = canon((string)($c['chapter_url'] ?? ''));
    if ($u === '') continue;
    $host = strtolower((string)(parse_url($u)['host'] ?? ''));
    if ($host !== $baseHost) continue;
    $path = rtrim(rawurldecode((string)(parse_url($u)['path'] ?? '')), '/');

    if ($isToonbun && preg_match('~^' . preg_quote($basePath, '~') . '/episode/(\d+(?:\.\d+)?)$~i', $path, $m)) {
      return ['mode'=>'toonbun_episode','base_path'=>$basePath,'label_prefix'=>'episode','sample'=>(string)$m[1]];
    }
    if ($isDiveToon && preg_match('~^' . preg_quote($basePath, '~') . '/(\d+(?:\.\d+)?)$~', $path, $m)) {
      return ['mode'=>'divetoon_direct','base_path'=>$basePath,'sample'=>(string)$m[1]];
    }

    if (preg_match('~^' . preg_quote($basePath, '~') . '/(\d+(?:\.\d+)?)$~', $path, $m)) {
      return ['mode' => 'direct', 'base_path' => $basePath, 'sample' => (string)$m[1]];
    }

    if (preg_match('~^' . preg_quote($basePath, '~') . '/(chapter|chap|ch|episode|ep)[-_]?(\d+(?:\.\d+)?)$~iu', $path, $m)) {
      return [
        'mode' => 'prefixed',
        'base_path' => $basePath,
        'label_prefix' => $m[1],
        'sample' => (string)$m[2]
      ];
    }
  }
  return null;
}

function numericChapterUrl(string $baseUrl, array $pattern, string|int $n): string {
  $p = parse_url($baseUrl);
  $scheme = $p['scheme'] ?? 'https';
  $host = $p['host'] ?? '';
  $port = isset($p['port']) ? ':' . $p['port'] : '';
  $suffix = '/' . $n;
  if (($pattern['mode'] ?? '') === 'prefixed') {
    $suffix = '/' . ($pattern['label_prefix'] ?? 'chapter') . '-' . $n;
  } elseif (($pattern['mode'] ?? '') === 'toonbun_episode') {
    $suffix = '/episode/' . $n;
  } elseif (($pattern['mode'] ?? '') === 'divetoon_direct') {
    $suffix = '/' . $n;
  }
  return $scheme . '://' . $host . $port . rtrim((string)$pattern['base_path'], '/') . $suffix;
}

function fetchHtmlMany(array $urls): array {
  $results = [];
  $urls = array_values(array_unique(array_filter(array_map('strval', $urls))));
  if (!$urls) return $results;
  // โฮสต์ฟรีบางแห่ง (เช่น InfinityFree) ปิดฟังก์ชัน curl_multi_* บางตัว → โหลดทีละหน้าแทน และจำกัดเวลารวมไม่ให้ค้าง
  $multiOk = true;
  foreach (['curl_multi_init', 'curl_multi_add_handle', 'curl_multi_exec', 'curl_multi_select', 'curl_multi_getcontent', 'curl_multi_remove_handle', 'curl_multi_close'] as $fnName) {
    if (!function_exists($fnName)) { $multiOk = false; break; }
  }
  if (!$multiOk) {
    $deadline = microtime(true) + 22;
    foreach ($urls as $url) {
      if (microtime(true) > $deadline) { $results[$url] = null; continue; }
      try { [$html, $final, $code] = fetchHtml($url); $results[$url] = [$html, $final, $code]; } catch (Throwable $e) { $results[$url] = null; }
    }
    return $results;
  }

  $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36';
  $chunks = array_chunk($urls, 6);
  foreach ($chunks as $batch) {
    $mh = curl_multi_init();
    $handles = [];
    foreach ($batch as $url) {
      $ch = curl_init($url);
      curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 8,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 14,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_ENCODING => '',
        CURLOPT_HTTPHEADER => [
          'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language: th,en;q=0.9'
        ]
      ]);
      curl_multi_add_handle($mh, $ch);
      $handles[(int)$ch] = [$ch, $url];
    }
    do {
      $status = curl_multi_exec($mh, $running);
      if ($running) curl_multi_select($mh, 1.0);
    } while ($running && $status === CURLM_OK);

    foreach ($handles as [$ch, $url]) {
      $html = curl_multi_getcontent($ch);
      $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
      $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
      $results[$url] = (is_string($html) && $html !== '' && $code >= 200 && $code < 400)
        ? [$html, $final ?: $url, $code]
        : null;
      curl_multi_remove_handle($mh, $ch);
      curl_close($ch);
    }
    curl_multi_close($mh);
  }
  return $results;
}

function chapterFromChapterPage(string $html, string $requestedUrl, string $sourceTitle = ''): ?array {
  if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) return null;
  libxml_use_internal_errors(true);
  $dom = new DOMDocument();
  @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
  $xp = new DOMXPath($dom);
  $txt = trim(preg_replace('/\s+/u', ' ', strip_tags($html)));

  $candidate = '';
  foreach ([
    '//main//h1', '//article//h1', '//h1',
    '//*[contains(@class,"chapter-title")]',
    '//*[contains(@class,"chapter-name")]'
  ] as $q) {
    $n = $xp->query($q)->item(0);
    if ($n) {
      $candidate = trim(preg_replace('/\s+/u', ' ', $n->textContent));
      if ($candidate !== '') break;
    }
  }

  $requestedPath = rawurldecode((string)(parse_url($requestedUrl, PHP_URL_PATH) ?? ''));
  $label = '';
  if (preg_match('~^/content/[^/]+/(\d+(?:\.\d+)?)/?$~i', $requestedPath, $urlLabel) && str_contains(strtolower((string)parse_url($requestedUrl, PHP_URL_HOST)), 'divetoon.com')) $label = $urlLabel[1];
  if (preg_match('~^/content/[^/]+/episode/(\d+(?:\.\d+)?)/?$~i', $requestedPath, $urlLabel) && str_contains(strtolower((string)parse_url($requestedUrl, PHP_URL_HOST)), 'toonbun.com')) $label = $urlLabel[1];
  $candidateLabel = chapterLabel($candidate);
  // On DiveToon/Toonbun, the URL is authoritative; the page H1 may contain views/date/other numbers.
  if ($label === '' && $candidateLabel !== '') $label = $candidateLabel;
  if ($label === '') $label = chapterLabel(str_replace(['/', '-', '_'], ' ', (string)(parse_url($requestedUrl)['path'] ?? '')));
  if ($label === '') return null;

  if ($sourceTitle !== '') {
    $hay = mb_strtolower($txt);
    $needle = mb_strtolower(cleanTitle($sourceTitle));
    if ($needle !== '' && mb_strlen($needle) >= 5 && !str_contains($hay, $needle)) {
      return null;
    }
  }

  $n = numChapter($label);
  return [
    'chapter' => $label,
    'title' => $candidate !== '' ? $candidate : 'Chapter ' . $label,
    'chapter_url' => canon($requestedUrl),
    'sort_order' => chapterSortOrder($label)
  ];
}

function hiddenLoadMoreUrls(string $html, string $baseUrl): array {
  $out = [];
  $decoded = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $blockRe = '/(?:แสดงอีก|โหลดเพิ่ม|ดูเพิ่มเติม|show\s*more|load\s*more|more\s*chapters?).{0,1200}/isu';
  if (preg_match_all($blockRe, $decoded, $blocks)) {
    foreach ($blocks[0] as $block) {
      if (preg_match_all('/(?:href|data-url|data-href|data-next-url|data-load-more-url|data-api-url)\s*=\s*["\']([^"\']+)["\']/iu', $block, $ms)) {
        foreach ($ms[1] as $href) {
          $u = absUrl($baseUrl, $href);
          if ($u !== '') $out[] = $u;
        }
      }
      if (preg_match_all('/(?:url|endpoint|apiUrl|nextUrl)\s*[:=]\s*["\']([^"\']+)["\']/iu', $block, $ms)) {
        foreach ($ms[1] as $href) {
          $u = absUrl($baseUrl, $href);
          if ($u !== '') $out[] = $u;
        }
      }
    }
  }
  return array_values(array_unique($out));
}

function extractDiveToonRawChapterLinks(string $html, string $baseUrl): array {
  $host = strtolower((string)(parse_url($baseUrl)['host'] ?? ''));
  if (!str_contains($host, 'divetoon.com')) return [];
  $basePath = rtrim(rawurldecode((string)(parse_url($baseUrl)['path'] ?? '')), '/');
  if ($basePath === '') return [];
  // Some source themes keep hidden chapter links in serialized state/script strings rather than <a> nodes.
  $raw = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $raw = str_replace(['\\/', '\\u002F', '\\u002f', '%2F', '%2f'], '/', $raw);
  $re = '~' . preg_quote($basePath, '~') . '/(\d+(?:\.\d+)?)(?![\w.-])~i';
  if (!preg_match_all($re, $raw, $matches)) return [];
  $rows = [];
  foreach ($matches[1] as $label) {
    $url = canon(rtrim((string)(parse_url($baseUrl)['scheme'] ?? 'https') . '://' . (string)(parse_url($baseUrl)['host'] ?? '') . $basePath, '/') . '/' . $label);
    $rows[] = ['chapter'=>(string)$label,'title'=>'Chapter ' . $label,'chapter_url'=>$url,'sort_order'=>chapterSortOrder($label)];
  }
  return $rows;
}

// v17.17.13 — DiveToon ใช้รหัสยาว (เช่น 161001–165005) เป็น URL ของตอนที่ล็อกสำหรับ VIP
// รหัสพวกนี้ไม่ใช่เลขตอนจริง: ห้ามนำไปเป็นตอนล่าสุด/จุดเริ่มเดินย้อนตอน/ฐานคำนวณเติมตอนที่ซ่อนอยู่
function isDiveToonVipLabel(mixed $label): bool {
  $s = trim((string)$label);
  return preg_match('/^\d{5,}$/', $s) === 1 && (int)$s >= 10000;
}

function inferDiveToonIntegerRows(array $chapters, string $baseUrl): array {
  $pattern = numericChapterPattern($chapters, $baseUrl);
  if (!$pattern || ($pattern['mode'] ?? '') !== 'divetoon_direct') return [];
  $max = 0;
  $seen = [];
  foreach ($chapters as $row) {
    $label = trim((string)($row['chapter'] ?? ''));
    if (isDiveToonVipLabel($label)) continue; // ข้ามรหัสตอนล็อก VIP
    if (preg_match('/^(\d+)$/', $label, $m)) { $n=(int)$m[1]; $seen[$n]=true; $max=max($max,$n); }
  }
  // Only fill integer URLs below the latest observed integer. Never invent episodes above the newest URL.
  if ($max < 1 || $max > 1500) return [];
  $rows=[];
  for ($n=1; $n<=$max; $n++) {
    if (isset($seen[$n])) continue;
    $rows[]=['chapter'=>(string)$n,'title'=>'Chapter ' . $n,'chapter_url'=>numericChapterUrl($baseUrl,$pattern,$n),'sort_order'=>chapterSortOrder((string)$n),'inferred_url'=>true];
  }
  return $rows;
}

function extractAdjacentChapterUrls(string $html, string $baseUrl): array {
  if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) return ['prev' => '', 'next' => ''];
  libxml_use_internal_errors(true);
  $dom = new DOMDocument();
  @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
  $xp = new DOMXPath($dom);
  $host = strtolower((string)(parse_url($baseUrl)['host'] ?? ''));
  $out = ['prev' => '', 'next' => ''];

  foreach ($xp->query('//a[@href]') as $a) {
    $href = absUrl($baseUrl, (string)$a->getAttribute('href'));
    if ($href === '') continue;
    if (strtolower((string)(parse_url($href)['host'] ?? '')) !== $host) continue;

    $label = trim(preg_replace('/\s+/u', ' ',
      (string)$a->textContent . ' ' .
      $a->getAttribute('aria-label') . ' ' .
      $a->getAttribute('title') . ' ' .
      $a->getAttribute('class') . ' ' .
      $a->getAttribute('id')
    ));

    $path = rawurldecode((string)(parse_url($href)['path'] ?? ''));
    if (!str_starts_with(strtolower(rtrim($path, '/')), strtolower(rtrim((string)(parse_url($baseUrl)['path'] ?? ''), '/')) . '/')) continue;

    if ($out['prev'] === '' && preg_match('/(?:ตอน\s*ก่อนหน้า|ก่อนหน้า|previous|prev(?:ious)?|‹|←)/iu', $label)) {
      $out['prev'] = $href;
    }
    if ($out['next'] === '' && preg_match('/(?:ตอน\s*ถัดไป|ถัดไป|next|ต่อไป|›|→)/iu', $label)) {
      $out['next'] = $href;
    }
    if ($out['prev'] !== '' && $out['next'] !== '') break;
  }

  // Some readers use icon-only arrows with no useful text. Infer the closest chapter links by URL label.
  if ($out['prev'] === '' || $out['next'] === '') {
    $currentPath = rtrim(rawurldecode((string)(parse_url($baseUrl, PHP_URL_PATH) ?? '')), '/');
    $seriesPath = preg_replace('~/\d+(?:\.\d+)?$~', '', $currentPath) ?: '';
    $seriesUrl = (string)(parse_url($baseUrl)['scheme'] ?? 'https') . '://' . $host . $seriesPath;
    $currentLabel = chapterLabelFromUrl($baseUrl, $seriesUrl);
    $currentOrder = chapterSortOrder($currentLabel);
    $bestPrev = null; $bestNext = null;
    foreach ($xp->query('//a[@href]') as $a) {
      $href = absUrl($baseUrl, (string)$a->getAttribute('href'));
      if ($href === '' || strtolower((string)(parse_url($href)['host'] ?? '')) !== $host) continue;
      $path = rawurldecode((string)(parse_url($href)['path'] ?? ''));
      if ($seriesPath === '' || !str_starts_with(strtolower(rtrim($path, '/')), strtolower(rtrim($seriesPath, '/')) . '/')) continue;
      $label = chapterLabelFromUrl($href, $seriesUrl);
      if ($label === '' || $label === $currentLabel) continue;
      $order = chapterSortOrder($label);
      if ($order < $currentOrder && ($bestPrev === null || $order > $bestPrev['order'])) $bestPrev = ['url'=>$href,'order'=>$order];
      if ($order > $currentOrder && ($bestNext === null || $order < $bestNext['order'])) $bestNext = ['url'=>$href,'order'=>$order];
    }
    if ($out['prev'] === '' && $bestPrev) $out['prev'] = $bestPrev['url'];
    if ($out['next'] === '' && $bestNext) $out['next'] = $bestNext['url'];
  }
  return $out;
}

function walkAdjacentChapters(string $startUrl, string $direction, string $baseUrl, string $sourceTitle = '', int $limit = 1000, float $budgetSeconds = 12.0, int $stopAt = 0): array {
  $rows = [];
  $current = canon($startUrl);
  $seen = [];
  $deadline = microtime(true) + max(1.0, $budgetSeconds);
  for ($i = 0; $i < $limit && $current !== '' && microtime(true) < $deadline; $i++) {
    if (isset($seen[$current])) break;
    $seen[$current] = true;
    try {
      // Chapter-chain requests must not hold the whole add/import request for 30s per page.
      [$pageHtml, $final] = fetchHtml($current, 'GET', [], 6, 3);
    } catch (Throwable $e) {
      break;
    }
    $requestedPath = strtolower(rtrim((string)(parse_url($current, PHP_URL_PATH) ?? ''), '/'));
    $finalPath = strtolower(rtrim((string)(parse_url((string)$final, PHP_URL_PATH) ?? ''), '/'));
    $seriesPath = strtolower(rtrim((string)(parse_url($baseUrl, PHP_URL_PATH) ?? ''), '/'));
    if ($finalPath !== '' && $finalPath !== $requestedPath && $finalPath === $seriesPath) break;

    $row = chapterFromChapterPage($pageHtml, $final ?: $current, '');
    if ($row) {
      $rows[] = $row;
      if ($stopAt > 0 && count($rows) >= $stopAt) break;
    }
    $adj = extractAdjacentChapterUrls($pageHtml, $final ?: $current);
    $next = canon((string)($adj[$direction] ?? ''));
    if ($next === $current) break;
    $current = $next;
  }
  return $rows;
}

function expandChapters(string $html, string $baseUrl, array $initial, string $sourceTitle = ''): array {
  $chapters = $initial;
  $total = chapterTotalFromHtml($html);
  if ($total <= 0) {
    $more = chapterMoreCountFromHtml($html);
    if ($more > 0) $total = count($initial) + $more;
  }

  $sourceHost = strtolower((string)(parse_url($baseUrl)['host'] ?? ''));
  if (isManghahaHost($sourceHost)) {
    $catalog = expandManghahaCatalogPages($html, $baseUrl, $chapters);
    if (!empty($catalog['handled'])) return [
      'chapters' => (array)$catalog['chapters'],
      'total' => (int)$catalog['total'],
      'catalog_complete' => !empty($catalog['catalog_complete']),
      'catalog_pages_scanned' => (int)($catalog['catalog_pages_scanned'] ?? 0),
    ];
  }
  if (str_contains($sourceHost, 'divetoon.com')) {
    // First capture links serialized in the page source (when the site's hidden list is embedded).
    $chapters = mergeChapterRows($chapters, extractDiveToonRawChapterLinks($html, $baseUrl));
    if ($total <= 0) {
      $moreCount = chapterMoreCountFromHtml($html);
      if ($moreCount > 0) $total = count($chapters) + $moreCount;
    }
    // Some versions expose a load-more endpoint in data attributes / script snippets.
    foreach (hiddenLoadMoreUrls($html, $baseUrl) as $loadUrl) {
      try {
        [$loadHtml] = fetchHtml($loadUrl, 'GET', [], 8, 3);
        $loadRows = extractDiveToonRawChapterLinks($loadHtml, $baseUrl);
        if (class_exists('DOMDocument') && class_exists('DOMXPath')) {
          $loadDom = new DOMDocument();
          @$loadDom->loadHTML('<?xml encoding="UTF-8">' . $loadHtml, LIBXML_NOERROR | LIBXML_NOWARNING);
          $loadXp = new DOMXPath($loadDom);
          $loadRows = mergeChapterRows($loadRows, extractChaptersFromXpath($loadXp, $baseUrl, extractMangaSlug($baseUrl), $sourceHost));
        }
        $chapters = mergeChapterRows($chapters, $loadRows);
      } catch (Throwable $e) {}
    }

    // DiveToon exposes only the newest 24-ish chapters plus a JS "show more" control.
    // A direct numeric gap-fill via individual page requests used to take minutes on free hosting.
    // Walk the source's previous/next chapter links instead; one fetch can reveal the next actual label,
    // including multipart labels which cannot safely be guessed from the total count.
    $seed = null;
    foreach ($chapters as $row) {
      // ตอนล็อก VIP (รหัส 6 หลัก) เปิดอ่านไม่ได้และไม่มีลิงก์ก่อนหน้า → ใช้ตอนจริงล่าสุดเป็นจุดเริ่มเดินย้อนแทน
      if (isDiveToonVipLabel($row['chapter'] ?? '')) continue;
      if (!$seed || (float)($row['sort_order'] ?? 0) > (float)($seed['sort_order'] ?? 0)) $seed = $row;
    }
    if ($seed && !empty($seed['chapter_url']) && ($total <= 0 || count($chapters) < $total)) {
      $limit = $total > 0 ? min(180, $total + 8) : 120;
      $walked = walkAdjacentChapters((string)$seed['chapter_url'], 'prev', $baseUrl, '', $limit, 18.0, $total);
      $chapters = mergeChapterRows($chapters, $walked);
      // Some readers use the opposite arrow convention or expose recent split chapters only in "next".
      // A short second pass is attempted only while still short of the source-declared total.
      if ($total > 0 && count($chapters) < $total) {
        $walkedNext = walkAdjacentChapters((string)$seed['chapter_url'], 'next', $baseUrl, '', $limit, 5.0, $total);
        $chapters = mergeChapterRows($chapters, $walkedNext);
      }
    }

    // Quick fallback for missing integer routes only. Keep the total as advertised so the UI marks
    // the import partial when the source has extra multipart/hidden chapters we could not verify.
    if ($total > 0 && count($chapters) < $total) {
      $chapters = mergeChapterRows($chapters, inferDiveToonIntegerRows($chapters, $baseUrl));
    }
    return ['chapters' => $chapters, 'total' => $total];
  }

  // 1) Try explicit "load more" URLs exposed by the page.
  $loadUrls = hiddenLoadMoreUrls($html, $baseUrl);
  foreach ($loadUrls as $u) {
    try {
      [$moreHtml, $final] = fetchHtml($u);
      $more = extractChaptersFromXpath((function($h){
        libxml_use_internal_errors(true);
        $d=new DOMDocument();
        @$d->loadHTML('<?xml encoding="UTF-8">'.$h,LIBXML_NOERROR|LIBXML_NOWARNING);
        return new DOMXPath($d);
      })($moreHtml), $baseUrl, extractMangaSlug($baseUrl), strtolower((string)(parse_url($baseUrl)['host'] ?? '')));
      $chapters = mergeChapterRows($chapters, $more);
    } catch (Throwable $e) {}
  }

  // 2) If the source uses simple numeric chapter URLs (e.g. /content/manga/61),
  // use the declared total and fetch the missing numbers in parallel.
  // If individual chapter pages refuse automated requests, a final catalog
  // fallback still creates the direct URLs so the complete chapter list is not
  // cut off at the visible first page.
  $pattern = numericChapterPattern($chapters, $baseUrl);
  if ($pattern && $total > 0 && count($chapters) < $total) {
    // รองรับเลขตอนแบบ 4.1 / 4.2 / 5.1 / 5.2 ... ก่อน
    $decimalMore = completeDecimalPatternChapters($chapters, $baseUrl, $pattern, $total);
    if ($decimalMore) $chapters = mergeChapterRows($chapters, $decimalMore);

    // ถ้ายังไม่ครบและเป็นเลขจำนวนเต็ม ค่อยใช้ตัวเติมแบบเดิม
    if (count($chapters) < $total) {
      $chapters = mergeChapterRows($chapters, completeNumericChapters($chapters, $baseUrl, $pattern, $total));
    }
  }
  if ($total <= 0 || count($chapters) < $total) {
    // 3) Non-numeric sources: walk Previous/Next links to uncover hidden pages.
    // Keep this as a fallback so it does not slow down numeric sites unnecessarily.
    if (!empty($chapters)) {
      $sorted = $chapters;
      usort($sorted, fn($a, $b) => ((float)($a['sort_order'] ?? 0) <=> (float)($b['sort_order'] ?? 0)));
      $lowest = $sorted[0] ?? null;
      $highest = $sorted ? $sorted[count($sorted)-1] : null;

      if ($lowest && !empty($lowest['chapter_url'])) {
        $older = walkAdjacentChapters((string)$lowest['chapter_url'], 'prev', $baseUrl, $sourceTitle, 250);
        $chapters = mergeChapterRows($chapters, $older);
      }
      if ($highest && !empty($highest['chapter_url'])) {
        $newer = walkAdjacentChapters((string)$highest['chapter_url'], 'next', $baseUrl, $sourceTitle, 250);
        $chapters = mergeChapterRows($chapters, $newer);
      }
    }
  }

  // Keep total=0 when the source does not expose a trustworthy total; this is 'unverifiable', not confirmed complete.
  return ['chapters' => $chapters, 'total' => $total];
}

// v16.7: ตรวจ/ล้างแถวตอนหลังดึงเสร็จ ก่อนส่งให้ระบบเขียน
// - รวมแถวที่ URL เดียวกัน (เลือกป้ายที่มาจาก URL ก่อน)
// - ทิ้งป้ายที่เป็นค่าหลุด เช่น 2618 ในเรื่องที่มีตอน 1-26 (ยอดวิว/วันที่ติดมากับลิงก์)
// - เรียงตามเลขตอนจากน้อยไปมาก เพื่อให้ "ล่าสุด" เป็นตอนมากสุดจริง
function normalizeChapterRows(array $rows, string $baseUrl = ''): array {
  $byUrl = [];
  $noUrl = [];
  foreach ($rows as $c) {
    $label = chapterLabel($c['chapter'] ?? '');
    if ($label === '') continue;
    $c['chapter'] = $label;
    $c['sort_order'] = chapterSortOrder($label);
    $url = canon((string)($c['chapter_url'] ?? ''));
    if ($url === '') { $noUrl[strtolower($label)] = $c; continue; }
    if (isManghahaCatalogPageUrl($url, $baseUrl)) continue;
    $c['chapter_url'] = $url;
    $fromUrl = chapterLabelFromUrl($url, $baseUrl);
    if ($fromUrl !== '') {
      $c['chapter'] = $fromUrl;
      $c['sort_order'] = chapterSortOrder($fromUrl);
      $c['_url_label'] = true;
    }
    if (!isset($byUrl[$url]) || (!empty($c['_url_label']) && empty($byUrl[$url]['_url_label']))) $byUrl[$url] = $c;
  }
  $list = array_merge(array_values($byUrl), array_values($noUrl));
  $majors = [];
  foreach ($list as $c) { $n = (int)floor((float)numChapter($c['chapter'])); if ($n > 0) $majors[] = $n; }
  if (count($majors) >= 6) {
    sort($majors);
    $p90 = $majors[(int)floor((count($majors) - 1) * 0.9)];
    $limit = max(150, $p90 * 4 + 50);
    $list = array_values(array_filter($list, function ($c) use ($limit) {
      if (!empty($c['_url_label'])) return true; // ป้ายจาก URL เชื่อถือได้กว่า
      return (int)floor((float)numChapter($c['chapter'])) <= $limit;
    }));
  }
  foreach ($list as &$c) unset($c['_url_label']);
  unset($c);
  // v17.17.15 — เว็บบางแห่ง (เช่น ntr-manga.net) ลิสต์ตอนเดียวกันซ้ำด้วย URL คนละรูปแบบ
  // เช่น /25-slug/ กับ /slug-25/ → เก็บ 1 URL ต่อ 1 ตอน เลือกรูปแบบ URL ที่เป็นแบบเดียวกับตอนส่วนใหญ่ของเรื่อง
  $sigOf = fn(array $c): string => preg_replace('/\d+(?:[-.]\d+)?/', '#', (string)parse_url((string)($c['chapter_url'] ?? ''), PHP_URL_PATH));
  $sigCount = [];
  foreach ($list as $c) { $sg = $sigOf($c); $sigCount[$sg] = ($sigCount[$sg] ?? 0) + 1; }
  $byLabel = [];
  foreach ($list as $c) {
    $k = strtolower((string)$c['chapter']);
    if (!isset($byLabel[$k]) || ($sigCount[$sigOf($c)] ?? 0) > ($sigCount[$sigOf($byLabel[$k])] ?? 0)) $byLabel[$k] = $c;
  }
  $list = array_values($byLabel);
  usort($list, fn($a, $b) => ((float)$a['sort_order'] <=> (float)$b['sort_order']) ?: strcasecmp((string)$a['chapter'], (string)$b['chapter']));
  return $list;
}

function parsePage(string $html, string $baseUrl, bool $expand = true): array {
  if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) throw new RuntimeException('PHP ไม่มี DOM extension');
  libxml_use_internal_errors(true);
  $dom = new DOMDocument();
  @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
  $xp = new DOMXPath($dom);
  $host = strtolower((string)(parse_url($baseUrl)['host'] ?? ''));

  $mangaSlug = extractMangaSlug($baseUrl);

  $meta = function(string $key) use ($xp): string {
    $n = $xp->query("//meta[@property='{$key}' or @name='{$key}']/@content")->item(0);
    return $n ? trim((string)$n->nodeValue) : '';
  };

  $title = '';
  $h1 = $xp->query('//main//h1|//article//h1|//h1')->item(0);
  if ($h1) $title = cleanTitle($h1->textContent);
  if ($title === '') $title = cleanTitle($meta('og:title'));
  if ($title === '') $title = ucwords(str_replace('-', ' ', $mangaSlug));

  // --- เพิ่มเติมส่วนระบบดึง URL รูปปก (Cover URL) ให้ครอบคลุมทุกรูปแบบ ---
  $cover = '';
  $coverQueries = [
    "//meta[@property='og:image']/@content",
    "//meta[@name='twitter:image']/@content",
    "//div[contains(@class,'summary_image')]//img/@data-original",
    "//div[contains(@class,'summary_image')]//img/@data-lazy-src",
    "//div[contains(@class,'summary_image')]//img/@data-src",
    "//div[contains(@class,'summary_image')]//img/@src",
    "//div[contains(@class,'summary_image')]//source/@srcset",
    "//div[contains(@class,'summary_image')]//img/@data-src",
    "//div[contains(@class,'summary_image')]//img/@data-lazy-src",
    "//div[contains(@class,'thumb')]//img/@data-original",
    "//div[contains(@class,'thumb')]//img/@data-lazy-src",
    "//div[contains(@class,'thumb')]//img/@data-src",
    "//div[contains(@class,'thumb')]//img/@src",
    "//div[contains(@class,'thumb')]//source/@srcset",
    "//div[contains(@class,'poster')]//img/@data-original",
    "//div[contains(@class,'poster')]//img/@data-lazy-src",
    "//div[contains(@class,'poster')]//img/@data-src",
    "//div[contains(@class,'poster')]//img/@src",
    "//div[contains(@class,'manga-poster')]//img/@src",
    "//div[contains(@class,'featured')]//img/@src",
    "//div[contains(@class,'cover')]//img/@data-original",
    "//div[contains(@class,'cover')]//img/@data-lazy-src",
    "//div[contains(@class,'cover')]//img/@data-src",
    "//div[contains(@class,'cover')]//img/@src",
    "//img[contains(@class,'wp-post-image')]/@data-original",
    "//img[contains(@class,'wp-post-image')]/@data-lazy-src",
    "//img[contains(@class,'wp-post-image')]/@src",
    "//img[contains(@class,'wp-post-image')]/@data-src"
  ];

  foreach ($coverQueries as $q) {
    $node = $xp->query($q)->item(0);
    if ($node) {
      $val = trim((string)$node->nodeValue);
      // srcset may contain multiple candidates; keep the first URL and never convert animated GIF/WebP to a still image.
      if (stripos($q, 'srcset') !== false && $val !== '') {
        $parts = preg_split('/\\s*,\\s*/', $val);
        $val = trim((string)($parts[0] ?? ''));
        $val = preg_split('/\\s+/', $val)[0] ?? $val;
      }
      if ($val !== '' && !preg_match('~^(?:data:image/|about:blank)~i', $val)) {
        $cover = absUrl($baseUrl, $val);
        if ($cover !== '') break;
      }
    }
  }

  // สำรองด้วย Regex กรณี HTML โดนซ่อน Attribute หรือ DOMParse อ่านไม่ได้
  if ($cover === '') {
    if (preg_match('/<meta\s+(?:property|name)=["\'](?:og:image|twitter:image)["\']\s+content=["\']([^"\']+)["\']/i', $html, $m)) {
      $cover = absUrl($baseUrl, $m[1]);
    } elseif (preg_match('/class=["\'][^"\']*(?:summary_image|thumb|poster|cover)[^"\']*["\'][^>]*>.*?<img[^>]+(?:data-src|data-lazy-src|src)=["\']([^"\']+)["\']/is', $html, $m)) {
      $cover = absUrl($baseUrl, $m[1]);
    }
  }

  $postId = '';
  $idNodes = $xp->query(
    "//input[@name='manga' or @name='id' or @id='wp-manga-post-id' or contains(@class,'rating-post-id')]/@value | " .
    "//*[@id='manga-chapters-holder']/@data-id | " .
    "//a[contains(@class,'wp-manga-action')]/@data-post"
  );
  foreach ($idNodes as $node) {
    $val = trim((string)$node->nodeValue);
    if (ctype_digit($val) && (int)$val > 0) {
      $postId = $val;
      break;
    }
  }

  if ($postId === '') {
    if (preg_match('/class=["\'][^"\']*postid-(\d+)/i', $html, $m)) $postId = $m[1];
    elseif (preg_match('/["\']?manga_id["\']?\s*:\s*["\']?(\d+)["\']?/i', $html, $m)) $postId = $m[1];
    elseif (preg_match('/["\']?post_id["\']?\s*:\s*["\']?(\d+)["\']?/i', $html, $m)) $postId = $m[1];
    elseif (preg_match('/data-id=["\'](\d+)["\']/i', $html, $m)) $postId = $m[1];
    elseif (preg_match('/name=["\']manga["\']\s+value=["\'](\d+)["\']/i', $html, $m)) $postId = $m[1];
  }

  $chs = [];
  $looksWordPressManga = preg_match('/wp-manga|manga_get_chapters|listing-chapters_wrap|wp-manga-chapter/iu', $html) === 1;
  if ($postId !== '' && $looksWordPressManga && !str_contains($host, 'divetoon.com') && !str_contains($host, 'toonbun.com')) {
    $ajaxUrl = (parse_url($baseUrl)['scheme'] ?? 'https') . '://' . $host . '/wp-admin/admin-ajax.php';
    try {
      [$ajaxHtml] = fetchHtml($ajaxUrl, 'POST', ['action' => 'manga_get_chapters', 'manga' => $postId]);
      if ($ajaxHtml !== '' && strlen($ajaxHtml) > 20) {
        $ajaxDom = new DOMDocument();
        @$ajaxDom->loadHTML('<?xml encoding="UTF-8">' . $ajaxHtml, LIBXML_NOERROR | LIBXML_NOWARNING);
        $ajaxXp = new DOMXPath($ajaxDom);
        $chs = extractChaptersFromXpath($ajaxXp, $baseUrl, $mangaSlug, $host);
      }
    } catch (Throwable $e) {}
  }

  if (empty($chs)) {
    $chs = extractChaptersFromXpath($xp, $baseUrl, $mangaSlug, $host);
  }
  if (str_contains($host, 'divetoon.com')) {
    $chs = mergeChapterRows($chs, extractDiveToonRawChapterLinks($html, $baseUrl));
  }

  try {
    if ($expand) {
      $expanded = expandChapters($html, $baseUrl, $chs, $title);
    } else {
      $fastTotal = chapterTotalFromHtml($html);
      if ($fastTotal <= 0) {
        $moreCount = chapterMoreCountFromHtml($html);
        if ($moreCount > 0) $fastTotal = count($chs) + $moreCount;
      }
      $expanded = ['chapters' => $chs, 'total' => $fastTotal];
    }
  } catch (Throwable $e) {
    // ขยายรายการตอนไม่สำเร็จ: ใช้ตอนที่เห็นอยู่ และแจ้งว่ายังไม่ครบ (แทนที่จะล้มทั้งการนำเข้า)
    $expanded = ['chapters' => $chs, 'total' => chapterTotalFromHtml($html)];
  }
  $chs = normalizeChapterRows((array)$expanded['chapters'], $baseUrl);
  $total = (int)$expanded['total'];

  return [
    'source_url' => $baseUrl,
    'title' => $title,
    'cover_url' => $cover,
    'chapters' => $chs,
    'chapter_count' => count($chs),
    'total_chapters' => $total,
    'last_chapter' => $chs ? $chs[count($chs)-1]['chapter'] : null,
    'pagination_complete' => !empty($expanded['catalog_complete']),
    'catalog_pages_scanned' => (int)($expanded['catalog_pages_scanned'] ?? 0),
    'adapter' => isManghahaHost($host) && array_key_exists('catalog_complete', $expanded)
      ? (!empty($expanded['catalog_complete']) ? 'manghaha-pagination-complete' : 'manghaha-pagination-partial')
      : (str_contains($host, 'divetoon.com') ? (($total > 0 && count($chs) >= $total) ? 'divetoon-chain-complete' : 'divetoon-chain-partial') : ($total > 0 && count($chs) >= $total ? 'generic+expanded' : 'generic'))
  ];
}

function scrape(string $source, bool $fast = false): array {
  $fetchCountBefore = (int)($GLOBALS['MMT_FETCH_PAGE_COUNT'] ?? 0);
  [$html, $final] = fetchHtml($source);
  $result = parsePage($html, $final, !$fast);
  $result['pages_scanned'] = max(1, (int)($GLOBALS['MMT_FETCH_PAGE_COUNT'] ?? 0) - $fetchCountBefore);
  $result['import_mode'] = $fast ? 'server-fast' : 'server';
  $expected = (int)($result['total_chapters'] ?? 0);
  $found = (int)($result['chapter_count'] ?? count($result['chapters'] ?? []));
  $result['import_complete'] = $expected > 0 && $found >= $expected;
  $result['missing_chapters'] = $expected > $found ? ($expected - $found) : 0;
  return $result;
}

function syncGenres(PDO $pdo, int $id, array $ids): void {
  $pdo->prepare('DELETE FROM manga_genres WHERE manga_id=?')->execute([$id]);
  $q = $pdo->prepare('INSERT IGNORE INTO manga_genres(manga_id,genre_id) VALUES(?,?)');
  foreach ($ids as $x) if ((int)$x > 0) $q->execute([$id, (int)$x]);
}

function syncCollections(PDO $pdo, int $id, array $ids): void {
  $pdo->prepare('DELETE FROM manga_collections WHERE manga_id=?')->execute([$id]);
  $q = $pdo->prepare('INSERT IGNORE INTO manga_collections(manga_id,collection_id) VALUES(?,?)');
  foreach ($ids as $x) if ((int)$x > 0) $q->execute([$id, (int)$x]);
}

function preferredTypeId(PDO $pdo): int {
  $q=$pdo->query("SELECT id FROM categories ORDER BY CASE WHEN name='มังฮวา 18+' THEN 0 WHEN name='อื่นๆ' THEN 1 ELSE 2 END, id LIMIT 1");
  return (int)($q->fetchColumn() ?: 0);
}

function importedGenreIds(PDO $pdo, array $names): array {
  $ids = [];
  $q = $pdo->prepare('SELECT id FROM genres WHERE LOWER(name)=LOWER(?)');
  // v17.10: also match loosely ("One-shot" = Oneshot, "Sci Fi" = Sci-Fi) and a few common aliases.
  $norm = function ($s) { return preg_replace('/[^a-z0-9]+/', '', strtolower((string)$s)); };
  $map = [];
  foreach ($pdo->query('SELECT id,name FROM genres')->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $k = $norm($r['name']);
    if ($k !== '') $map[$k] = (int)$r['id'];
  }
  $alias = ['bl'=>'boyslove','yaoi'=>'boyslove','gl'=>'girlslove','yuri'=>'girlslove','romcom'=>'romanticcomedy','monstergirl'=>'monstergirls','videogame'=>'videogames','games'=>'videogames','game'=>'videogames','postapocalypse'=>'postapocalyptic','apocalyptic'=>'postapocalyptic','xianxia'=>'cultivation','genderswap'=>'genderbender','magicalgirl'=>'magicalgirls','overpower'=>'overpowered','zombie'=>'zombies','vampire'=>'vampires','ghost'=>'ghosts','demon'=>'demons','monster'=>'monsters','sliceoflife'=>'sliceoflife'];
  foreach ($names as $n) {
    $q->execute([$n]);
    if ($id = $q->fetchColumn()) { $ids[] = (int)$id; continue; }
    $k = $norm($n);
    if ($k === '') continue;
    if (isset($alias[$k])) $k = $alias[$k];
    if (isset($map[$k])) $ids[] = $map[$k];
  }
  return array_values(array_unique($ids));
}

// v17.17.16 — ซิงก์แบบฉลาด: ตอนที่ดึงมาซึ่ง "เป็นตอนเดียวกับที่มีอยู่แล้ว" แต่เขียนป้ายต่างกัน (เช่น 01 / 1 / 1.0 / Chapter 1)
// ต้องไม่ถูกเพิ่มซ้ำ → เทียบด้วยค่าลำดับตอนเชิงตัวเลข ถ้าตรงกับตอนเดิมให้ข้าม (ตอนที่ป้ายตรงกันเป๊ะปล่อยให้ upsert จัดการเอง)
function filterAliasChapters(PDO $pdo, int $mangaId, array $chs): array {
  $q = $pdo->prepare('SELECT chapter FROM chapters WHERE manga_id=?');
  $q->execute([$mangaId]);
  $labels = []; $keys = [];
  foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $lab) {
    $lab = (string)$lab;
    $labels[strtolower($lab)] = true;
    $so = chapterSortOrder($lab);
    if ($so > 0) $keys[number_format($so, 6, '.', '')] = true;
  }
  $out = [];
  foreach ($chs as $c) {
    $lab = strtolower(chapterLabel($c['chapter'] ?? ''));
    if ($lab === '' || isset($labels[$lab])) { $out[] = $c; continue; }
    $so = chapterSortOrder($lab);
    if ($so > 0 && isset($keys[number_format($so, 6, '.', '')])) continue; // ตอนเดียวกับที่มีอยู่แล้ว
    $out[] = $c;
  }
  return $out;
}

function chapterUrlForStore(array $c): string {
  $cn = canon((string)($c['chapter_url'] ?? ''));
  return (!empty($c['keep_slash']) && $cn !== '') ? $cn . '/' : $cn;
}

function upsertChapters(PDO $pdo, int $mangaId, array $chs, bool $sourceManaged = true, bool $preserveExisting = false): int {
  // Sync Review uses insert-only behavior: if the same manga/Chapter label already
  // exists, keep its title, URL, date, sort order, and source ownership unchanged.
  $duplicateClause = $preserveExisting
    ? 'ON DUPLICATE KEY UPDATE id=id'
    : 'ON DUPLICATE KEY UPDATE title=IF(user_edited=1,title,VALUES(title)),chapter_url=IF(user_edited=1,chapter_url,VALUES(chapter_url)),release_date=IF(user_edited=1,release_date,VALUES(release_date)),sort_order=VALUES(sort_order),source_managed=IF(VALUES(source_managed)=1,1,source_managed)';
  $q = $pdo->prepare('INSERT INTO chapters(manga_id,chapter,title,chapter_url,release_date,sort_order,source_managed) VALUES(?,?,?,?,?,?,?) ' . $duplicateClause);
  $new = 0;
  foreach ($chs as $c) {
    $label = chapterLabel($c['chapter'] ?? '');
    // Source imports must never fall back to arbitrary card text (views/dates/titles).
    // Manual chapter entry has already been validated by its caller.
    if ($label === '' && !$sourceManaged) $label = clean($c['chapter'] ?? '', 50);
    if ($label === '') continue;
    $q->execute([$mangaId, $label, clean($c['title'] ?? '', 255) ?: null, chapterUrlForStore($c), !empty($c['release_date']) ? $c['release_date'] : null, (float)($c['sort_order'] ?? chapterSortOrder($label)), $sourceManaged ? 1 : 0]);
    $new += $q->rowCount() === 1 ? 1 : 0;
  }
  return $new;
}

function mangaRow(PDO $pdo, int $id): ?array {
  $sql = "SELECT m.*,COALESCE(m.type_id,m.category_id) type_id,c.name category_name,c.adult type_adult,
    (SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id) chapter_count,
    (SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id ORDER BY ch.sort_order DESC,ch.id DESC LIMIT 1) latest_chapter,
    (SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chs.sort_order FROM chapters chs WHERE chs.manga_id=m.id AND chs.chapter=m.last_seen_chapter LIMIT 1),-1)) new_chapter_count,
    (SELECT ch.chapter_url FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chcur.sort_order FROM chapters chcur WHERE chcur.manga_id=m.id AND chcur.chapter=m.current_chapter LIMIT 1),CAST(SUBSTRING_INDEX(m.current_chapter,'.',1) AS DECIMAL(20,6)),0) ORDER BY ch.sort_order ASC,ch.id ASC LIMIT 1) next_chapter_url,
    (SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chcur.sort_order FROM chapters chcur WHERE chcur.manga_id=m.id AND chcur.chapter=m.current_chapter LIMIT 1),CAST(SUBSTRING_INDEX(m.current_chapter,'.',1) AS DECIMAL(20,6)),0) ORDER BY ch.sort_order ASC,ch.id ASC LIMIT 1) next_chapter,
    (SELECT GROUP_CONCAT(DISTINCT g.name ORDER BY g.name SEPARATOR '||') FROM manga_genres mg JOIN genres g ON g.id=mg.genre_id WHERE mg.manga_id=m.id) genre_names,
    (SELECT GROUP_CONCAT(DISTINCT g.id ORDER BY g.id SEPARATOR ',') FROM manga_genres mg JOIN genres g ON g.id=mg.genre_id WHERE mg.manga_id=m.id) genre_ids,
    (SELECT GROUP_CONCAT(DISTINCT mc.collection_id ORDER BY mc.collection_id SEPARATOR ',') FROM manga_collections mc WHERE mc.manga_id=m.id) collection_ids
    FROM manga m LEFT JOIN categories c ON c.id=COALESCE(m.type_id,m.category_id) WHERE m.id=? GROUP BY m.id";
  $q = $pdo->prepare($sql);
  $q->execute([$id]);
  return $q->fetch() ?: null;
}

function mangaPayload(PDO $pdo, int $id): array {
  $m = mangaRow($pdo, $id);
  if (!$m) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 404);
  $q = $pdo->prepare('SELECT * FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC');
  $q->execute([$id]);
  $chs = $q->fetchAll();
  $q = $pdo->prepare('SELECT genre_id FROM manga_genres WHERE manga_id=?');
  $q->execute([$id]);
  $gs = array_map('intval', array_column($q->fetchAll(), 'genre_id'));
  $q = $pdo->prepare('SELECT collection_id FROM manga_collections WHERE manga_id=?');
  $q->execute([$id]);
  $cs = array_map('intval', array_column($q->fetchAll(), 'collection_id'));
  $types = $pdo->query('SELECT id,name,adult FROM categories ORDER BY id')->fetchAll();
  $genres = $pdo->query('SELECT id,name FROM genres ORDER BY name')->fetchAll();
  $cols = $pdo->query('SELECT id,name FROM collections ORDER BY id')->fetchAll();
  $completionCard=completionCardForManga($pdo,$id);
  return ['manga' => $m, 'chapters' => $chs, 'genres_selected' => $gs, 'collections_selected' => $cs, 'types' => $types, 'categories' => $types, 'genres' => $genres, 'collections' => $cols, 'completion_card' => $completionCard];
}

function handleReadChapter(PDO $pdo, array $data): never {
  $id = (int)($data['id'] ?? $data['manga_id'] ?? 0);
  $chRaw = $data['chapter'] ?? $data['current_chapter'] ?? $data['ch'] ?? '';
  $ch = chapterLabel($chRaw);
  if ($ch === '') $ch = clean($chRaw, 50);

  if ($id < 1) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 422);

  $chapterUrl = '';
  if ($ch !== '') {
    $q = $pdo->prepare("SELECT chapter_url FROM chapters WHERE manga_id = ? AND (chapter = ? OR sort_order = ?) LIMIT 1");
    $q->execute([$id, $ch, chapterSortOrder($ch)]);
    $chapterUrl = (string)($q->fetchColumn() ?: '');
  }

  if ($chapterUrl === '' && $ch !== '') {
    $q = $pdo->prepare("SELECT chapter_url, chapter FROM chapters WHERE manga_id = ? AND chapter LIKE ? LIMIT 1");
    $q->execute([$id, "%{$ch}%"]);
    if ($row = $q->fetch()) {
      $chapterUrl = (string)($row['chapter_url'] ?? '');
      if ($ch === '') $ch = (string)($row['chapter'] ?? '');
    }
  }

  if ($chapterUrl === '') {
    $q = $pdo->prepare("SELECT chapter_url FROM chapters WHERE manga_id = ? ORDER BY sort_order ASC LIMIT 1");
    $q->execute([$id]);
    $chapterUrl = (string)($q->fetchColumn() ?: '');
  }

  if ($chapterUrl === '') {
    $q = $pdo->prepare("SELECT source_url FROM manga WHERE id = ?");
    $q->execute([$id]);
    $chapterUrl = (string)($q->fetchColumn() ?: '');
  }

  if ($ch !== '') {
    $pdo->prepare("UPDATE manga SET current_chapter = ?, last_read_at = CURRENT_TIMESTAMP, status = IF(status = 'planned', 'reading', status) WHERE id = ?")->execute([$ch, $id]);
    $pdo->prepare("INSERT INTO reading_history (manga_id, chapter, source_url, detection_method) VALUES (?, ?, ?, ?)")
        ->execute([$id, $ch, clean($data['source_url'] ?? $chapterUrl, 1000) ?: null, clean($data['detection_method'] ?? 'web', 30)]);
  } else {
    $pdo->prepare("UPDATE manga SET last_read_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$id]);
  }

  out([
    'ok' => true,
    'chapter_url' => $chapterUrl,
    'url' => $chapterUrl,
    'redirect_url' => $chapterUrl,
    'source_url' => $chapterUrl,
    'data' => [
      'url' => $chapterUrl,
      'chapter_url' => $chapterUrl
    ]
  ]);
}

function ensureSchemaOnce(PDO $pdo): void {
  static $done = false;
  if ($done) return;
  $pdo->exec("CREATE TABLE IF NOT EXISTS manga(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(255) NOT NULL,alt_title VARCHAR(255) NULL,cover_url VARCHAR(1000) NULL,source_url VARCHAR(1000) NOT NULL,category_id INT NULL,type_id INT NULL,current_chapter VARCHAR(50) NOT NULL DEFAULT '0',last_chapter VARCHAR(50) NULL,status ENUM('reading','completed','planned','paused','dropped') NOT NULL DEFAULT 'reading',rating DECIMAL(2,1) NULL,favorite TINYINT(1) NOT NULL DEFAULT 0,note TEXT NULL,last_read_at TIMESTAMP NULL,completion_status ENUM('ongoing','completed') NOT NULL DEFAULT 'ongoing',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX idx_m_source(source_url(255)),INDEX idx_m_updated(updated_at),INDEX idx_m_read(last_read_at),INDEX idx_m_type(type_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,adult TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS genres(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS collections(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS manga_genres(manga_id INT NOT NULL,genre_id INT NOT NULL,PRIMARY KEY(manga_id,genre_id),INDEX idx_mg_genre(genre_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS manga_collections(manga_id INT NOT NULL,collection_id INT NOT NULL,PRIMARY KEY(manga_id,collection_id),INDEX idx_mc_collection(collection_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS chapters(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,title VARCHAR(255) NULL,chapter_url VARCHAR(1000) NOT NULL,release_date DATE NULL,sort_order DECIMAL(20,6) NULL,source_managed TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_manga_chapter(manga_id,chapter),INDEX idx_ch_manga(manga_id),INDEX idx_ch_sort(manga_id,sort_order),INDEX idx_ch_source(manga_id,source_managed)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS reading_history(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,source_url VARCHAR(1000) NULL,detection_method VARCHAR(30) NOT NULL DEFAULT 'web',read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_hist_manga(manga_id,read_at),INDEX idx_hist_time(read_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS app_settings(setting_key VARCHAR(80) PRIMARY KEY,setting_value TEXT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("CREATE TABLE IF NOT EXISTS completion_cards(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,manga_id INT NULL,title_snapshot VARCHAR(255) NOT NULL,cover_snapshot VARCHAR(1000) NULL,chapter_count INT NOT NULL DEFAULT 0,last_chapter VARCHAR(50) NULL,rating DECIMAL(2,1) NULL,completed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,message VARCHAR(255) NOT NULL DEFAULT '🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว',rarity_override VARCHAR(20) NULL,UNIQUE KEY uq_completion_manga(manga_id),INDEX idx_completion_date(completed_at),INDEX idx_completion_manga(manga_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $done = true;
}


/* =========================================================
   V11 APP.JS COMPATIBILITY HELPERS
========================================================= */

/* v17.10: expanded genre catalogue (seeded once; existing names are kept) */
function mmtExpandedGenreNames(): array {
  return [
    'Oneshot',
    'Anthology',
    'Academy',
    'Animals',
    'Boys Love',
    'Girls Love',
    'Business',
    'Coming of Age',
    'Cooking',
    'Crime',
    'Cultivation',
    'Cyberpunk',
    'Delinquents',
    'Demons',
    'Dungeon',
    'Family',
    'Gender Bender',
    'Ghosts',
    'Gore',
    'Gyaru',
    'Hentai',
    'Housewife',
    'Hunter',
    'Idol',
    'Magic',
    'Magical Girls',
    'Mecha',
    'Medical',
    'Military',
    'Monster Girls',
    'Monsters',
    'Music',
    'Overpowered',
    'Palace Intrigue',
    'Post-Apocalyptic',
    'Regression',
    'Revenge',
    'Romantic Comedy',
    'Royalty',
    'Samurai',
    'Shoujo',
    'Survival',
    'Thriller',
    'Time Travel',
    'Tower Climbing',
    'Tragedy',
    'Vampires',
    'Vanilla',
    'Video Games',
    'Villainess',
    'Wuxia',
    'Zombies'
  ];
}

function ensureOptionalColumns(PDO $pdo): void {
  $checks = [
    ['manga','alt_title',"VARCHAR(255) NULL AFTER title"],
    ['manga','category_id',"INT NULL AFTER source_url"],
    ['manga','type_id',"INT NULL AFTER category_id"],
    ['manga','favorite',"TINYINT(1) NOT NULL DEFAULT 0 AFTER rating"],
    ['manga','note',"TEXT NULL AFTER favorite"],
    ['manga','last_read_at',"TIMESTAMP NULL AFTER updated_at"],
    ['manga','completion_status',"ENUM('ongoing','completed') NOT NULL DEFAULT 'ongoing' AFTER last_read_at"],
    ['manga','last_sync_at',"TIMESTAMP NULL AFTER completion_status"],
    ['manga','last_seen_chapter',"VARCHAR(50) NULL AFTER last_sync_at"],
    ['manga','sync_status',"VARCHAR(20) NOT NULL DEFAULT 'idle' AFTER last_seen_chapter"],
    ['manga','sync_error',"TEXT NULL AFTER sync_status"],
    ['manga','cover_motion_url',"VARCHAR(1000) NULL AFTER cover_url"],
    ['manga','cover_motion_request_id',"VARCHAR(255) NULL AFTER cover_motion_url"],
    ['manga','cover_motion_status',"VARCHAR(24) NOT NULL DEFAULT 'none' AFTER cover_motion_request_id"],
    ['chapters','source_managed',"TINYINT(1) NOT NULL DEFAULT 1 AFTER sort_order"],
    ['chapters','user_edited',"TINYINT(1) NOT NULL DEFAULT 0 AFTER source_managed"],
    ['completion_cards','rarity_override',"VARCHAR(20) NULL AFTER message"],
  ];
  foreach ($checks as $c) {
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
    $stmt->execute([$c[0],$c[1]]);
    if ((int)$stmt->fetchColumn()===0) {
      try { $pdo->exec("ALTER TABLE `{$c[0]}` ADD COLUMN `{$c[1]}` {$c[2]}"); } catch(Throwable $e) {}
    }
  }
  // คะแนนรองรับ .5: เปลี่ยนคอลัมน์เดิม (TINYINT) เป็น DECIMAL(2,1) ครั้งเดียว ค่าเดิมคงอยู่
  foreach ([['manga','rating'],['completion_cards','rating']] as $rc) {
    try {
      $st=$pdo->prepare("SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
      $st->execute($rc);
      if (strtolower((string)$st->fetchColumn())==='tinyint') $pdo->exec("ALTER TABLE `{$rc[0]}` MODIFY `{$rc[1]}` DECIMAL(2,1) NULL");
    } catch(Throwable $e) {}
  }
  try {
    // Existing libraries should not suddenly report every historical chapter as "new".
    $pdo->exec("UPDATE manga m SET m.last_seen_chapter=(SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id ORDER BY ch.sort_order DESC,ch.id DESC LIMIT 1) WHERE (m.last_seen_chapter IS NULL OR NOT EXISTS (SELECT 1 FROM chapters cs WHERE cs.manga_id=m.id AND cs.chapter=m.last_seen_chapter)) AND EXISTS (SELECT 1 FROM chapters ce WHERE ce.manga_id=m.id)");
  } catch(Throwable $e) {}
  // Upgrade existing order keys once; do not reset them on every API request.
  try {
    $mark=$pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key=? LIMIT 1');
    $mark->execute(['chapter_sort_order_v16']);
    if ((string)$mark->fetchColumn() !== 'done') {
      $rows=$pdo->query('SELECT id,chapter FROM chapters')->fetchAll(PDO::FETCH_ASSOC);
      $up=$pdo->prepare('UPDATE chapters SET sort_order=? WHERE id=?');
      foreach($rows as $row) $up->execute([chapterSortOrder($row['chapter']??''),(int)$row['id']]);
      $pdo->prepare('INSERT INTO app_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute(['chapter_sort_order_v16','done']);
    }
  } catch(Throwable $e) {}
  // v17.10: seed the expanded genre list once. INSERT IGNORE keeps existing genres; genres you delete later are not re-created.
  try {
    $gm=$pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key=? LIMIT 1');
    $gm->execute(['genres_seed_v17_10']);
    if ((string)$gm->fetchColumn() !== 'done') {
      $gi=$pdo->prepare('INSERT IGNORE INTO genres(name) VALUES(?)');
      foreach (mmtExpandedGenreNames() as $gn) $gi->execute([$gn]);
      $pdo->prepare('INSERT INTO app_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute(['genres_seed_v17_10','done']);
    }
  } catch(Throwable $e) {}
}

function recentActivity(PDO $pdo): array {
  $latest=[];
  $timeline=[];
  try {
    $q=$pdo->query("SELECT h.*,m.title,m.cover_url,COALESCE(m.type_id,m.category_id) type_id FROM reading_history h JOIN manga m ON m.id=h.manga_id ORDER BY h.read_at DESC,h.id DESC LIMIT 50");
    $timeline=$q->fetchAll(PDO::FETCH_ASSOC);
    $seen=[];
    foreach($timeline as $r){
      $mid=(int)$r['manga_id'];
      if(isset($seen[$mid])) continue;
      $seen[$mid]=1;
      $latest[]=$r;
    }
  } catch(Throwable $e) {}
  return ['latest'=>$latest,'timeline'=>$timeline];
}

function completionCardForManga(PDO $pdo, int $mangaId): ?array {
  // คะแนนบนการ์ดให้ยึดคะแนนปัจจุบันของเรื่องเสมอ
  // แต่ถ้าเรื่องถูกลบ ให้ใช้คะแนนที่บันทึกไว้บนการ์ดเป็น fallback เพื่อคงประวัติรางวัล
  $q=$pdo->prepare('SELECT cc.*, CASE WHEN m.id IS NOT NULL THEN m.rating ELSE cc.rating END AS display_rating FROM completion_cards cc LEFT JOIN manga m ON m.id=cc.manga_id WHERE cc.manga_id=? LIMIT 1');
  $q->execute([$mangaId]);
  $r=$q->fetch(PDO::FETCH_ASSOC);
  if(!$r) return null;
  $r['rating']=$r['display_rating']!==null ? (float)$r['display_rating'] : null;
  unset($r['display_rating']);
  return $r;
}

function ensureCompletionCard(PDO $pdo, int $mangaId): array {
  $existing=completionCardForManga($pdo,$mangaId);
  if($existing) return [$existing,false];
  $q=$pdo->prepare('SELECT title,cover_url,rating,last_chapter,(SELECT COUNT(*) FROM chapters WHERE manga_id=m.id) AS chapter_count FROM manga m WHERE m.id=? LIMIT 1');
  $q->execute([$mangaId]);
  $m=$q->fetch(PDO::FETCH_ASSOC);
  if(!$m) return [null,false];
  $q=$pdo->prepare('INSERT INTO completion_cards(manga_id,title_snapshot,cover_snapshot,chapter_count,last_chapter,rating,message) VALUES(?,?,?,?,?,?,?)');
  $q->execute([
    $mangaId,
    clean($m['title']??'',255) ?: 'เรื่องที่อ่านจบ',
    clean($m['cover_url']??'',1000) ?: null,
    (int)($m['chapter_count']??0),
    $m['last_chapter']??null,
    normalizeRating($m['rating']??null),
    '🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว'
  ]);
  $id=(int)$pdo->lastInsertId();
  $q=$pdo->prepare('SELECT * FROM completion_cards WHERE id=?'); $q->execute([$id]);
  return [$q->fetch(PDO::FETCH_ASSOC) ?: null,true];
}

function completionCards(PDO $pdo): array {
  // ใช้คะแนนปัจจุบันจาก manga.rating เพื่อให้แก้คะแนนภายหลังแล้วการ์ดอัปเดตตามทันที
  $rows=$pdo->query('SELECT cc.*, CASE WHEN m.id IS NOT NULL THEN m.rating ELSE cc.rating END AS display_rating FROM completion_cards cc LEFT JOIN manga m ON m.id=cc.manga_id ORDER BY cc.completed_at DESC,cc.id DESC')->fetchAll(PDO::FETCH_ASSOC);
  foreach($rows as &$r){
    $r['id']=(int)$r['id'];
    $r['manga_id']=$r['manga_id']!==null ? (int)$r['manga_id'] : null;
    $r['chapter_count']=(int)$r['chapter_count'];
    $r['rating']=$r['display_rating']!==null ? (float)$r['display_rating'] : null;
    unset($r['display_rating']);
    $r['card_number']=$r['id'];
  }
  return $rows;
}

function exportBackup(PDO $pdo): array {
  $tables=['manga','chapters','categories','genres','collections','manga_genres','manga_collections','reading_history','app_settings','completion_cards'];
  $backup=[
    'format'=>'mymanga-tracker',
    'version'=>'17.6.0-tcg-collector',
    'exported_at'=>date(DATE_ATOM)
  ];
  foreach($tables as $table){
    try {
      $backup[$table]=$pdo->query("SELECT * FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
      $backup[$table]=[];
    }
  }
  return $backup;
}

function restoreBackup(PDO $pdo, array $backup): array {
  if (($backup['format'] ?? '') !== 'mymanga-tracker') {
    out(['ok'=>false,'message'=>'ไฟล์ Backup ไม่ถูกต้อง'],422);
  }

  $mangaCount=0;
  $chapterCount=0;

  $pdo->beginTransaction();
  try {
    if (!empty($backup['categories']) && is_array($backup['categories'])) {
      $q=$pdo->prepare('INSERT INTO categories(id,name,adult,created_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),adult=VALUES(adult)');
      foreach($backup['categories'] as $r){
        $q->execute([(int)($r['id']??0),clean($r['name']??'',80),(int)($r['adult']??0),$r['created_at']??null]);
      }
    }

    if (!empty($backup['genres']) && is_array($backup['genres'])) {
      $q=$pdo->prepare('INSERT INTO genres(id,name,created_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)');
      foreach($backup['genres'] as $r){
        $q->execute([(int)($r['id']??0),clean($r['name']??'',80),$r['created_at']??null]);
      }
    }

    if (!empty($backup['collections']) && is_array($backup['collections'])) {
      $q=$pdo->prepare('INSERT INTO collections(id,name,created_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)');
      foreach($backup['collections'] as $r){
        $q->execute([(int)($r['id']??0),clean($r['name']??'',80),$r['created_at']??null]);
      }
    }

    if (!empty($backup['manga']) && is_array($backup['manga'])) {
      $q=$pdo->prepare("INSERT INTO manga(id,title,alt_title,cover_url,source_url,category_id,type_id,current_chapter,last_chapter,status,rating,favorite,note,last_read_at,completion_status,last_sync_at,last_seen_chapter,sync_status,sync_error,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title),alt_title=VALUES(alt_title),cover_url=VALUES(cover_url),source_url=VALUES(source_url),category_id=VALUES(category_id),type_id=VALUES(type_id),current_chapter=VALUES(current_chapter),last_chapter=VALUES(last_chapter),status=VALUES(status),rating=VALUES(rating),favorite=VALUES(favorite),note=VALUES(note),last_read_at=VALUES(last_read_at),completion_status=VALUES(completion_status),last_sync_at=VALUES(last_sync_at),last_seen_chapter=VALUES(last_seen_chapter),sync_status=VALUES(sync_status),sync_error=VALUES(sync_error)");
      foreach($backup['manga'] as $r){
        try {
          $q->execute([
            (int)($r['id']??0),clean($r['title']??'',255),clean($r['alt_title']??'',255)?:null,clean($r['cover_url']??'',1000)?:null,clean($r['source_url']??'',1000),$r['category_id']!==null?(int)$r['category_id']:null,$r['type_id']!==null?(int)$r['type_id']:null,clean($r['current_chapter']??'0',50),($r['last_chapter']??null),in_array(($r['status']??'reading'),['reading','completed','planned','paused','dropped'],true)?$r['status']:'reading',normalizeRating($r['rating']??null),(int)($r['favorite']??0),clean($r['note']??'',5000)?:null,($r['last_read_at']??null),in_array(($r['completion_status']??'ongoing'),['ongoing','completed'],true)?$r['completion_status']:'ongoing',($r['last_sync_at']??null),($r['last_seen_chapter']??null),clean($r['sync_status']??'idle',20)?:'idle',clean($r['sync_error']??'',4000)?:null,$r['created_at']??null,$r['updated_at']??null
          ]);
          $mangaCount++;
        } catch(Throwable $e) {}
      }
    }

    if (!empty($backup['chapters']) && is_array($backup['chapters'])) {
      $q=$pdo->prepare('INSERT INTO chapters(id,manga_id,chapter,title,chapter_url,release_date,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE title=VALUES(title),chapter_url=VALUES(chapter_url),release_date=VALUES(release_date),sort_order=VALUES(sort_order)');
      foreach($backup['chapters'] as $r){
        try {
          $q->execute([(int)($r['id']??0),(int)($r['manga_id']??0),clean($r['chapter']??'',50),clean($r['title']??'',255)?:null,clean($r['chapter_url']??'',1000),($r['release_date']??null),($r['sort_order']??null),$r['created_at']??null]);
          $chapterCount++;
        } catch(Throwable $e) {}
      }
    }

    if (!empty($backup['manga_genres']) && is_array($backup['manga_genres'])) {
      $q=$pdo->prepare('INSERT IGNORE INTO manga_genres(manga_id,genre_id) VALUES(?,?)');
      foreach($backup['manga_genres'] as $r){try{$q->execute([(int)$r['manga_id'],(int)$r['genre_id']]);}catch(Throwable $e){}}
    }
    if (!empty($backup['manga_collections']) && is_array($backup['manga_collections'])) {
      $q=$pdo->prepare('INSERT IGNORE INTO manga_collections(manga_id,collection_id) VALUES(?,?)');
      foreach($backup['manga_collections'] as $r){try{$q->execute([(int)$r['manga_id'],(int)$r['collection_id']]);}catch(Throwable $e){}}
    }
    if (!empty($backup['reading_history']) && is_array($backup['reading_history'])) {
      $q=$pdo->prepare('INSERT INTO reading_history(id,manga_id,chapter,source_url,detection_method,read_at) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE chapter=VALUES(chapter),source_url=VALUES(source_url),detection_method=VALUES(detection_method),read_at=VALUES(read_at)');
      foreach($backup['reading_history'] as $r){try{$q->execute([(int)($r['id']??0),(int)($r['manga_id']??0),clean($r['chapter']??'',50),clean($r['source_url']??'',1000)?:null,clean($r['detection_method']??'web',30),$r['read_at']??null]);}catch(Throwable $e){}}
    }
    if (!empty($backup['app_settings']) && is_array($backup['app_settings'])) {
      $q=$pdo->prepare('INSERT INTO app_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
      foreach($backup['app_settings'] as $r){try{$q->execute([clean($r['setting_key']??'',80),$r['setting_value']??null,$r['updated_at']??null]);}catch(Throwable $e){}}
    }
    if (!empty($backup['completion_cards']) && is_array($backup['completion_cards'])) {
      $q=$pdo->prepare('INSERT INTO completion_cards(id,manga_id,title_snapshot,cover_snapshot,chapter_count,last_chapter,rating,completed_at,message,rarity_override) VALUES(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE title_snapshot=VALUES(title_snapshot),cover_snapshot=VALUES(cover_snapshot),chapter_count=VALUES(chapter_count),last_chapter=VALUES(last_chapter),rating=VALUES(rating),completed_at=VALUES(completed_at),message=VALUES(message),rarity_override=VALUES(rarity_override)');
      foreach($backup['completion_cards'] as $r){
        try{
          $q->execute([
            (int)($r['id']??0),
            ($r['manga_id']??null)!==null ? (int)$r['manga_id'] : null,
            clean($r['title_snapshot']??'',255) ?: 'เรื่องที่อ่านจบ',
            clean($r['cover_snapshot']??'',1000) ?: null,
            (int)($r['chapter_count']??0),
            $r['last_chapter']??null,
            normalizeRating($r['rating']??null),
            $r['completed_at']??date('Y-m-d H:i:s'),
            clean($r['message']??'🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว',255) ?: '🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว',
            in_array(($r['rarity_override']??null),['common','common-ii','common-iii','common-iv','common-v','uncommon','uncommon-ii','uncommon-iii','uncommon-iv','uncommon-v','rare','rare-ii','rare-iii','rare-iv','rare-v','rare-vi','rare-vii','rare-viii','epic','epic-ii','epic-iii','epic-iv','epic-v','epic-vi','epic-vii','epic-viii','legendary','legendary-ii','mythic','divine','celestial','eternal'],true) ? $r['rarity_override'] : null
          ]);
        }catch(Throwable $e){}
      }
    }
    $pdo->commit();
  } catch(Throwable $e) {
    if($pdo->inTransaction())$pdo->rollBack();
    throw $e;
  }
  return ['manga'=>$mangaCount,'chapters'=>$chapterCount];
}

function browserImport(PDO $pdo, array $data): void {
  $source=safeRemote(clean($data['source_url']??$data['url']??'',1000));
  $title=clean($data['title']??'',255);
  $cover=clean($data['cover_url']??$data['cover']??'',1000);
  $id=(int)($data['manga_id']??0);
  $chapters=(array)($data['chapters']??[]);

  if($id<1){
    $q=$pdo->prepare('SELECT id FROM manga WHERE source_url=? LIMIT 1');
    $q->execute([$source]);
    $id=(int)($q->fetchColumn()?:0);
  }

  if($id<1){
    if($title==='')$title=cleanTitle(ucwords(str_replace('-', ' ', basename(trim((string)(parse_url($source)['path']??''),'/')))));
    if($title==='')$title='Imported Manga';
    $typeId=(int)$pdo->query("SELECT id FROM categories WHERE name='อื่นๆ' LIMIT 1")->fetchColumn();
    $q=$pdo->prepare("INSERT INTO manga(title,cover_url,source_url,category_id,type_id,status,current_chapter,last_chapter,completion_status) VALUES(?,?,?,?,?,'reading','0',NULL,'ongoing')");
    $q->execute([$title,$cover?:null,$source,$typeId,$typeId]);
    $id=(int)$pdo->lastInsertId();
  } else {
    $sets=['source_url=?'];$params=[$source];
    if($title!==''){$sets[]='title=?';$params[]=$title;}
    if($cover!==''){$sets[]='cover_url=?';$params[]=$cover;}
    $params[]=$id;
    $pdo->prepare('UPDATE manga SET '.implode(',',$sets).' WHERE id=?')->execute($params);
  }

  $normalized=[];
  foreach($chapters as $c){
    if(is_string($c))$c=['chapter'=>$c];
    if(!is_array($c))continue;
    $label=chapterLabel($c['chapter']??$c['number']??$c['episode']??$c['label']??'');
    $url=clean($c['chapter_url']??$c['url']??$c['href']??'',1000);
    $rawUrl=trim($url);
    $url=$url!==''?absUrl($source,$url):'';
    // Keep the site's own trailing slash: some sources 404 without it (canon() strips it for storage elsewhere).
    $keepSlash=($url!==''&&preg_match('~^https?://[^?#]+/$~i',$rawUrl)===1);
    if($keepSlash)$url.='/';
    $urlLabel=$url!==''?chapterLabelFromUrl($url,$source):'';
    if($urlLabel!=='')$label=$urlLabel;
    if($label===''&&$url!=='')$label=chapterLabel(str_replace(['/','-'],' ',(string)(parse_url($url)['path']??'')));
    if($label===''||$url==='')continue;
    $key=strtolower($label);
    if(isset($normalized[$key]))continue;
    $normalized[$key]=['chapter'=>$label,'title'=>clean($c['title']??$c['name']??'',255),'chapter_url'=>$url,'keep_slash'=>$keepSlash,'sort_order'=>chapterSortOrder($label),'release_date'=>$c['release_date']??null];
  }
  $new=upsertChapters($pdo,$id,array_values($normalized));
  $seenQ=$pdo->prepare('SELECT last_seen_chapter FROM manga WHERE id=? LIMIT 1');$seenQ->execute([$id]);$wasSeen=$seenQ->fetchColumn();
  $pdo->prepare('UPDATE manga SET last_chapter=(SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1), last_read_at=last_read_at WHERE id=?')->execute([$id,$id]);
  if($wasSeen===false || $wasSeen===null || $wasSeen===''){ $pdo->prepare('UPDATE manga SET last_seen_chapter=last_chapter WHERE id=?')->execute([$id]); }
  $pdo->prepare("UPDATE manga SET last_sync_at=CURRENT_TIMESTAMP,sync_status='success',sync_error=NULL WHERE id=?")->execute([$id]);
  out(['ok'=>true,'manga_id'=>$id,'new_chapters'=>$new,'chapter_count'=>count($normalized)]);
}

/**
 * Narrow server-side wrapper for fal.ai's queue API. The API key never leaves PHP.
 * Returns [http, data, raw]; all external endpoint paths are fixed by this app.
 */
function falProviderText(array $data): string {
  $parts = [];
  foreach (['detail','message','error','reason','status_message'] as $key) {
    if (!array_key_exists($key, $data)) continue;
    $value = $data[$key];
    if (is_string($value) || is_numeric($value)) $parts[] = (string)$value;
    elseif (is_array($value)) $parts[] = (string)json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  }
  return trim(implode(' ', $parts));
}
function falBalanceExhausted(string $detail): bool {
  return (bool)preg_match('/exhausted\s+balance|user\s+is\s+locked|insufficient\s+balance|top.?up.{0,80}balance|balance.{0,80}(?:empty|exhausted|insufficient)/i', $detail);
}
function falCoverRequest(string $url, string $key, string $method = 'GET', ?array $payload = null): array {
  if (!function_exists('curl_init')) return ['http'=>0,'data'=>[],'raw'=>'cURL is not enabled on this PHP host'];
  $ch = curl_init($url);
  $headers = ['Authorization: Key ' . $key, 'Accept: application/json'];
  if ($payload !== null) $headers[] = 'Content-Type: application/json';
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => $method,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 22,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
  ]);
  if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  $raw = curl_exec($ch);
  $err = curl_error($ch);
  $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($raw === false) return ['http'=>$http,'data'=>[],'raw'=>$err ?: 'Could not connect to AI provider'];
  $decoded = json_decode((string)$raw, true);
  return ['http'=>$http,'data'=>is_array($decoded)?$decoded:[],'raw'=>(string)$raw];
}

$data = body();
$action = (string)($data['action'] ?? '');
try {
  requireToken($MANGA_API_TOKEN, $data);
  ensureSchemaOnce($pdo);
  ensureOptionalColumns($pdo);
  switch ($action) {
    case 'animate_cover_submit': {
      $id = (int)($data['id'] ?? 0);
      if ($id < 1) out(['ok'=>false,'message'=>'ไม่พบเรื่องที่เลือก'],422);
      $falKey = trim((string)($FAL_KEY ?? ''));
      if ($falKey === '') out(['ok'=>false,'message'=>'ยังไม่ได้ตั้งค่า FAL_KEY ใน api/config.php จึงยังสร้างปก AI ไม่ได้'],503);
      $q = $pdo->prepare('SELECT id,title,cover_url,cover_motion_url,cover_motion_request_id,cover_motion_status FROM manga WHERE id=? LIMIT 1');
      $q->execute([$id]); $m = $q->fetch(PDO::FETCH_ASSOC);
      if (!$m) out(['ok'=>false,'message'=>'ไม่พบเรื่องในคลัง'],404);
      $cover = trim((string)($m['cover_url'] ?? ''));
      if ($cover === '') out(['ok'=>false,'message'=>'เรื่องนี้ยังไม่มีรูปปกต้นฉบับ กรุณาดึงหรือเพิ่มรูปปกก่อน'],422);
      // Do not launch another paid job when one is already active.
      if (in_array((string)($m['cover_motion_status'] ?? ''), ['queued','IN_QUEUE','IN_PROGRESS'], true) && trim((string)($m['cover_motion_request_id'] ?? '')) !== '') {
        out(['ok'=>true,'status'=>'queued','message'=>'เรื่องนี้กำลังสร้างปกเคลื่อนไหวอยู่แล้ว','cover_motion_url'=>$m['cover_motion_url'] ?? null]);
      }
      if (!empty($m['cover_motion_url']) && empty($data['force'])) {
        out(['ok'=>true,'status'=>'completed','message'=>'เรื่องนี้มีปกเคลื่อนไหวอยู่แล้ว','cover_motion_url'=>$m['cover_motion_url']]);
      }
      $cover = safeRemote($cover);
      $prompt = clean($data['prompt'] ?? '', 900);
      if ($prompt === '') $prompt = 'Animate this original anime or manga cover with subtle natural motion: gentle hair and clothing movement, soft atmospheric particles and a delicate light shimmer. Preserve character identity, composition, colors, and all visible lettering and logos. Keep the camera almost still, no cuts, no new characters, no text changes, no morphing. Vertical cover animation.';
      // Input image is taken from the selected manga row, not arbitrary user-supplied URLs.
      $endpoint = 'fal-ai/wan/v2.2-5b/image-to-video';
      $resp = falCoverRequest('https://queue.fal.run/'.$endpoint, $falKey, 'POST', [
        'image_url'=>$cover,
        'prompt'=>$prompt,
        'resolution'=>'580p',
        'aspect_ratio'=>'auto',
        'num_frames'=>49,
        'frames_per_second'=>16,
        'video_quality'=>'medium',
        'video_write_mode'=>'small',
        'enable_safety_checker'=>true,
        'enable_output_safety_checker'=>true,
      ]);
      if ($resp['http'] < 200 || $resp['http'] >= 300 || empty($resp['data']['request_id'])) {
        $detail = falProviderText($resp['data']);
        $allProviderText = $detail . ' ' . (string)$resp['raw'];
        if (falBalanceExhausted($allProviderText)) {
          out(['ok'=>false,'error_code'=>'FAL_BALANCE_EXHAUSTED','billing_url'=>'https://fal.ai/dashboard/billing','message'=>'บัญชี fal.ai ใช้ยอดเครดิตหมดหรือถูกล็อกชั่วคราว จึงยังสร้างปกเคลื่อนไหวไม่ได้ กรุณาตรวจสอบหรือเติมเครดิตที่ fal.ai/dashboard/billing แล้วค่อยลองใหม่'],402);
        }
        if ($detail === '') $detail = 'AI service did not accept the request (HTTP '.(int)$resp['http'].')';
        out(['ok'=>false,'message'=>'ส่งงานสร้างปกไม่สำเร็จ: '.clean($detail,500)],502);
      }
      $requestId = clean($resp['data']['request_id'],255);
      $pdo->prepare("UPDATE manga SET cover_motion_request_id=?,cover_motion_status='queued' WHERE id=?")->execute([$requestId,$id]);
      out(['ok'=>true,'status'=>'queued','message'=>'ส่งงานสร้างปกเคลื่อนไหวแล้ว','request_id'=>$requestId]);
    }
    case 'animate_cover_status': {
      $id = (int)($data['id'] ?? 0);
      if ($id < 1) out(['ok'=>false,'message'=>'ไม่พบเรื่องที่เลือก'],422);
      $q = $pdo->prepare('SELECT id,cover_motion_url,cover_motion_request_id,cover_motion_status FROM manga WHERE id=? LIMIT 1');
      $q->execute([$id]); $m = $q->fetch(PDO::FETCH_ASSOC);
      if (!$m) out(['ok'=>false,'message'=>'ไม่พบเรื่องในคลัง'],404);
      if (!empty($m['cover_motion_url']) && (string)($m['cover_motion_status'] ?? '') === 'completed') out(['ok'=>true,'status'=>'completed','cover_motion_url'=>$m['cover_motion_url']]);
      $requestId = trim((string)($m['cover_motion_request_id'] ?? ''));
      if ($requestId === '') out(['ok'=>true,'status'=>'none','cover_motion_url'=>$m['cover_motion_url'] ?? null]);
      if (!preg_match('/^[A-Za-z0-9_-]{8,255}$/', $requestId)) out(['ok'=>false,'message'=>'รหัสงาน AI ไม่ถูกต้อง'],422);
      $falKey = trim((string)($FAL_KEY ?? ''));
      if ($falKey === '') out(['ok'=>false,'message'=>'ยังไม่ได้ตั้งค่า FAL_KEY ใน api/config.php'],503);
      $endpoint = 'fal-ai/wan/v2.2-5b/image-to-video';
      $statusResp = falCoverRequest('https://queue.fal.run/'.$endpoint.'/requests/'.rawurlencode($requestId).'/status', $falKey);
      if ($statusResp['http'] < 200 || $statusResp['http'] >= 300) {
        $providerDetail = falProviderText($statusResp['data']) . ' ' . (string)$statusResp['raw'];
        if (falBalanceExhausted($providerDetail)) out(['ok'=>false,'error_code'=>'FAL_BALANCE_EXHAUSTED','billing_url'=>'https://fal.ai/dashboard/billing','message'=>'บัญชี fal.ai ใช้ยอดเครดิตหมดหรือถูกล็อกชั่วคราว กรุณาตรวจสอบที่ fal.ai/dashboard/billing แล้วลองใหม่'],402);
        out(['ok'=>false,'message'=>'ตรวจสถานะ AI ไม่สำเร็จ (HTTP '.(int)$statusResp['http'].')'],502);
      }
      $rawStatus = strtoupper((string)($statusResp['data']['status'] ?? 'IN_QUEUE'));
      if (in_array($rawStatus,['IN_QUEUE','IN_PROGRESS','QUEUED','PENDING'],true)) {
        $pdo->prepare("UPDATE manga SET cover_motion_status='queued' WHERE id=?")->execute([$id]);
        out(['ok'=>true,'status'=>'queued','message'=>'AI กำลังสร้างวิดีโอปก']);
      }
      if (in_array($rawStatus,['FAILED','CANCELLED','CANCELED'],true)) {
        $providerDetail = falProviderText($statusResp['data']) . ' ' . (string)$statusResp['raw'];
        $pdo->prepare("UPDATE manga SET cover_motion_status='failed' WHERE id=?")->execute([$id]);
        if (falBalanceExhausted($providerDetail)) out(['ok'=>true,'status'=>'failed','error_code'=>'FAL_BALANCE_EXHAUSTED','message'=>'บัญชี fal.ai ใช้ยอดเครดิตหมดหรือถูกล็อกชั่วคราว กรุณาตรวจสอบที่ fal.ai/dashboard/billing ก่อนลองใหม่']);
        out(['ok'=>true,'status'=>'failed','message'=>'AI สร้างวิดีโอไม่สำเร็จ ลองใหม่ได้']);
      }
      if ($rawStatus !== 'COMPLETED') out(['ok'=>true,'status'=>'queued','message'=>'รอผลจาก AI']);
      $resultResp = falCoverRequest('https://queue.fal.run/'.$endpoint.'/requests/'.rawurlencode($requestId), $falKey);
      $videoUrl = trim((string)($resultResp['data']['video']['url'] ?? ''));
      if ($resultResp['http'] < 200 || $resultResp['http'] >= 300 || $videoUrl === '' || !filter_var($videoUrl,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($videoUrl,PHP_URL_SCHEME)),['http','https'],true)) {
        out(['ok'=>false,'message'=>'AI แจ้งว่าสร้างเสร็จแล้ว แต่ไม่พบ URL ไฟล์วิดีโอ'],502);
      }
      $pdo->prepare("UPDATE manga SET cover_motion_url=?,cover_motion_status='completed' WHERE id=? AND cover_motion_request_id=?")->execute([clean($videoUrl,1000),$id,$requestId]);
      out(['ok'=>true,'status'=>'completed','cover_motion_url'=>$videoUrl,'message'=>'สร้างปกเคลื่อนไหวสำเร็จ']);
    }
    case 'health':
      out(['ok' => true, 'version' => '17.6.8-electric-cover', 'php' => PHP_VERSION, 'time' => date(DATE_ATOM), 'database' => 'connected']);
    case 'list':
      $q = $pdo->query("SELECT m.*,COALESCE(m.type_id,m.category_id) type_id,c.name category_name,c.adult type_adult,(SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id) chapter_count,(SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id ORDER BY ch.sort_order DESC,ch.id DESC LIMIT 1) last_chapter,(SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chcur.sort_order FROM chapters chcur WHERE chcur.manga_id=m.id AND chcur.chapter=m.current_chapter LIMIT 1),CAST(SUBSTRING_INDEX(m.current_chapter,'.',1) AS DECIMAL(20,6)),0)) unread_count,(SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chs.sort_order FROM chapters chs WHERE chs.manga_id=m.id AND chs.chapter=m.last_seen_chapter LIMIT 1),-1)) new_chapter_count,(SELECT ch.chapter_url FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chcur.sort_order FROM chapters chcur WHERE chcur.manga_id=m.id AND chcur.chapter=m.current_chapter LIMIT 1),CAST(SUBSTRING_INDEX(m.current_chapter,'.',1) AS DECIMAL(20,6)),0) ORDER BY ch.sort_order ASC,ch.id ASC LIMIT 1) next_chapter_url,(SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chcur.sort_order FROM chapters chcur WHERE chcur.manga_id=m.id AND chcur.chapter=m.current_chapter LIMIT 1),CAST(SUBSTRING_INDEX(m.current_chapter,'.',1) AS DECIMAL(20,6)),0) ORDER BY ch.sort_order ASC,ch.id ASC LIMIT 1) next_chapter,(SELECT GROUP_CONCAT(DISTINCT g.name ORDER BY g.name SEPARATOR '||') FROM manga_genres mg JOIN genres g ON g.id=mg.genre_id WHERE mg.manga_id=m.id) genre_names,(SELECT GROUP_CONCAT(DISTINCT g.id ORDER BY g.id SEPARATOR ',') FROM manga_genres mg JOIN genres g ON g.id=mg.genre_id WHERE mg.manga_id=m.id) genre_ids,(SELECT GROUP_CONCAT(DISTINCT mc.collection_id ORDER BY mc.collection_id SEPARATOR ',') FROM manga_collections mc WHERE mc.manga_id=m.id) collection_ids FROM manga m LEFT JOIN categories c ON c.id=COALESCE(m.type_id,m.category_id) GROUP BY m.id ORDER BY COALESCE(m.last_read_at,m.updated_at) DESC,m.id DESC");
      out(['ok' => true, 'items' => $q->fetchAll(), 'types' => $pdo->query('SELECT id,name,adult FROM categories ORDER BY id')->fetchAll(), 'categories' => $pdo->query('SELECT id,name,adult FROM categories ORDER BY id')->fetchAll(), 'genres' => $pdo->query('SELECT id,name FROM genres ORDER BY name')->fetchAll()]);
    case 'get_manga':
      out(['ok' => true] + mangaPayload($pdo, (int)($data['id'] ?? 0)));
    case 'import_source':
      $source = safeRemote(clean($data['source_url'] ?? '', 1000));
      try {
        $r = scrape($source);
        out(['ok' => true, 'import' => $r]);
      } catch (Throwable $e) {
        $msg = $e->getMessage();
        $browserRequired = (bool)preg_match('/HTTP\s*(403|429)|ปฏิเสธคำขอ|ดึงหน้าเว็บต้นทางไม่สำเร็จ/iu', $msg);
        out(['ok' => false, 'message' => $msg, 'retry_with_extension' => true, 'browser_required' => $browserRequired, 'source_url' => $source], $browserRequired ? 409 : 502);
      }
    case 'add_manga':
      $source = safeRemote(clean($data['source_url'] ?? '', 1000));
      $title = clean($data['title'] ?? '', 255);
      $alt = clean($data['alt_title'] ?? '', 255);
      $cover = clean($data['cover_url'] ?? '', 1000);
      $typeId = (int)($data['type_id'] ?? 0);
      $status = (string)($data['status'] ?? 'reading');
      $rating = normalizeRating($data['rating'] ?? null);
      $completionStatus = (string)($data['completion_status'] ?? 'ongoing');
      if (!in_array($completionStatus, ['ongoing', 'completed'], true)) $completionStatus = 'ongoing';
      $note = clean($data['note'] ?? '', 5000);
      $genreIds = array_values(array_unique(array_map('intval', (array)($data['genre_ids'] ?? []))));
      $collectionIds = array_values(array_unique(array_map('intval', (array)($data['collection_ids'] ?? []))));
      $auto = !empty($data['auto_import']);

      if ($typeId < 1) $typeId = preferredTypeId($pdo);
      $q = $pdo->prepare('SELECT id,title FROM manga WHERE source_url=? LIMIT 1');
      $q->execute([$source]);
      if ($du = $q->fetch()) out(['ok' => false, 'message' => 'เรื่องนี้มีอยู่ในคลังแล้ว', 'duplicate' => $du], 409);

      $imp = null;
      $warning = null;
      if ($auto) {
        try {
          // New records should save quickly; a separate background request can perform full chapter discovery.
          $imp = scrape($source, true);
          $pdo = ensureDbAlive($pdo);
          if ($title === '' && ($imp['title'] ?? '') !== '') $title = $imp['title'];
          if ($cover === '' && ($imp['cover_url'] ?? '') !== '') $cover = $imp['cover_url'];
          if (!$genreIds) $genreIds = importedGenreIds($pdo, $imp['genres'] ?? []);
        } catch (Throwable $e) {
          $warning = $e->getMessage();
        }
      }
      if ($title === '') {
        $slug = extractMangaSlug($source);
        $title = cleanTitle(ucwords(str_replace(['-','_'], ' ', $slug)));
      }
      if ($title === '') $title = 'Imported Manga';

      $pdo = ensureDbAlive($pdo);
      $pdo->beginTransaction();
      try {
        $q = $pdo->prepare('INSERT INTO manga(title,alt_title,cover_url,source_url,category_id,type_id,status,rating,favorite,note,current_chapter,last_chapter,completion_status) VALUES(?,?,?,?,?,?,?,?,0,?,?,?,?)');
        $q->execute([$title, $alt ?: null, $cover ?: null, $source, $typeId, $typeId, in_array($status, ['reading', 'completed', 'planned', 'paused', 'dropped'], true) ? $status : 'reading', $rating, $note ?: null, '0', $imp['last_chapter'] ?? null, $completionStatus]);
        $id = (int)$pdo->lastInsertId();
        syncGenres($pdo, $id, $genreIds);
        syncCollections($pdo, $id, $collectionIds);
        $imported = upsertChapters($pdo, $id, $imp['chapters'] ?? []);
        $pdo->prepare("UPDATE manga SET last_chapter=(SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1),last_seen_chapter=(SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1),sync_status=CASE WHEN ? IS NULL OR ?='' THEN 'idle' ELSE 'success' END WHERE id=?")->execute([$id,$id,$imp['last_chapter']??null,$imp['last_chapter']??'',$id]);
        $rewardUnlocked=false; $completionCard=null;
        if($status==='completed'){[$completionCard,$rewardUnlocked]=ensureCompletionCard($pdo,$id);}
        $pdo->commit();
      } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
      }
      $expected = (int)($imp['total_chapters'] ?? 0);
      $found = (int)($imp['chapter_count'] ?? count($imp['chapters'] ?? []));
      $complete = $expected > 0 ? ($found >= $expected) : ($found > 0);
      if (!$complete) $warning = trim(($warning ? $warning . ' • ' : '') . "นำเข้าได้ {$found}/{$expected} Chapter — แหล่งข้อมูลยังเปิดไม่ครบตอน");
      out(['ok' => true, 'id' => $id, 'imported_chapters' => $imported, 'import_warning' => $warning, 'expected_chapters' => $expected, 'import_complete' => $complete, 'missing_chapters' => $complete ? 0 : max(0, $expected - $found), 'reward_unlocked' => $rewardUnlocked ?? false, 'completion_card' => $completionCard ?? null]);

    case 'reset_reading':
      $rid = (int)($data['id'] ?? $data['manga_id'] ?? 0);
      if ($rid < 1) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 422);
      $chk = $pdo->prepare('SELECT status FROM manga WHERE id=?');
      $chk->execute([$rid]);
      $curStatus = $chk->fetchColumn();
      if ($curStatus === false) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 404);
      $pdo->beginTransaction();
      try {
        $pdo->prepare('DELETE FROM reading_history WHERE manga_id=?')->execute([$rid]);
        $newStatus = ($curStatus === 'reading') ? 'planned' : $curStatus;
        $pdo->prepare("UPDATE manga SET current_chapter='0', last_read_at=NULL, status=? WHERE id=?")->execute([$newStatus, $rid]);
        $pdo->commit();
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        out(['ok' => false, 'message' => 'รีเซ็ตการอ่านไม่สำเร็จ'], 500);
      }
      out(['ok' => true, 'id' => $rid, 'status' => $newStatus, 'current_chapter' => '0']);

    case 'manga_history':
      $mid = (int)($data['manga_id'] ?? $data['id'] ?? 0);
      if ($mid < 1) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 422);
      $q = $pdo->prepare('SELECT id,chapter,source_url,detection_method,read_at FROM reading_history WHERE manga_id=? ORDER BY read_at DESC,id DESC LIMIT 200');
      $q->execute([$mid]);
      out(['ok' => true, 'items' => $q->fetchAll(PDO::FETCH_ASSOC)]);

    case 'recent_activity':
      out(['ok'=>true] + recentActivity($pdo));

    case 'list_collections':
      out(['ok'=>true,'collections'=>$pdo->query('SELECT id,name FROM collections ORDER BY id')->fetchAll()]);

    case 'collection_map':
      $map=[];
      foreach($pdo->query('SELECT manga_id,collection_id FROM manga_collections ORDER BY manga_id,collection_id')->fetchAll() as $r){
        $mid=(string)$r['manga_id'];
        if(!isset($map[$mid]))$map[$mid]=[];
        $map[$mid][]=(int)$r['collection_id'];
      }
      out(['ok'=>true,'map'=>$map]);

    case 'add_type':
      $name=clean($data['name']??'',80);$adult=!empty($data['adult'])?1:0;
      if($name==='')out(['ok'=>false,'message'=>'ชื่อประเภทว่าง'],422);
      $q=$pdo->prepare('SELECT id FROM categories WHERE LOWER(name)=LOWER(?)');$q->execute([$name]);
      if($q->fetch())out(['ok'=>false,'message'=>'มีประเภทนี้อยู่แล้ว'],409);
      $q=$pdo->prepare('INSERT INTO categories(name,adult) VALUES(?,?)');$q->execute([$name,$adult]);
      out(['ok'=>true,'id'=>(int)$pdo->lastInsertId()]);

    case 'delete_type':
      $id=(int)($data['id']??0);$q=$pdo->prepare('SELECT name FROM categories WHERE id=?');$q->execute([$id]);$name=$q->fetchColumn();
      if(!$name)out(['ok'=>false,'message'=>'ไม่พบประเภท'],404);
      if($name==='อื่นๆ')out(['ok'=>false,'message'=>'ไม่สามารถลบประเภท “อื่นๆ” ได้'],409);
      $other=(int)$pdo->query("SELECT id FROM categories WHERE name='อื่นๆ' LIMIT 1")->fetchColumn();
      $pdo->prepare('UPDATE manga SET type_id=?,category_id=? WHERE COALESCE(type_id,category_id)=?')->execute([$other,$other,$id]);
      $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);
      out(['ok'=>true]);

    case 'add_genre':
      $name=clean($data['name']??'',80);if($name==='')out(['ok'=>false,'message'=>'ชื่อแนวว่าง'],422);
      $q=$pdo->prepare('SELECT id FROM genres WHERE LOWER(name)=LOWER(?)');$q->execute([$name]);if($q->fetch())out(['ok'=>false,'message'=>'มีแนวนี้อยู่แล้ว'],409);
      $q=$pdo->prepare('INSERT INTO genres(name) VALUES(?)');$q->execute([$name]);out(['ok'=>true,'id'=>(int)$pdo->lastInsertId()]);

    case 'delete_genre':
      $id=(int)($data['id']??0);$pdo->prepare('DELETE FROM manga_genres WHERE genre_id=?')->execute([$id]);$pdo->prepare('DELETE FROM genres WHERE id=?')->execute([$id]);out(['ok'=>true]);

    case 'add_collection':
      $name=clean($data['name']??'',80);if($name==='')out(['ok'=>false,'message'=>'ชื่อ Collection ว่าง'],422);
      $q=$pdo->prepare('SELECT id FROM collections WHERE LOWER(name)=LOWER(?)');$q->execute([$name]);if($q->fetch())out(['ok'=>false,'message'=>'มี Collection นี้อยู่แล้ว'],409);
      $q=$pdo->prepare('INSERT INTO collections(name) VALUES(?)');$q->execute([$name]);out(['ok'=>true,'id'=>(int)$pdo->lastInsertId()]);

    case 'delete_collection':
      $id=(int)($data['id']??0);$pdo->prepare('DELETE FROM manga_collections WHERE collection_id=?')->execute([$id]);$pdo->prepare('DELETE FROM collections WHERE id=?')->execute([$id]);out(['ok'=>true]);

    case 'toggle_favorite':
      $id=(int)($data['id']??0);$pdo->prepare('UPDATE manga SET favorite=CASE WHEN favorite=1 THEN 0 ELSE 1 END WHERE id=?')->execute([$id]);$q=$pdo->prepare('SELECT favorite FROM manga WHERE id=?');$q->execute([$id]);out(['ok'=>true,'favorite'=>(int)$q->fetchColumn()]);

    case 'update_manga':
      $id=(int)($data['id']??0);$source=safeRemote(clean($data['source_url']??'',1000));$title=clean($data['title']??'',255);$alt=clean($data['alt_title']??'',255);$cover=clean($data['cover_url']??'',1000);$typeId=(int)($data['type_id']??0);$status=(string)($data['status']??'reading');$rating=normalizeRating($data['rating']??null);$completionStatus=(string)($data['completion_status']??'ongoing');if(!in_array($completionStatus,['ongoing','completed'],true))$completionStatus='ongoing';$note=clean($data['note']??'',5000);
      if($id<1||$title==='')out(['ok'=>false,'message'=>'ข้อมูลเรื่องไม่ครบ'],422);
      if($typeId<1)$typeId=preferredTypeId($pdo);
      $q=$pdo->prepare('SELECT id FROM manga WHERE source_url=? AND id<>? LIMIT 1');$q->execute([$source,$id]);if($q->fetch())out(['ok'=>false,'message'=>'URL นี้ถูกใช้กับเรื่องอื่นแล้ว'],409);
      if(!in_array($status,['reading','completed','planned','paused','dropped'],true))$status='reading';
      $q=$pdo->prepare('UPDATE manga SET title=?,alt_title=?,cover_url=?,source_url=?,category_id=?,type_id=?,status=?,rating=?,completion_status=?,note=? WHERE id=?');
      $q->execute([$title,$alt?:null,$cover?:null,$source,$typeId?:null,$typeId?:null,$status,$rating,$completionStatus,$note?:null,$id]);
      syncGenres($pdo,$id,(array)($data['genre_ids']??[]));syncCollections($pdo,$id,(array)($data['collection_ids']??[]));
      $rewardUnlocked=false; $completionCard=null;
      if($status==='completed'){[$completionCard,$rewardUnlocked]=ensureCompletionCard($pdo,$id);}
      out(['ok'=>true,'reward_unlocked'=>$rewardUnlocked,'completion_card'=>$completionCard]);

    case 'list_completion_cards':
      out(['ok'=>true,'cards'=>completionCards($pdo),'count'=>(int)$pdo->query('SELECT COUNT(*) FROM completion_cards')->fetchColumn()]);

    case 'get_completion_card':
      $id=(int)($data['id']??0);
      $q=$pdo->prepare('SELECT cc.*, CASE WHEN m.id IS NOT NULL THEN m.rating ELSE cc.rating END AS display_rating FROM completion_cards cc LEFT JOIN manga m ON m.id=cc.manga_id WHERE cc.id=? LIMIT 1');$q->execute([$id]);$card=$q->fetch(PDO::FETCH_ASSOC);
      if(!$card)out(['ok'=>false,'message'=>'ไม่พบการ์ด'],404);
      $card['id']=(int)$card['id'];$card['card_number']=$card['id'];$card['manga_id']=$card['manga_id']!==null?(int)$card['manga_id']:null;$card['chapter_count']=(int)$card['chapter_count'];$card['rating']=$card['display_rating']!==null?(float)$card['display_rating']:null;unset($card['display_rating']);
      out(['ok'=>true,'card'=>$card]);

    case 'update_completion_rarity':
      $id=(int)($data['id']??0);
      $rarity=strtolower(trim((string)($data['rarity_override']??'auto')));
      $allowed=['auto','common','common-ii','common-iii','common-iv','common-v','uncommon','uncommon-ii','uncommon-iii','uncommon-iv','uncommon-v','rare','rare-ii','rare-iii','rare-iv','rare-v','rare-vi','rare-vii','rare-viii','epic','epic-ii','epic-iii','epic-iv','epic-v','epic-vi','epic-vii','epic-viii','legendary','legendary-ii','mythic','divine','celestial','eternal'];
      if($id<1)out(['ok'=>false,'message'=>'ไม่พบการ์ดที่ต้องการแก้ไข'],422);
      if(!in_array($rarity,$allowed,true))out(['ok'=>false,'message'=>'ระดับการ์ดไม่ถูกต้อง'],422);
      $check=$pdo->prepare('SELECT id FROM completion_cards WHERE id=? LIMIT 1');$check->execute([$id]);
      if(!$check->fetchColumn())out(['ok'=>false,'message'=>'ไม่พบการ์ดในคอลเลกชัน'],404);
      $value=$rarity==='auto'?null:$rarity;
      $pdo->prepare('UPDATE completion_cards SET rarity_override=? WHERE id=?')->execute([$value,$id]);
      out(['ok'=>true,'id'=>$id,'rarity_override'=>$value]);

    case 'delete_completion_card':
      $id=(int)($data['id']??0);if($id<1)out(['ok'=>false,'message'=>'ไม่พบการ์ด'],422);
      $pdo->prepare('DELETE FROM completion_cards WHERE id=?')->execute([$id]);
      out(['ok'=>true]);

    case 'export_all':
      out(['ok'=>true,'backup'=>exportBackup($pdo)]);

    case 'save_imported_chapters':
      $id=(int)($data['id']??0);
      $source=safeRemote(clean($data['source_url']??'',1000));
      $imp=(array)($data['import']??[]);
      if($id<1||empty($imp['chapters'])||!is_array($imp['chapters']))out(['ok'=>false,'message'=>'ไม่มี Chapter สำหรับบันทึก'],422);
      $q=$pdo->prepare('SELECT source_url FROM manga WHERE id=? LIMIT 1');$q->execute([$id]);$registered=$q->fetchColumn();
      if($registered===false)out(['ok'=>false,'message'=>'ไม่พบเรื่องที่ต้องการอัปเดต'],404);
      if(canon((string)$registered)!==canon($source))out(['ok'=>false,'message'=>'URL ต้นทางไม่ตรงกับเรื่องในฐานข้อมูล ป้องกันการบันทึกผิดเรื่อง'],409);
      $expected=(int)($imp['total_chapters']??0);
      $rows=[];$seen=[];
      foreach((array)$imp['chapters'] as $c){
        if(!is_array($c))continue;
        $label=chapterLabel($c['chapter']??'');$rawChapterUrl=canon((string)($c['chapter_url']??''));
        if($label===''||$rawChapterUrl===''||!str_starts_with($rawChapterUrl,'http'))continue;
        $url=safeRemote($rawChapterUrl);
        $key=strtolower($label);if(isset($seen[$key]))continue;$seen[$key]=true;$rows[]=$c;
      }
      if(!$rows)out(['ok'=>false,'message'=>'ไม่พบ Chapter ที่ตรวจรูปแบบได้'],422);
      [$exLabels,$exMax]=syncExistingChapters($pdo,$id);
      $safety=syncSafetyReport($exLabels,$exMax,$rows);
      if($safety['existing_count']>=5&&$safety['overlap']<0.6)out(['ok'=>false,'needs_review'=>true,'message'=>"ตอนที่ดึงมาไม่ตรงกับตอนเดิม (ตรงเพียง {$safety['matched']} จาก {$safety['existing_count']} ตอน) จึงไม่บันทึก"],409);
      $rows=$safety['kept'];
      if(!$rows)out(['ok'=>false,'message'=>'ไม่พบ Chapter ที่ปลอดภัยสำหรับบันทึก'],422);
      $found=count($rows);$complete=$expected>0&&$found>=$expected;
      $status=$complete?'success':($expected>0?'partial':'unverifiable');
      $error=$complete?null:($expected>0?"ดึงได้ {$found} จาก {$expected} ตอน; เก็บข้อมูลเดิมไว้และยังไม่ยืนยันว่าครบ":"เว็บไม่แจ้งจำนวนตอนที่ยืนยันได้; เก็บข้อมูลเดิมไว้");
      $pdo=ensureDbAlive($pdo);$pdo->beginTransaction();
      try{
        $rows=filterAliasChapters($pdo,$id,$rows);
        $inserted=upsertChapters($pdo,$id,$rows,true,true);
        if ($complete && isManghahaHost((string)(parse_url((string)$registered, PHP_URL_HOST) ?? '')) && str_contains((string)($imp['adapter'] ?? ''), 'manghaha-pagination-complete')) {
          $badListQ=$pdo->prepare('SELECT id,chapter_url FROM chapters WHERE manga_id=? AND source_managed=1');$badListQ->execute([$id]);
          $deleteBadListQ=$pdo->prepare('DELETE FROM chapters WHERE id=? AND source_managed=1 AND user_edited=0');
          foreach($badListQ->fetchAll(PDO::FETCH_ASSOC) as $badRow){if(isManghahaCatalogPageUrl(canon((string)($badRow['chapter_url']??'')),(string)$registered))$deleteBadListQ->execute([(int)$badRow['id']]);}
        }
        $latestQ=$pdo->prepare('SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1');$latestQ->execute([$id]);$latest=$latestQ->fetchColumn();
        $pdo->prepare('UPDATE manga SET last_chapter=COALESCE(?,last_chapter),last_seen_chapter=COALESCE(NULLIF(last_seen_chapter,\'\'),?),last_sync_at=CURRENT_TIMESTAMP,sync_status=?,sync_error=? WHERE id=?')->execute([$latest!==false?$latest:null,$latest!==false?$latest:null,$status,$error,$id]);
        if (!empty($data['title_was_blank']) && clean($data['imported_title'] ?? '',255) !== '') {
          $fallbackTitle = cleanTitle(ucwords(str_replace(['-','_'], ' ', extractMangaSlug((string)$registered))));
          if ($fallbackTitle === '') $fallbackTitle = 'Imported Manga';
          // Do not overwrite a title if the user has already edited it while the import was running.
          $pdo->prepare('UPDATE manga SET title=? WHERE id=? AND title=?')->execute([clean($data['imported_title'],255),$id,$fallbackTitle]);
        }
        if (!empty($data['cover_was_blank']) && clean($data['imported_cover_url'] ?? '',1000) !== '') {
          $newCover = safeRemote(clean($data['imported_cover_url'],1000));
          $pdo->prepare('UPDATE manga SET cover_url=? WHERE id=? AND (cover_url IS NULL OR cover_url=\'\')')->execute([$newCover,$id]);
        }
        // Preserve the site's published title as an alias when it differs from the user's chosen title.
        $sourceTitle = clean($data['imported_title'] ?? '', 255);
        if ($sourceTitle !== '') {
          $aliasQ = $pdo->prepare('SELECT title,alt_title FROM manga WHERE id=? AND source_url=? LIMIT 1');
          $aliasQ->execute([$id, $source]);
          $aliasRow = $aliasQ->fetch(PDO::FETCH_ASSOC) ?: ['title'=>'','alt_title'=>''];
          $normalizeAlias = static function (string $value): string {
            $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
            $value = preg_replace('/[^\\p{L}\\p{N}]+/u', ' ', $value) ?? $value;
            return trim(preg_replace('/\\s+/u', ' ', $value) ?? $value);
          };
          $sourceKey = $normalizeAlias($sourceTitle);
          $known = $normalizeAlias(clean($aliasRow['title'] ?? '',255)) === $sourceKey;
          $aliases = array_values(array_filter(array_map('trim', preg_split('/[|;\\n]+/', (string)($aliasRow['alt_title'] ?? '')) ?: [])));
          foreach ($aliases as $alias) { if ($normalizeAlias($alias) === $sourceKey) { $known = true; break; } }
          if (!$known) {
            $aliases[] = $sourceTitle;
            $joinedText = implode(' | ', array_unique($aliases));
            $joined = function_exists('mb_substr') ? mb_substr($joinedText, 0, 255, 'UTF-8') : substr($joinedText, 0, 255);
            $pdo->prepare('UPDATE manga SET alt_title=? WHERE id=? AND source_url=?')->execute([$joined !== '' ? $joined : null, $id, $source]);
          }
        }
        $pdo->commit();
      }catch(Throwable $e){$pdo->rollBack();throw $e;}
      $totalQ=$pdo->prepare('SELECT COUNT(*) FROM chapters WHERE manga_id=?');$totalQ->execute([$id]);
      out(['ok'=>true,'manga_id'=>$id,'new_chapters'=>$inserted,'chapter_count'=>(int)$totalQ->fetchColumn(),'expected_chapters'=>$expected,'imported_chapter_count'=>$found,'import_complete'=>$complete,'sync_status'=>$status,'sync_error'=>$error,'adapter'=>$imp['adapter']??'generic']);

    case 'set_import_status':
      $id=(int)($data['id']??0);$source=safeRemote(clean($data['source_url']??'',1000));
      $status=in_array(($data['sync_status']??''),['running','blocked','error','partial','unverifiable','review'],true)?$data['sync_status']:'error';
      $message=clean($data['sync_error']??'นำเข้าไม่สำเร็จ',4000);
      if($id<1)out(['ok'=>false,'message'=>'ไม่พบเรื่อง'],422);
      $q=$pdo->prepare('UPDATE manga SET last_sync_at=CURRENT_TIMESTAMP,sync_status=?,sync_error=? WHERE id=? AND source_url=?');$q->execute([$status,$message,$id,$source]);
      if(!$q->rowCount()){
        $check=$pdo->prepare('SELECT id FROM manga WHERE id=? AND source_url=? LIMIT 1');$check->execute([$id,$source]);if(!$check->fetchColumn())out(['ok'=>false,'message'=>'URL ต้นทางไม่ตรงกับเรื่อง'],409);
      }
      out(['ok'=>true,'sync_status'=>$status,'sync_error'=>$message]);

    case 'mark_sync_ok':
      // v17.17.10: ผู้ใช้ตรวจแล้วว่าปกติ -> ล้างสถานะ "ต้องตรวจสอบ" (ไม่แตะตอน/ความคืบหน้า)
      $ids=array_values(array_unique(array_filter(array_map('intval',(array)($data['ids']??[])),static fn($v)=>$v>0)));
      $ids=array_slice($ids,0,500);
      if(!$ids)out(['ok'=>false,'message'=>'ไม่ได้เลือกเรื่อง'],422);
      $ph=implode(',',array_fill(0,count($ids),'?'));
      $q=$pdo->prepare("UPDATE manga SET sync_status='success',sync_error=NULL,last_sync_at=COALESCE(last_sync_at,CURRENT_TIMESTAMP) WHERE id IN ($ph) AND sync_status IN ('partial','unverifiable','review','error','blocked')");
      $q->execute($ids);
      out(['ok'=>true,'updated'=>$q->rowCount()]);

    case 'import_backup':
      $backup=(array)($data['backup']??[]);$r=restoreBackup($pdo,$backup);out(['ok'=>true,'manga'=>$r['manga'],'chapters'=>$r['chapters']]);

    case 'mark_new_seen':
      $id=(int)($data['id']??0);
      if($id<1)out(['ok'=>false,'message'=>'ไม่พบเรื่อง'],422);
      $q=$pdo->prepare('SELECT last_chapter FROM manga WHERE id=? LIMIT 1');$q->execute([$id]);$latest=$q->fetchColumn();
      if($latest===false)out(['ok'=>false,'message'=>'ไม่พบเรื่อง'],404);
      $realQ=$pdo->prepare('SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1');$realQ->execute([$id]);$real=$realQ->fetchColumn();
      if($real!==false&&$real!==null)$latest=$real;
      $pdo->prepare('UPDATE manga SET last_seen_chapter=? WHERE id=?')->execute([$latest!==null?(string)$latest:null,$id]);
      out(['ok'=>true,'last_seen_chapter'=>$latest]);

    case 'mark_all_new_seen':
      $pdo->exec('UPDATE manga m SET m.last_seen_chapter=(SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id ORDER BY ch.sort_order DESC,ch.id DESC LIMIT 1) WHERE EXISTS (SELECT 1 FROM chapters ce WHERE ce.manga_id=m.id)');
      out(['ok'=>true]);

    case 'match_url':
      $url=safeRemote(clean($data['url']??$data['source_url']??'',1000));
      $q=$pdo->prepare('SELECT * FROM manga WHERE source_url=? LIMIT 1');$q->execute([$url]);$m=$q->fetch();
      if(!$m)out(['ok'=>true,'matched'=>false]);
      out(['ok'=>true,'matched'=>true,'manga_id'=>(int)$m['id'],'manga'=>$m]);

    case 'browser_import':
      browserImport($pdo,$data);

    case 'add_chapter':
      $mangaId=(int)($data['manga_id']??0);$ch=chapterLabel($data['chapter']??'');$url=safeRemote(clean($data['chapter_url']??'',1000));$title=clean($data['title']??'',255);
      if(!$mangaId||$ch==='')out(['ok'=>false,'message'=>'ข้อมูล Chapter ไม่ครบ'],422);
      upsertChapters($pdo,$mangaId,[['chapter'=>$ch,'title'=>$title,'chapter_url'=>$url,'keep_slash'=>str_ends_with($url,'/'),'release_date'=>$data['release_date']??null,'sort_order'=>chapterSortOrder($ch)]], false);
      out(['ok'=>true]);

    case 'edit_chapter':
      $id=(int)($data['id']??0);if(!$id)out(['ok'=>false,'message'=>'ไม่พบตอน'],422);
      $title=clean($data['title']??'',255);$url=clean($data['chapter_url']??'',1000);
      if($url==='')out(['ok'=>false,'message'=>'กรุณาใส่ลิงก์ตอน'],422);
      $url=safeRemote($url); // เก็บตามที่ผู้ใช้พิมพ์ รวมถึง "/" ท้ายลิงก์ (บางเว็บ 404 ถ้าไม่มี /)
      $q=$pdo->prepare('SELECT id FROM chapters WHERE id=?');$q->execute([$id]);
      if(!$q->fetchColumn())out(['ok'=>false,'message'=>'ไม่พบตอน'],404);
      // user_edited=1: ซิงก์รอบถัดไปจะไม่เขียนทับชื่อ/ลิงก์ที่แก้เอง และไม่ลบตอนนี้
      $pdo->prepare('UPDATE chapters SET title=?,chapter_url=?,user_edited=1 WHERE id=?')->execute([$title!==''?$title:null,$url,$id]);
      out(['ok'=>true]);

    case 'delete_chapter':
      $id=(int)($data['id']??0);if(!$id)out(['ok'=>false,'message'=>'ไม่พบตอน'],422);
      $q=$pdo->prepare('SELECT manga_id FROM chapters WHERE id=?');$q->execute([$id]);$mid=(int)$q->fetchColumn();
      $pdo->prepare('DELETE FROM chapters WHERE id=?')->execute([$id]);
      if($mid)$pdo->prepare('UPDATE manga SET last_chapter=(SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1) WHERE id=?')->execute([$mid,$mid]);
      out(['ok'=>true]);

    case 'delete_manga':
      $id = (int)($data['id'] ?? 0);
      foreach (['manga_genres', 'manga_collections', 'reading_history', 'chapters'] as $t) {
        $pdo->prepare("DELETE FROM {$t} WHERE manga_id=?")->execute([$id]);
      }
      $pdo->prepare('DELETE FROM manga WHERE id=?')->execute([$id]);
      out(['ok' => true]);

    case 'update_progress':
    case 'update_current_chapter':
    case 'read_chapter':
    case 'save_history':
    case 'mark_read':
    case 'read':
    case 'save_progress':
    case 'get_chapter':
    case 'get_chapter_url':
    case 'get_next_chapter':
    case 'continue_read':
    case 'read_next':
    case 'get_read_url':
    case 'open_chapter':
    case 'track':
    case 'track_read':
    case 'log_history':
    case 'history_add':
    case 'manga_read':
    case 'update_read':
    case 'chapter_read':
    case 'set_current_chapter':
    case 'update_chapter':
    case 'go_to_chapter':
    case 'click_chapter':
    case 'history':
    case 'progress':
      handleReadChapter($pdo, $data);

    case 'sync_preview':
    case 'sync_manga':
      $id = (int)($data['id'] ?? 0);
      $q = $pdo->prepare('SELECT source_url FROM manga WHERE id=?');
      $q->execute([$id]);
      $source = $q->fetchColumn();
      if (!$source) out(['ok' => false, 'message' => 'ไม่พบเรื่อง'], 404);
      try {
        $imp = syncScrapeCached((string)$source, $action === 'sync_preview', ($action === 'sync_manga' && !empty($data['use_preview'])));
      } catch (Throwable $e) {
        $msg = $e->getMessage();
        $browserRequired = (bool)preg_match('/HTTP\s*(403|429)|ปฏิเสธคำขอ|ดึงหน้าเว็บต้นทางไม่สำเร็จ/iu', $msg);
        try { $pdo=ensureDbAlive($pdo); $pdo->prepare("UPDATE manga SET last_sync_at=CURRENT_TIMESTAMP,sync_status=?,sync_error=? WHERE id=?")->execute([$browserRequired?'blocked':'error',clean($msg,4000),$id]); } catch(Throwable $ignored) {}
        out(['ok' => false, 'message' => $msg, 'retry_with_extension' => true, 'browser_required' => $browserRequired, 'manga_id' => $id, 'source_url' => $source], $browserRequired ? 409 : 502);
      }
      $pdo = ensureDbAlive($pdo);
      $expected = (int)($imp['total_chapters'] ?? 0);
      $found = (int)($imp['chapter_count'] ?? count($imp['chapters'] ?? []));
      $complete = $expected > 0 && $found >= $expected;
      $syncState = $complete ? 'complete' : ($expected > 0 ? 'partial' : 'unverifiable');
      $previewRows=[];
      $previewLabels=[];
      $duplicatePreviewLabels=false;
      foreach (($imp['chapters'] ?? []) as $c) {
        $lab=chapterLabel($c['chapter']??'');
        $url=canon((string)($c['chapter_url']??''));
        if ($lab==='') continue;
        if (isset($previewLabels[$lab])) $duplicatePreviewLabels=true;
        $previewLabels[$lab]=true;
        $previewRows[]=['chapter'=>$lab,'title'=>clean($c['title']??'',255),'chapter_url'=>$url];
      }
      $unparsedCount=max(0,$found-count($previewRows));
      [$exLabels,$exMax]=syncExistingChapters($pdo,$id);
      $safety=syncSafetyReport($exLabels,$exMax,$imp['chapters'] ?? []);
      $mismatch=$safety['existing_count']>=5 && $safety['overlap']<0.6;
      if ($action === 'sync_preview') {
        out(['ok'=>true,'preview'=>true,'manga_id'=>$id,'source_url'=>$source,'expected_chapters'=>$expected,'chapter_count'=>$found,'unparsed_chapter_count'=>$unparsedCount,'duplicate_chapter_labels'=>$duplicatePreviewLabels,'missing_chapters'=>$expected>0?max(0,$expected-$found):null,'sync_state'=>$syncState,'last_found'=>$previewRows?end($previewRows)['chapter']:null,'existing_count'=>$safety['existing_count'],'existing_matched'=>$safety['matched'],'suspicious_labels'=>$safety['dropped'],'chapters'=>$previewRows]);
      }
      // v17.17.9: never overwrite/delete our chapters with a list that doesn't resemble them.
      if ($mismatch && empty($data['preserve_existing'])) {
        out(['ok'=>false,'needs_review'=>true,'message'=>"ตอนที่ดึงมาไม่ตรงกับตอนเดิม (ตรงเพียง {$safety['matched']} จาก {$safety['existing_count']} ตอน) จึงไม่เขียนทับ ตรวจสอบก่อนบันทึก",'manga_id'=>$id,'source_url'=>$source,'expected_chapters'=>$expected,'chapter_count'=>$found,'existing_count'=>$safety['existing_count'],'existing_matched'=>$safety['matched'],'sync_state'=>$syncState],409);
      }
      if ($safety['existing_count']>0 && $safety['overlap']<0.9) $data['preserve_existing']=1; // insert-only, no overwrite, no delete
      $imp['chapters']=$safety['kept'];
      if (!$complete && empty($data['allow_partial'])) {
        out(['ok'=>false,'needs_review'=>true,'message'=>$syncState==='partial'?'ดึง Chapter ได้ไม่ครบตามจำนวนที่เว็บแจ้ง':'เว็บไม่แจ้งจำนวน Chapter ทั้งหมด จึงตรวจความครบถ้วนไม่ได้','manga_id'=>$id,'source_url'=>$source,'expected_chapters'=>$expected,'chapter_count'=>$found,'unparsed_chapter_count'=>$unparsedCount,'duplicate_chapter_labels'=>$duplicatePreviewLabels,'missing_chapters'=>$expected>0?max(0,$expected-$found):null,'sync_state'=>$syncState],409);
      }
      if (($unparsedCount>0 || $duplicatePreviewLabels) && empty($data['preserve_existing'])) {
        out(['ok'=>false,'needs_review'=>true,'message'=>$unparsedCount>0?'มีรายการที่อ่านเลข Chapter ไม่ได้ ต้องตรวจสอบก่อนบันทึก':'พบเลข Chapter ซ้ำ ต้องตรวจสอบก่อนบันทึก','manga_id'=>$id,'source_url'=>$source,'expected_chapters'=>$expected,'chapter_count'=>$found,'unparsed_chapter_count'=>$unparsedCount,'duplicate_chapter_labels'=>$duplicatePreviewLabels,'missing_chapters'=>$expected>0?max(0,$expected-$found):null,'sync_state'=>$syncState],409);
      }
      $new = 0;
      $syncRow = [];
      $writeError = null;
      for ($dbAttempt=0; $dbAttempt<2; $dbAttempt++) {
        try {
          $pdo = ensureDbAlive($pdo);
          if ($pdo->inTransaction()) $pdo->rollBack();
          $pdo->beginTransaction();

          // ซิงก์แบบเพิ่ม/แก้ไขเท่านั้น ไม่ลบตอนเดิม
          $oldQ = $pdo->prepare('SELECT chapter FROM chapters WHERE manga_id=?');
          $oldQ->execute([$id]);
          $before = array_flip(array_map('strval', $oldQ->fetchAll(PDO::FETCH_COLUMN)));

          $chaptersForWrite = $imp['chapters'] ?? [];
          if (!empty($data['preserve_existing'])) {
            // Conservative write: in reviewed/partial imports, do not overwrite a label
            // when the same label was attached to multiple source URLs.
            $labelCounts=[];
            foreach ($chaptersForWrite as $candidate) {
              $candidateLabel=chapterLabel($candidate['chapter']??'');
              if ($candidateLabel!=='') $labelCounts[$candidateLabel]=($labelCounts[$candidateLabel]??0)+1;
            }
            $chaptersForWrite=array_values(array_filter($chaptersForWrite,static function($candidate) use ($labelCounts) {
              $candidateLabel=chapterLabel($candidate['chapter']??'');
              return $candidateLabel!=='' && ($labelCounts[$candidateLabel]??0)===1 && trim((string)($candidate['chapter_url']??''))!=='';
            }));
          }
          $chaptersForWrite = filterAliasChapters($pdo, $id, $chaptersForWrite);
          $insertedNow = upsertChapters($pdo, $id, $chaptersForWrite, true, !empty($data['preserve_existing']));

          // ถ้ารอบนี้ยืนยันจำนวนตอนครบจริง ให้ล้าง Chapter ที่เคยถูกดึงผิด/ค้างจากรอบเก่า
          // แต่ไม่แตะตอนที่ผู้ใช้เพิ่มเอง (source_managed=0) และไม่ลบอะไรเมื่อ source ให้ข้อมูลไม่ครบ
          if ($expected > 0 && $found >= $expected && empty($data['preserve_existing'])) {
            $keepLabels = [];
            $keepUrls = [];
            $keepKeys = [];
            foreach (($imp['chapters'] ?? []) as $c) {
              $lab = chapterLabel($c['chapter'] ?? '');
              $url = canon((string)($c['chapter_url'] ?? ''));
              if ($lab !== '') { $keepLabels[(string)$lab] = true; $so = chapterSortOrder($lab); if ($so > 0) $keepKeys[number_format($so, 6, '.', '')] = true; }
              if ($url !== '') $keepUrls[$url] = true;
            }
            $oldManagedQ = $pdo->prepare('SELECT id,chapter,chapter_url FROM chapters WHERE manga_id=? AND source_managed=1');
            $oldManagedQ->execute([$id]);
            $deleteManagedQ = $pdo->prepare('DELETE FROM chapters WHERE id=? AND source_managed=1 AND user_edited=0');
            foreach ($oldManagedQ->fetchAll(PDO::FETCH_ASSOC) as $r) {
              $oldLabel = (string)($r['chapter'] ?? '');
              $oldUrl = canon((string)($r['chapter_url'] ?? ''));
              $oldSo = chapterSortOrder($oldLabel);
              $oldKeyHit = $oldSo > 0 && isset($keepKeys[number_format($oldSo, 6, '.', '')]);
              if (!isset($keepLabels[$oldLabel]) && !isset($keepUrls[$oldUrl]) && !$oldKeyHit) {
                $deleteManagedQ->execute([(int)$r['id']]);
              }
            }
          }

          // ลบแถวที่เลขตอนผิดจากการดึงรอบก่อน แต่แตะเฉพาะ URL ที่รอบนี้ยืนยันได้
          $labelByUrl = [];
          foreach (($imp['chapters'] ?? []) as $c) {
            $lab = chapterLabel($c['chapter'] ?? '');
            $u = canon((string)($c['chapter_url'] ?? ''));
            if ($lab !== '' && $u !== '') $labelByUrl[$u] = $lab;
          }
          $staleQ = $pdo->prepare('SELECT id,chapter,chapter_url,source_managed FROM chapters WHERE manga_id=?');
          $staleQ->execute([$id]);
          $delQ = $pdo->prepare('DELETE FROM chapters WHERE id=? AND source_managed=1 AND user_edited=0');
          foreach ($staleQ->fetchAll() as $r) {
            $u = canon((string)$r['chapter_url']);
            if (empty($data['preserve_existing']) && (int)($r['source_managed']??1)===1 && $u !== '' && isset($labelByUrl[$u]) && (string)$labelByUrl[$u] !== (string)$r['chapter']) {
              $delQ->execute([(int)$r['id']]);
            }
          }

          // Clean previously mis-imported page=1/page=2 rows after a full Manghaha catalog crawl.
          // Only source-managed rows are eligible; never touch manually added chapters.
          if ($complete && empty($data['preserve_existing']) && isManghahaHost((string)(parse_url((string)$source, PHP_URL_HOST) ?? '')) && str_contains((string)($imp['adapter'] ?? ''), 'manghaha-pagination-complete')) {
            $badListQ = $pdo->prepare('SELECT id,chapter_url FROM chapters WHERE manga_id=? AND source_managed=1');
            $badListQ->execute([$id]);
            foreach ($badListQ->fetchAll(PDO::FETCH_ASSOC) as $badRow) {
              if (isManghahaCatalogPageUrl(canon((string)($badRow['chapter_url'] ?? '')), (string)$source)) {
                $delQ->execute([(int)$badRow['id']]);
              }
            }
          }

          $new = (int)$insertedNow; // นับเฉพาะตอนที่เพิ่มจริง (ไม่นับตอนเดิมที่ซ้ำ/ป้ายต่างกัน)

          if (count($before) === 0) {
            $pdo->prepare('UPDATE manga m SET m.last_seen_chapter=(SELECT ch.chapter FROM chapters ch WHERE ch.manga_id=m.id ORDER BY ch.sort_order DESC,ch.id DESC LIMIT 1) WHERE m.id=? AND m.last_seen_chapter IS NULL')->execute([$id]);
          }
          $shouldUpdateLatest = (!$complete && !empty($data['allow_partial'])) || ($complete && empty($data['preserve_existing']));
          if (!$complete) {
            $storedSyncStatus = $expected > 0 ? 'partial' : 'unverifiable';
            $storedSyncError = $expected > 0 ? "ดึงได้ {$found} จาก {$expected} ตอน; เก็บ Chapter เดิมไว้" : 'เว็บไม่แจ้งจำนวนตอนทั้งหมด; ยังยืนยันความครบถ้วนไม่ได้';
          } elseif (!empty($data['preserve_existing'])) {
            $storedSyncStatus = 'review';
            $storedSyncError = 'บันทึกแบบปลอดภัยและเก็บ Chapter เดิมไว้ เนื่องจากผลซิงก์มีจุดน่าสงสัย';
          } else {
            $storedSyncStatus = 'success';
            $storedSyncError = null;
          }
          $pdo->prepare("UPDATE manga SET last_chapter=IF(?,(SELECT chapter FROM chapters WHERE manga_id=? ORDER BY sort_order DESC,id DESC LIMIT 1),last_chapter),last_sync_at=CURRENT_TIMESTAMP,sync_status=?,sync_error=? WHERE id=?")->execute([$shouldUpdateLatest?1:0,$id,$storedSyncStatus,$storedSyncError,$id]);
          $latestQ=$pdo->prepare('SELECT m.last_chapter,m.last_seen_chapter,(SELECT COUNT(*) FROM chapters ch WHERE ch.manga_id=m.id AND ch.sort_order>COALESCE((SELECT chs.sort_order FROM chapters chs WHERE chs.manga_id=m.id AND chs.chapter=m.last_seen_chapter LIMIT 1),-1)) AS new_chapter_count FROM manga m WHERE m.id=? LIMIT 1');
          $latestQ->execute([$id]);
          $syncRow=$latestQ->fetch(PDO::FETCH_ASSOC)?:[];
          $pdo->commit();
          $writeError=null;
          break;
        } catch (Throwable $e) {
          $writeError=$e;
          try { if ($pdo->inTransaction()) $pdo->rollBack(); } catch (Throwable $ignored) {}
          if (isTransientDbError($e) && $dbAttempt===0) {
            usleep(350000);
            try { $pdo=ensureDbAlive($pdo); } catch (Throwable $ignored) {}
            continue;
          }
          break;
        }
      }
      if ($writeError !== null) {
        $msg=$writeError->getMessage();
        $retryable=isTransientDbError($writeError);
        try {
          $pdo=ensureDbAlive($pdo);
          $pdo->prepare("UPDATE manga SET sync_status='error',sync_error=? WHERE id=?")->execute([clean($msg,4000),$id]);
        } catch(Throwable $ignored) {}
        out(['ok'=>false,'message'=>$retryable?'ฐานข้อมูลขาดการเชื่อมต่อชั่วคราว: '.$msg:$msg,'manga_id'=>$id,'retryable'=>$retryable,'sync_status'=>'error'], $retryable?503:500);
      }

      out([
        'ok' => true,
        'new_chapters' => $new,
        'chapter_count' => $found,
        'expected_chapters' => $expected,
        'import_complete' => $complete,
        'sync_state' => $syncState,
        'missing_chapters' => $expected > 0 ? max(0, $expected - $found) : null,
        'last_chapter' => $syncRow['last_chapter'] ?? null,
        'last_seen_chapter' => $syncRow['last_seen_chapter'] ?? null,
        'new_chapter_count' => (int)($syncRow['new_chapter_count'] ?? 0),
        'sync_status' => $storedSyncStatus ?? 'success',
        'sync_error' => $storedSyncError ?? null
      ]);

    default:
      if (isset($data['id']) || isset($data['manga_id'])) {
        handleReadChapter($pdo, $data);
      }
      out(['ok' => false, 'message' => 'Action ไม่ถูกต้อง'], 400);
  }
} catch (Throwable $e) {
  out(['ok' => false, 'message' => $e->getMessage()], 500);
}