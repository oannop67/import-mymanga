<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
try {
  $q=$pdo->query('SELECT 1');
  echo json_encode(['ok'=>true,'db'=>true,'php'=>PHP_VERSION,'time'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'db'=>false,'message'=>'เชื่อมฐานข้อมูลไม่ได้'],JSON_UNESCAPED_UNICODE);
}
