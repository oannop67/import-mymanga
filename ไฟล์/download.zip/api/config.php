<?php
declare(strict_types=1);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// 1. ตรวจสอบ Hostname จากหน้า "ฐานข้อมูล MySQL" ของบัญชีใหม่นี้
$host = 'sql212.infinityfree.com'; 

// 2. ชื่อฐานข้อมูลของบัญชีใหม่ (เช่น if0_43069900_mymanga)
$db   = 'if0_43069900_mymangapro'; 

// 3. ชื่อผู้ใช้ MySQL ของบัญชีใหม่
$user = 'if0_43069900'; 

// 4. รหัสผ่านถูกต้องแล้ว
$pass = 'Perdping0809'; 

$MANGA_API_TOKEN = 'MyMangaV11LocalToken2026';

$pdo = new PDO(
    "mysql:host={$host};dbname={$db};charset=utf8mb4",
    $user,
    $pass,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
);
$FAL_KEY = 'fal_sk_69a1177e4f2e4c6ba3da17ee8deea8b7:6fc6617382ffca06ba7bafd602ee5d5a';
