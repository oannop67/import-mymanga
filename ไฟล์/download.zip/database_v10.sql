CREATE DATABASE IF NOT EXISTS manga_tracker CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE manga_tracker;

CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,adult TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS genres(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS collections(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS manga_genres(manga_id INT NOT NULL,genre_id INT NOT NULL,PRIMARY KEY(manga_id,genre_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS manga_collections(manga_id INT NOT NULL,collection_id INT NOT NULL,PRIMARY KEY(manga_id,collection_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS chapters(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,title VARCHAR(255) NULL,chapter_url VARCHAR(1000) NOT NULL,release_date DATE NULL,sort_order DECIMAL(20,6) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_manga_chapter(manga_id,chapter),INDEX idx_ch_sort(manga_id,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS reading_history(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,source_url VARCHAR(1000) NULL,detection_method VARCHAR(30) NOT NULL DEFAULT 'web',read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_hist_manga(manga_id,read_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS app_settings(setting_key VARCHAR(80) PRIMARY KEY,setting_value TEXT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @sql=IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='categories' AND COLUMN_NAME='adult')=0,'ALTER TABLE categories ADD COLUMN adult TINYINT(1) NOT NULL DEFAULT 0 AFTER name','SELECT 1');PREPARE s FROM @sql;EXECUTE s;DEALLOCATE PREPARE s;
SET @sql=IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='manga' AND COLUMN_NAME='last_read_at')=0,'ALTER TABLE manga ADD COLUMN last_read_at TIMESTAMP NULL AFTER updated_at','SELECT 1');PREPARE s FROM @sql;EXECUTE s;DEALLOCATE PREPARE s;
SET @sql=IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='manga' AND COLUMN_NAME='favorite')=0,'ALTER TABLE manga ADD COLUMN favorite TINYINT(1) NOT NULL DEFAULT 0 AFTER rating','SELECT 1');PREPARE s FROM @sql;EXECUTE s;DEALLOCATE PREPARE s;

INSERT IGNORE INTO categories(name,adult) VALUES('มังฮวา',0),('มังฮวา 18+',1),('มังงะ',0),('มังงะ 18+',1),('มันฮัว',0),('มันฮัว 18+',1),('นิยาย',0),('นิยาย 18+',1),('เว็บตูน',0),('เว็บตูน 18+',1),('โดจิน',0),('โดจิน 18+',1),('อื่นๆ',0);
INSERT IGNORE INTO genres(name) VALUES('Action'),('Adventure'),('Comedy'),('Drama'),('Fantasy'),('Romance'),('Harem'),('Historical'),('Horror'),('Isekai'),('Martial Arts'),('Mystery'),('Psychology'),('School Life'),('Sci-Fi'),('Shounen'),('Sports'),('Supernatural'),('System'),('Reincarnation'),('Office'),('NTR'),('Mature'),('Smut'),('Slice of Life'),('Adult'),('Ecchi'),('Josei'),('Seinen');
INSERT IGNORE INTO collections(name) VALUES('⭐ รายการโปรด'),('🔥 กำลังตาม'),('🎯 อยากอ่าน'),('📦 Archive');
UPDATE manga SET type_id=category_id WHERE (type_id IS NULL OR type_id=0) AND category_id IS NOT NULL;
