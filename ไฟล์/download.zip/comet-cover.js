/* MyManga Tracker — Comet Cover 3D + Sparkles + Holo + Phone Tilt (v17.15.0 — stability pass)
   Vanilla-JS port of two 21st.dev components, so no React/Tailwind/npm build is needed:
   - CometCard    → spring-smoothed 3D tilt, parallax translate, hover lift, moving glare
   - SparklesCore → tiny twinkling particles (+ a few 4-point glints) drawn inside the cover
   Extras in this version:
   - Phone tilt: on touch devices the cards follow the phone's gyroscope (DeviceOrientation).
     iPhone/iPad ask permission once, on the first tap anywhere.
   - Holo foil on completion (reward) cards: a restrained iridescent sheen that moves with the tilt.
   - v17.15: only the few cards nearest the screen centre animate at once (1 for reward cards), nothing
     animates while scrolling, sparkles are capped and freed off-screen, the bottom bar hides on scroll down / returns on scroll up (home & library only).
   Applied to: library covers (.card-cover-wrap), detail cover (.big-cover), reward cards (.reward-card,
   .reward-unlock-card), the 3D collector viewer ([data-tcg-tilt]) and collector artwork (.tcg-art-layer).
   Respects prefers-reduced-motion, pauses off-screen, never blocks clicks (pointer-events:none). */
(function(){
  'use strict';
  var mq = function(q){ return window.matchMedia && window.matchMedia(q).matches; };
  var reduce = mq('(prefers-reduced-motion: reduce)');
  var touchLike = mq('(hover: none), (pointer: coarse)');
  var smallScreen = mq('(max-width: 780px)');
  var clamp = function(v, a, b){ return Math.max(a, Math.min(b, v)); };

  /* ================= Scroll flag: nothing animates while the page is scrolling ================= */
  var scrolling = false, scrollTimer = 0;
  window.addEventListener('scroll', function(){
    scrolling = true; clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function(){
      scrolling = false; refreshFocus(); scheduleSparkRefresh();
      // resume at the current phone pose right away (don't wait for the next sensor tick)
      if (gyroSeen && lastNx !== 9) for (var i = 0; i < gyroSubs.length; i++) gyroSubs[i](lastNx, lastNy);
    }, 150);
  }, { passive: true });

  /* ================= Phone gyroscope (shared) ================= */
  var gyroSubs = [];
  var gyroBase = { g: null, b: null };
  var gyroSeen = false, gyroBound = false, lastEmit = 0, lastNx = 9, lastNy = 9, pendNx = 0, pendNy = 0, pendT = 0;

  function onOrient(e){
    if (e.gamma == null || e.beta == null) return;
    if (gyroBase.g === null){ gyroBase.g = e.gamma; gyroBase.b = e.beta; }
    // baseline follows the way you hold the phone, slowly (~4 s), so tilt is always relative
    gyroBase.g += (e.gamma - gyroBase.g) * 0.004;
    gyroBase.b += (e.beta - gyroBase.b) * 0.004;
    var dg = e.gamma - gyroBase.g, db = e.beta - gyroBase.b;
    var ang = (window.screen && screen.orientation && screen.orientation.angle) || window.orientation || 0;
    var x = dg, y = db;
    if (ang === 90){ x = db; y = -dg; }
    else if (ang === 270 || ang === -90){ x = -db; y = dg; }
    else if (ang === 180 || ang === -180){ x = -dg; y = -db; }
    var nx = clamp(x / 26, -1, 1) * 0.5;   // -0.5 … 0.5, same range the mouse version uses
    var ny = clamp(y / 26, -1, 1) * 0.5;
    var now = performance.now();
    if (now - lastEmit < 33){                                         // ~30 updates/s is plenty
      pendNx = nx; pendNy = ny;                                       // but never lose the final pose
      if (!pendT) pendT = setTimeout(function(){ pendT = 0; emitOrient(pendNx, pendNy); }, 34);
      return;
    }
    emitOrient(nx, ny);
  }
  function emitOrient(nx, ny){
    if (Math.abs(nx - lastNx) < 0.004 && Math.abs(ny - lastNy) < 0.004) return;   // ignore sensor jitter
    lastEmit = performance.now(); lastNx = nx; lastNy = ny;
    if (!gyroSeen){ gyroSeen = true; document.documentElement.classList.add('mmt-gyro'); }
    for (var i = 0; i < gyroSubs.length; i++) gyroSubs[i](nx, ny);
  }
  function bindGyro(){
    if (gyroBound) return; gyroBound = true;
    window.addEventListener('deviceorientation', onOrient, true);
  }
  function initGyro(){
    if (!touchLike || reduce || !('DeviceOrientationEvent' in window)) return;
    var D = window.DeviceOrientationEvent;
    if (typeof D.requestPermission === 'function'){            // iOS 13+: needs a user gesture
      var asked = false;
      var ask = function(){
        if (asked) return; asked = true;
        D.requestPermission().then(function(r){ if (r === 'granted') bindGyro(); }).catch(function(){});
      };
      document.addEventListener('click', ask, { once: true });
      document.addEventListener('touchend', ask, { once: true, passive: true });
    } else {
      bindGyro();
    }
  }

  /* ================= CometCard: spring tilt ================= */
  var K = 150, C = 17;  // spring stiffness / damping
  function Spring(){ this.v = 0; this.p = 0; this.t = 0; }
  Spring.prototype.step = function(dt){ var a = -K * (this.p - this.t) - C * this.v; this.v += a * dt; this.p += this.v * dt; };
  Spring.prototype.settled = function(){ return Math.abs(this.p - this.t) < 0.0008 && Math.abs(this.v) < 0.002; };

  // selector → tuning (rot = max degrees, tra = px parallax, sc = hover scale)
  var TILT_TARGETS = [
    ['.card-cover-wrap',     { key: 'cov', max: touchLike ? 4 : 10, rot: 11, tra: 2.5, sc: 1.03,  persp: 900  }],
    ['.big-cover',           { key: 'big', max: 1, rot: 14, tra: 7,   sc: 1.04,  persp: 900  }],
    ['.reward-card',         { key: 'rwd', max: 1, rot: 9,  tra: 0,   sc: 1.025, persp: 1000, holo: true }],
    ['.reward-unlock-card',  { key: 'unl', max: 1, rot: 13, tra: 0,   sc: 1.03,  persp: 900,  holo: true }]
  ];
  var TILT_SELECTOR = TILT_TARGETS.map(function(t){ return t[0]; }).join(',');
  function cfgFor(el){
    for (var i = 0; i < TILT_TARGETS.length; i++) if (el.matches(TILT_TARGETS[i][0])) return TILT_TARGETS[i][1];
    return null;
  }

  var driven = new Set();   // tilt targets currently on screen (gyro only drives these)
  var focus = new Set();    // the few on-screen targets (nearest the screen centre) that are allowed to animate
  var focusTimer = 0;
  var ioTilt = ('IntersectionObserver' in window) ? new IntersectionObserver(function(entries){
    entries.forEach(function(en){ if (en.isIntersecting) driven.add(en.target); else { driven.delete(en.target); focus.delete(en.target); if (en.target.__idle) en.target.__idle(); } });
    clearTimeout(focusTimer); focusTimer = setTimeout(refreshFocus, 60);
  }, { rootMargin: '40px 0px', threshold: 0.01 }) : null;

  function refreshFocus(){
    var mid = window.innerHeight / 2, groups = {};
    driven.forEach(function(el){
      if (!el.isConnected){ driven.delete(el); return; }
      var r = el.getBoundingClientRect(); if (!r.height) return;
      var k = (el.__cfg && el.__cfg.key) || 'x';
      (groups[k] = groups[k] || []).push([Math.abs(r.top + r.height / 2 - mid), el]);
    });
    var next = new Set();
    Object.keys(groups).forEach(function(k){
      var arr = groups[k].sort(function(a, b){ return a[0] - b[0]; });
      var max = (arr[0][1].__cfg && arr[0][1].__cfg.max) || 4;
      arr.slice(0, max).forEach(function(x){ next.add(x[1]); });
    });
    focus.forEach(function(el){ if (!next.has(el) && el.__idle) el.__idle(); });
    focus = next;
  }

  gyroSubs.push(function(nx, ny){
    if (scrolling) return;
    focus.forEach(function(el){ if (el.__drive) el.__drive(nx, ny); });
  });

  function attachTilt(wrap){
    if (wrap.__comet) return; wrap.__comet = true;
    var cfg = cfgFor(wrap) || { rot: 11, tra: 2.5, sc: 1.03, persp: 900 };
    wrap.__cfg = cfg;
    wrap.classList.add('comet-tilt');
    var glare = document.createElement('span');
    glare.className = 'comet-glare'; glare.setAttribute('aria-hidden', 'true');
    wrap.appendChild(glare);
    if (cfg.holo){
      var foil = document.createElement('span');
      foil.className = 'holo-foil'; foil.setAttribute('aria-hidden', 'true');
      wrap.appendChild(foil);
    }
    var sx = new Spring(), sy = new Spring(), ss = new Spring();
    ss.p = ss.t = 1;
    var raf = 0, last = 0, hover = false, lastDrive = 0, holdTimer = 0;

    function apply(){
      var rx = (-sy.p * 2 * cfg.rot).toFixed(2);
      var ry = (sx.p * 2 * cfg.rot).toFixed(2);
      var tx = (sx.p * 2 * cfg.tra).toFixed(2);
      var ty = (sy.p * 2 * cfg.tra).toFixed(2);
      wrap.style.transform = 'perspective(' + cfg.persp + 'px) translate3d(' + tx + 'px,' + ty + 'px,0) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg) scale(' + ss.p.toFixed(4) + ')';
      wrap.style.setProperty('--cx', ((sx.p + .5) * 100).toFixed(1) + '%');
      wrap.style.setProperty('--cy', ((sy.p + .5) * 100).toFixed(1) + '%');
    }
    function clearAll(){
      wrap.style.transform = '';
      wrap.style.removeProperty('--gl-op'); wrap.style.removeProperty('--holo-op');
      wrap.classList.remove('comet-active', 'comet-gyro');
    }
    function loop(ts){
      var dt = Math.min(.032, (ts - last) / 1000 || .016); last = ts;
      sx.step(dt); sy.step(dt); ss.step(dt); apply();
      var settled = sx.settled() && sy.settled() && ss.settled();
      var gyroLive = performance.now() - lastDrive < 600;
      if (!hover && settled){
        raf = 0;
        if (gyroLive){ clearTimeout(holdTimer); holdTimer = setTimeout(kick, 700); }   // hold pose; re-check shortly
        else clearAll();
        return;
      }
      raf = requestAnimationFrame(loop);
    }
    function kick(){ if (!raf){ last = performance.now(); raf = requestAnimationFrame(loop); } }

    wrap.__drive = function(nx, ny){
      lastDrive = performance.now();
      sx.t = nx; sy.t = ny; ss.t = 1 + (cfg.sc - 1) * .6;
      wrap.classList.add('comet-gyro');
      var m = Math.min(1, Math.hypot(nx, ny) * 2);
      wrap.style.setProperty('--gl-op', (m * .5).toFixed(2));
      wrap.style.setProperty('--holo-op', (.12 + m * .4).toFixed(2));
      kick();
    };

    wrap.__idle = function(){
      lastDrive = 0; sx.t = 0; sy.t = 0; ss.t = 1;
      if (wrap.style.transform || wrap.classList.contains('comet-gyro')) kick();
    };

    wrap.addEventListener('pointermove', function(e){
      if (e.pointerType !== 'mouse') return;
      var r = wrap.getBoundingClientRect(); if (!r.width || !r.height) return;
      sx.t = clamp((e.clientX - r.left) / r.width - .5, -.5, .5);
      sy.t = clamp((e.clientY - r.top) / r.height - .5, -.5, .5);
      kick();
    }, { passive: true });
    wrap.addEventListener('pointerenter', function(e){
      if (e.pointerType !== 'mouse') return;
      hover = true; ss.t = cfg.sc; wrap.classList.add('comet-active'); kick();
    }, { passive: true });
    wrap.addEventListener('pointerleave', function(e){
      if (e.pointerType !== 'mouse') return;
      hover = false; sx.t = 0; sy.t = 0; ss.t = 1; kick();
    }, { passive: true });

    if (ioTilt) ioTilt.observe(wrap);
  }

  /* ================= 3D collector viewer: gyro drives its CSS variables ================= */
  var tcgTargets = new Set();
  var tcgCur = { x: 0, y: 0 }, tcgTar = { x: 0, y: 0 }, tcgRaf = 0;
  function tcgLoop(){
    tcgCur.x += (tcgTar.x - tcgCur.x) * .16;
    tcgCur.y += (tcgTar.y - tcgCur.y) * .16;
    tcgTargets.forEach(function(el){
      if (!el.isConnected){ tcgTargets.delete(el); return; }
      el.style.setProperty('--tcg-tilt-x', (-tcgCur.y * 2 * 13).toFixed(2) + 'deg');
      el.style.setProperty('--tcg-tilt-y', (tcgCur.x * 2 * 15).toFixed(2) + 'deg');
      el.style.setProperty('--tcg-pointer-x', clamp(50 + tcgCur.x * 100, 0, 100).toFixed(1) + '%');
      el.style.setProperty('--tcg-pointer-y', clamp(44 + tcgCur.y * 100, 0, 100).toFixed(1) + '%');
    });
    var moving = Math.abs(tcgTar.x - tcgCur.x) > .002 || Math.abs(tcgTar.y - tcgCur.y) > .002;
    tcgRaf = moving && tcgTargets.size ? requestAnimationFrame(tcgLoop) : 0;
  }
  gyroSubs.push(function(nx, ny){
    if (!tcgTargets.size) return;
    tcgTar.x = nx; tcgTar.y = ny;
    if (!tcgRaf) tcgRaf = requestAnimationFrame(tcgLoop);
  });

  /* ================= SparklesCore: twinkling particles ================= */
  var COLORS = ['#ffffff', '#ffffff', '#ece6ff', '#c4b5fd', '#a5b4fc'];
  var visible = new Set();
  var sparkRaf = 0, lastFrame = 0;
  var FRAME_MS = 1000 / 30;

  function makeParticle(w, h, glint){
    return {
      x: Math.random() * w, y: Math.random() * h,
      r: glint ? 1.6 + Math.random() * 1.6 : .4 + Math.random() * 1.0,
      vx: (Math.random() - .5) * .05, vy: -(.03 + Math.random() * .1),
      ph: Math.random() * Math.PI * 2, sp: (glint ? .5 : .9) + Math.random() * 1.6,
      c: COLORS[(Math.random() * COLORS.length) | 0], glint: glint
    };
  }
  function buildSparkles(host){
    if (host.__sparkles) return;
    var canvas = document.createElement('canvas');
    canvas.className = 'comet-sparkles'; canvas.setAttribute('aria-hidden', 'true');
    host.appendChild(canvas);
    host.__sparkles = { canvas: canvas, ctx: canvas.getContext('2d'), parts: [], w: 0, h: 0 };
  }
  function sizeSparkles(host){
    var s = host.__sparkles; if (!s) return;
    var r = host.getBoundingClientRect(); if (!r.width || !r.height) return;
    var dpr = touchLike ? 1 : Math.min(2, window.devicePixelRatio || 1);
    if (Math.abs(r.width - s.w) < 1 && Math.abs(r.height - s.h) < 1 && s.parts.length) return;
    s.w = r.width; s.h = r.height;
    s.canvas.width = Math.round(r.width * dpr); s.canvas.height = Math.round(r.height * dpr);
    s.dpr = dpr;
    var area = r.width * r.height;
    var isBig = host.classList.contains('big-cover') || host.classList.contains('reward-card-cover') || host.classList.contains('reward-unlock-art');
    var n = Math.max(10, Math.min(smallScreen ? 22 : (isBig ? 56 : 38), Math.round(area / 1500)));
    var glints = Math.max(2, Math.round(n / 9));
    s.parts = [];
    for (var i = 0; i < n; i++) s.parts.push(makeParticle(r.width, r.height, i < glints));
  }
  function drawSparkles(host, t, dt){
    var s = host.__sparkles; if (!s || !s.parts.length) return;
    var ctx = s.ctx; ctx.setTransform(s.dpr, 0, 0, s.dpr, 0, 0);
    ctx.clearRect(0, 0, s.w, s.h);
    for (var i = 0; i < s.parts.length; i++){
      var p = s.parts[i];
      p.x += p.vx * dt * 60; p.y += p.vy * dt * 60;
      if (p.y < -4){ p.y = s.h + 4; p.x = Math.random() * s.w; }
      if (p.x < -4) p.x = s.w + 4; else if (p.x > s.w + 4) p.x = -4;
      var tw = (Math.sin(t * p.sp + p.ph) + 1) / 2;
      var a = p.glint ? Math.pow(tw, 3) * .95 : .08 + tw * .8;
      if (a < .02) continue;
      ctx.globalAlpha = a; ctx.fillStyle = p.c; ctx.strokeStyle = p.c;
      if (p.glint){
        var L = p.r * (2.2 + tw * 2.2);
        ctx.lineWidth = .7;
        ctx.beginPath();
        ctx.moveTo(p.x - L, p.y); ctx.lineTo(p.x + L, p.y);
        ctx.moveTo(p.x, p.y - L); ctx.lineTo(p.x, p.y + L);
        ctx.stroke();
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * .5, 0, 6.2832); ctx.fill();
      } else {
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }
  function sparkLoop(ts){
    if (!visible.size || document.hidden){ sparkRaf = 0; return; }
    if (!scrolling && ts - lastFrame >= FRAME_MS){
      var dt = Math.min(.1, (ts - lastFrame) / 1000); lastFrame = ts;
      visible.forEach(function(host){ drawSparkles(host, ts / 1000, dt); });
    }
    sparkRaf = requestAnimationFrame(sparkLoop);
  }
  function startSparkles(){ if (!sparkRaf && visible.size){ lastFrame = 0; sparkRaf = requestAnimationFrame(sparkLoop); } }
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) startSparkles(); });

  // Phones: no sparkle canvases on the collector/reward thumbnails (that grid is already heavy); only the 3D viewer card.
  var SPARKLE_HOSTS = '.library-grid .card-cover, .shelf-mobile .card-cover, .big-cover' +
    (touchLike ? ', .tcg-stage .tcg-art-layer' : ', .tcg-art-layer, .reward-card-cover, .reward-unlock-art');
  var MAX_SPARK = touchLike ? 6 : 14;       // canvases alive at once (nearest the screen centre win)
  var inView = new Set(), sparkTimer = 0;
  function dropSparkles(h){
    if (h.__sparkles){ try { h.__sparkles.canvas.remove(); } catch (e) {} h.__sparkles = null; }
    visible.delete(h);
  }
  function refreshSparkles(){
    var mid = window.innerHeight / 2, arr = [];
    inView.forEach(function(h){
      if (!h.isConnected){ inView.delete(h); dropSparkles(h); return; }
      var r = h.getBoundingClientRect(); if (!r.height) return;
      arr.push([Math.abs(r.top + r.height / 2 - mid), h]);
    });
    arr.sort(function(a, b){ return a[0] - b[0]; });
    var keep = new Set(arr.slice(0, MAX_SPARK).map(function(x){ return x[1]; }));
    arr.forEach(function(x){
      var h = x[1];
      if (keep.has(h)){ buildSparkles(h); sizeSparkles(h); visible.add(h); } else dropSparkles(h);
    });
    startSparkles();
  }
  function scheduleSparkRefresh(){ clearTimeout(sparkTimer); sparkTimer = setTimeout(refreshSparkles, 80); }
  var io = ('IntersectionObserver' in window) ? new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if (en.isIntersecting) inView.add(en.target);
      else { inView.delete(en.target); dropSparkles(en.target); }
    });
    scheduleSparkRefresh();
  }, { rootMargin: '60px 0px', threshold: 0.01 }) : null;

  /* ================= Bottom dock: hides while scrolling down, returns when scrolling up; absent on the detail page ================= */
  function initBottomBar(){
    if (document.body.classList.contains('page-detail')){ document.querySelectorAll('.bottom-nav').forEach(function(n){ n.remove(); }); return; }
    var nav = document.querySelector('.bottom-nav');
    if (!nav || nav.__autoHide) return; nav.__autoHide = true;
    var lastY = window.pageYOffset || 0, acc = 0, hidden = false, ticking = false;
    function set(h){ if (h === hidden) return; hidden = h; nav.classList.toggle('is-hidden', h); }
    function onScroll(){
      var y = Math.max(0, window.pageYOffset || 0), dy = y - lastY; lastY = y;
      var doc = document.documentElement;
      var atTop = y < 90, atBottom = window.innerHeight + y >= doc.scrollHeight - 28;
      if (atTop || atBottom){ set(false); acc = 0; return; }
      acc = ((dy > 0) === (acc > 0)) ? acc + dy : dy;
      if (acc > 16) set(true); else if (acc < -9) set(false);
    }
    window.addEventListener('scroll', function(){
      if (ticking) return; ticking = true;
      requestAnimationFrame(function(){ ticking = false; onScroll(); });
    }, { passive: true });
    // never leave it hidden while typing or when the page changes
    document.addEventListener('focusin', function(e){ if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) set(false); });
    window.addEventListener('hashchange', function(){ set(false); });
  }

  /* ================= wiring ================= */
  function scan(root){
    if (!root || root.nodeType !== 1) return;
    var tilts = [], sparks = [], tcgs = [];
    if (root.matches){
      if (root.matches(TILT_SELECTOR)) tilts.push(root);
      if (root.matches(SPARKLE_HOSTS)) sparks.push(root);
      if (root.matches('[data-tcg-tilt]')) tcgs.push(root);
    }
    if (root.querySelectorAll){
      root.querySelectorAll(TILT_SELECTOR).forEach(function(n){ tilts.push(n); });
      root.querySelectorAll(SPARKLE_HOSTS).forEach(function(n){ sparks.push(n); });
      root.querySelectorAll('[data-tcg-tilt]').forEach(function(n){ tcgs.push(n); });
    }
    if (!reduce){
      tilts.forEach(function(el){ if (!el.closest('.list-mode')) attachTilt(el); });
      sparks.forEach(function(el){ if (io && !el.__cometObserved){ el.__cometObserved = true; io.observe(el); } });
      if (touchLike) tcgs.forEach(function(el){ tcgTargets.add(el); });
    }
  }

  function init(){
    scan(document.body);
    initGyro();
    initBottomBar();
    new MutationObserver(function(recs){
      recs.forEach(function(r){ r.addedNodes.forEach(scan); });
    }).observe(document.body, { childList: true, subtree: true });
    window.addEventListener('resize', function(){ visible.forEach(sizeSparkles); }, { passive: true });
  }
  if (document.body) init(); else document.addEventListener('DOMContentLoaded', init);
})();
