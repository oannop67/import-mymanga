/* MyManga Tracker PRO v17.1 — 21st.dev-inspired Action Search Bar
 * Native runtime version for the existing HTML/JS/PHP website. React TSX version is in components/ui.
 */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const actions = [
    { id:'home', label:'หน้าแรก', description:'กลับไปหน้า Dashboard', icon:'⌂', category:'นำทาง', keywords:'home dashboard หน้าแรก หลัก' },
    { id:'library', label:'คลังทั้งหมด', description:'ค้นหา กรอง และจัดการการ์ตูน', icon:'▦', category:'นำทาง', keywords:'library manga คลัง การ์ตูน รายการทั้งหมด' },
    { id:'continue', label:'กำลังอ่าน', description:'กลับไปเรื่องที่อ่านค้างไว้', icon:'▶', category:'นำทาง', keywords:'continue reading อ่านต่อ ค้างไว้' },
    { id:'new-chapters', label:'ศูนย์ตอนใหม่', description:'ดู Chapter ใหม่ที่รออ่าน', icon:'🆕', category:'อ่านการ์ตูน', keywords:'new chapters episode latest ตอนใหม่ chapter' },
    { id:'sync-center', label:'AUTO SYNC CENTER', description:'ดูคิวและซิงก์เรื่องที่ยังไม่จบ', icon:'🔄', category:'จัดการคลัง', keywords:'sync auto refresh ซิงก์ อัปเดต ดึงตอน' },
    { id:'sync-all', label:'เริ่มซิงก์ทั้งหมด', description:'เริ่มประมวลผลคิวซิงก์ตามเงื่อนไขปัจจุบัน', icon:'⟳', category:'จัดการคลัง', keywords:'start sync all ทั้งหมด' },
    { id:'categories', label:'หมวดหมู่', description:'จัดการประเภท แนวเรื่อง และ Collection', icon:'▤', category:'นำทาง', keywords:'categories genre collection tag หมวด แนว' },
    { id:'completed', label:'อ่านจบแล้ว', description:'ดูรายการที่อ่านจบแล้ว', icon:'✅', category:'นำทาง', keywords:'completed finish done จบแล้ว' },
    { id:'rewards', label:'การ์ดสะสม', description:'ดูรางวัลจากการอ่านจบ', icon:'🏆', category:'นำทาง', keywords:'rewards card trophy รางวัล สะสม' },
    { id:'add', label:'เพิ่มการ์ตูน', description:'เพิ่มเรื่องใหม่เข้าคลัง', icon:'＋', category:'จัดการคลัง', keywords:'add create new manga เพิ่มเรื่อง' },
    { id:'search', label:'ค้นหาการ์ตูน', description:'ค้นหาชื่อเรื่อง แนว หมายเหตุ หรือเว็บต้นทาง', icon:'⌕', category:'ค้นหา', keywords:'search find ค้นหา' },
    { id:'source-manager', label:'จัดการเว็บต้นทาง', description:'ค้นหาเรื่องตามโดเมนและเปลี่ยน URL', icon:'🌐', category:'จัดการคลัง', keywords:'source manager domain host เว็บต้นทาง url' },
    { id:'sync-issues', label:'ตรวจเว็บที่มีปัญหา', description:'ดูรายการซิงก์ผิดพลาดหรือดึงไม่ครบ', icon:'⚠', category:'จัดการคลัง', keywords:'issues error blocked partial verify ปัญหา' },
    { id:'timeline', label:'Timeline การอ่าน', description:'ดูประวัติการอ่านตามเวลา', icon:'◷', category:'อ่านการ์ตูน', keywords:'timeline history recent ประวัติ' },
    { id:'settings', label:'ตั้งค่าและสถานะระบบ', description:'API Token การสำรองข้อมูล และประวัติซิงก์', icon:'⚙', category:'ระบบ', keywords:'settings config backup api ตั้งค่า' },
    { id:'theme', label:'สลับธีมสว่าง/มืด', description:'เปลี่ยนธีมของเว็บไซต์', icon:'☼', category:'ระบบ', keywords:'theme dark light color สี ธีม' },
  ];
  let results = [];
  let activeIndex = 0;
  let previousFocus = null;
  let palette;
  let input;
  let list;

  function init() {
    if ($('mmtActionSearchPalette')) return;
    const wrapper = document.createElement('div');
    wrapper.id = 'mmtActionSearchPalette';
    wrapper.className = 'command-palette hidden';
    wrapper.setAttribute('aria-hidden', 'true');
    wrapper.innerHTML = `
      <button class="command-palette-backdrop" type="button" data-command-close aria-label="ปิดคำสั่งด่วน"></button>
      <section class="command-dialog" role="dialog" aria-modal="true" aria-labelledby="commandDialogLabel">
        <header class="command-dialog-head">
          <div class="command-dialog-title"><strong id="commandDialogLabel"><span>⌘</span> คำสั่งด่วน MyManga</strong><small>21st.dev-inspired Action Search</small></div>
          <label class="command-input-wrap"><span class="command-input-icon">⌕</span><input id="commandSearchInput" class="command-input" type="text" autocomplete="off" spellcheck="false" placeholder="พิมพ์คำสั่งหรือค้นหาการ์ตูน..." aria-label="ค้นหาคำสั่งหรือการ์ตูน" aria-controls="commandSearchResults" aria-expanded="true" role="combobox" aria-autocomplete="list"/><span class="command-result-end">ESC</span></label>
        </header>
        <div id="commandSearchResults" class="command-results" role="listbox" aria-label="คำสั่งที่ใช้ได้"></div>
        <footer class="command-dialog-foot"><div class="command-foot-hints"><span><kbd>↑</kbd> <kbd>↓</kbd> เลือก</span><span><kbd>↵</kbd> เปิด</span><span><kbd>Esc</kbd> ปิด</span></div><span>MyManga Tracker PRO</span></footer>
      </section>`;
    document.body.appendChild(wrapper);
    palette = wrapper;
    input = $('commandSearchInput');
    list = $('commandSearchResults');
    $('commandSearchBtn')?.addEventListener('click', openPalette);
    $('actionPaletteOpenHero')?.addEventListener('click', openPalette);
    wrapper.querySelector('[data-command-close]')?.addEventListener('click', closePalette);
    input.addEventListener('input', () => { activeIndex = 0; renderResults(); });
    input.addEventListener('keydown', handleInputKeydown);
    list.addEventListener('mousemove', (event) => {
      const row = event.target instanceof Element ? event.target.closest('[data-command-index]') : null;
      if (row) { activeIndex = Number(row.dataset.commandIndex); updateActive(); }
    });
    list.addEventListener('click', (event) => {
      const row = event.target instanceof Element ? event.target.closest('[data-command-index]') : null;
      if (!row) return;
      runResult(Number(row.dataset.commandIndex));
    });
    document.addEventListener('keydown', (event) => {
      const isK = event.key.toLowerCase() === 'k';
      if ((event.ctrlKey || event.metaKey) && isK) { event.preventDefault(); palette.classList.contains('hidden') ? openPalette() : closePalette(); return; }
      if (event.key === 'Escape' && !palette.classList.contains('hidden')) { event.preventDefault(); closePalette(); }
    });
  }

  function openPalette() {
    if (!palette) return;
    previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    palette.classList.remove('hidden');
    palette.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('command-palette-open');
    document.body.classList.add('command-palette-open');
    input.value = '';
    activeIndex = 0;
    renderResults();
    requestAnimationFrame(() => input.focus());
  }

  function closePalette() {
    if (!palette || palette.classList.contains('hidden')) return;
    palette.classList.add('hidden');
    palette.setAttribute('aria-hidden', 'true');
    document.documentElement.classList.remove('command-palette-open');
    document.body.classList.remove('command-palette-open');
    if (previousFocus && previousFocus.isConnected) previousFocus.focus({ preventScroll: true });
  }

  function renderResults() {
    if (!input || !list) return;
    const query = input.value.trim().toLocaleLowerCase('th');
    const dynamicSearch = query ? [{ id:'search-query', label:`ค้นหาในคลัง: “${input.value.trim()}”`, description:'ใช้คำนี้ค้นชื่อเรื่อง แนว หมายเหตุ และเว็บต้นทาง', icon:'⌕', category:'ค้นหา', keywords:query, query:input.value.trim() }] : [];
    const filtered = actions.filter(action => `${action.label} ${action.description} ${action.keywords} ${action.category}`.toLocaleLowerCase('th').includes(query));
    results = [...dynamicSearch, ...filtered];
    if (!results.length) {
      list.innerHTML = '<div class="command-empty">ไม่พบคำสั่งที่ตรงกัน ลองค้นหาชื่อเมนูหรือชื่อการ์ตูน</div>';
      return;
    }
    activeIndex = Math.max(0, Math.min(activeIndex, results.length - 1));
    let lastCategory = '';
    const parts = [];
    results.forEach((action, index) => {
      const cat = action.category || 'คำสั่ง';
      if (cat !== lastCategory) { parts.push(`<div class="command-result-group">${escapeHtml(cat)}</div>`); lastCategory = cat; }
      parts.push(`<button type="button" class="command-result${index===activeIndex?' is-active':''}" role="option" aria-selected="${index===activeIndex?'true':'false'}" id="command-result-${index}" data-command-index="${index}"><span class="command-result-icon" aria-hidden="true">${escapeHtml(action.icon)}</span><span class="command-result-copy"><span class="command-result-label">${escapeHtml(action.label)}</span><span class="command-result-description">${escapeHtml(action.description)}</span></span>${action.id==='search-query'?'<span class="command-result-end">ค้นหา</span>':action.id==='sync-all'?'<span class="command-result-end">เริ่ม</span>':'<span class="command-result-arrow" aria-hidden="true">↗</span>'}</button>`);
    });
    list.innerHTML = parts.join('');
    input.setAttribute('aria-activedescendant', `command-result-${activeIndex}`);
    const current = list.querySelector('.is-active');
    current?.scrollIntoView({ block: 'nearest' });
  }

  function updateActive() {
    list.querySelectorAll('[data-command-index]').forEach(el => {
      const active = Number(el.dataset.commandIndex) === activeIndex;
      el.classList.toggle('is-active', active);
      el.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    input.setAttribute('aria-activedescendant', `command-result-${activeIndex}`);
    list.querySelector('.is-active')?.scrollIntoView({ block:'nearest' });
  }

  function handleInputKeydown(event) {
    if (event.key === 'ArrowDown') { event.preventDefault(); activeIndex = Math.min(results.length - 1, activeIndex + 1); updateActive(); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); activeIndex = Math.max(0, activeIndex - 1); updateActive(); }
    else if (event.key === 'Enter') { event.preventDefault(); runResult(activeIndex); }
  }

  function runResult(index) {
    const action = results[index];
    if (!action) return;
    closePalette();
    if (action.id === 'search-query') { searchLibrary(action.query); return; }
    switch (action.id) {
      case 'home': navigate('#home'); break;
      case 'library': navigate('#library'); break;
      case 'continue': navigate('#continue'); break;
      case 'new-chapters': document.querySelector('a[href="#new-chapters"]')?.click(); break;
      case 'sync-center': navigate('#sync-center'); break;
      case 'sync-all': navigate('#sync-center'); setTimeout(() => $('syncStartBtn')?.click(), 120); break;
      case 'categories': navigate('#categories'); break;
      case 'completed': navigate('#completed'); break;
      case 'rewards': navigate('#rewards'); break;
      case 'add': $('addBtn')?.click(); break;
      case 'search': searchLibrary(''); break;
      case 'source-manager': navigate('#library'); setTimeout(() => $('sourceManagerBtn')?.click(), 120); break;
      case 'sync-issues': navigate('#sync-center'); setTimeout(() => $('syncIssuesBtn')?.click(), 120); break;
      case 'timeline': navigate('#continue'); setTimeout(() => $('timelineBtn')?.click(), 120); break;
      case 'settings': $('settingsBtn')?.click(); break;
      case 'theme': $('themeBtn')?.click(); break;
    }
  }

  function navigate(hash) {
    const anchor = document.querySelector(`.desktop-nav a[href="${hash}"], .bottom-nav a[href="${hash}"]`);
    if (anchor) anchor.click();
    else { location.hash = hash; document.querySelector(hash)?.scrollIntoView({ behavior:'smooth', block:'start' }); }
  }

  function searchLibrary(query) {
    const field = $('search');
    if (!field) return;
    field.value = query;
    field.dispatchEvent(new Event('input', { bubbles:true }));
    navigate('#library');
    setTimeout(() => { field.focus({ preventScroll:true }); if (typeof field.select === 'function') field.select(); }, 160);
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[character]);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once:true }); else init();
})();
