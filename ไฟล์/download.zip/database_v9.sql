CREATE DATABASE IF NOT EXISTS manga_tracker CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE manga_tracker;

CREATE TABLE IF NOT EXISTS manga(
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255) NOT NULL,
 alt_title VARCHAR(255) NULL,
 cover_url VARCHAR(1000) NULL,
 source_url VARCHAR(1000) NOT NULL,
 category_id INT NULL,
 type_id INT NULL,
 current_chapter VARCHAR(50) NOT NULL DEFAULT '0',
 last_chapter VARCHAR(50) NULL,
 status ENUM('reading','completed','planned','paused','dropped') NOT NULL DEFAULT 'reading',
 rating TINYINT NULL,
 favorite TINYINT(1) NOT NULL DEFAULT 0,
 note TEXT NULL,
 last_read_at TIMESTAMP NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_m_source(source_url(255)),INDEX idx_m_updated(updated_at),INDEX idx_m_read(last_read_at),INDEX idx_m_type(type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,adult TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS genres(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS collections(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS manga_genres(manga_id INT NOT NULL,genre_id INT NOT NULL,PRIMARY KEY(manga_id,genre_id),INDEX idx_mg_genre(genre_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS manga_collections(manga_id INT NOT NULL,collection_id INT NOT NULL,PRIMARY KEY(manga_id,collection_id),INDEX idx_mc_collection(collection_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS chapters(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,title VARCHAR(255) NULL,chapter_url VARCHAR(1000) NOT NULL,release_date DATE NULL,sort_order DECIMAL(20,6) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_manga_chapter(manga_id,chapter),INDEX idx_ch_manga(manga_id),INDEX idx_ch_sort(manga_id,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS reading_history(id INT AUTO_INCREMENT PRIMARY KEY,manga_id INT NOT NULL,chapter VARCHAR(50) NOT NULL,source_url VARCHAR(1000) NULL,detection_method VARCHAR(30) NOT NULL DEFAULT 'web',read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_hist_manga(manga_id,read_at),INDEX idx_hist_time(read_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS app_settings(setting_key VARCHAR(80) PRIMARY KEY,setting_value TEXT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO categories(name,adult) VALUES('มังฮวา',0),('มังฮวา 18+',1),('มังงะ',0),('มังงะ 18+',1),('มันฮัว',0),('มันฮัว 18+',1),('นิยาย',0),('นิยาย 18+',1),('เว็บตูน',0),('เว็บตูน 18+',1),('โดจิน',0),('โดจิน 18+',1),('อื่นๆ',0);
INSERT IGNORE INTO genres(name) VALUES('Action'),('Adventure'),('Comedy'),('Drama'),('Fantasy'),('Romance'),('Harem'),('Historical'),('Horror'),('Isekai'),('Martial Arts'),('Mystery'),('Psychology'),('School Life'),('Sci-Fi'),('Shounen'),('Sports'),('Supernatural'),('System'),('Reincarnation'),('Office'),('NTR'),('Mature'),('Smut'),('Slice of Life'),('Adult'),('Ecchi'),('Josei'),('Seinen');
INSERT IGNORE INTO collections(name) VALUES('⭐ รายการโปรด'),('🔥 กำลังตาม'),('🎯 อยากอ่าน'),('📦 Archive');
