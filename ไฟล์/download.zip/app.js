window.__mmHash=/^#mmimport=/.test(location.hash)?location.hash:'';if(window.__mmHash){try{history.replaceState(null,'',location.pathname+location.search)}catch{}}
const API='api/api.php';const LOCAL_DEV_TOKEN='MyMangaV11LocalToken2026!';const isLocalDev=/^(localhost|127\.0\.0\.1|\[::1\])$/i.test(location.hostname);
const $=id=>document.getElementById(id);
function setMmtPerformanceMode(enabled, persist=true){
 const on=!!enabled;
 document.documentElement.classList.toggle('mmt-performance-mode',on);
 if(persist){try{localStorage.setItem('manga_performance_mode',on?'1':'0')}catch{}}
 const tune=root=>{
  if(!on||!root)return;
  const videos=[];
  if(root.matches?.('video.cover-motion-video,video.tcg-art-video'))videos.push(root);
  root.querySelectorAll?.('video.cover-motion-video,video.tcg-art-video').forEach(v=>videos.push(v));
  videos.forEach(v=>{try{v.pause();v.dataset.mmtPausedForPerformance='1'}catch{}});
 };
 tune(document);
 if(on&&!window.__mmtPerformanceObserver&&document.body&&'MutationObserver'in window){
  window.__mmtPerformanceObserver=new MutationObserver(records=>records.forEach(rec=>rec.addedNodes.forEach(n=>{if(n.nodeType===1)tune(n)})));
  window.__mmtPerformanceObserver.observe(document.body,{childList:true,subtree:true});
 }else if(!on&&window.__mmtPerformanceObserver){window.__mmtPerformanceObserver.disconnect();window.__mmtPerformanceObserver=null;document.querySelectorAll('video[data-mmt-paused-for-performance="1"]').forEach(v=>{delete v.dataset.mmtPausedForPerformance;try{v.play().catch(()=>{})}catch{}})}
}
try{setMmtPerformanceMode(localStorage.getItem('manga_performance_mode')==='1',false)}catch{}

const CARD_THEME_SHADE_IDS=["pink-100", "pink-200", "pink-300", "pink-400", "pink-500", "pink-600", "pink-700", "pink-800", "pink-900", "rose-100", "rose-200", "rose-300", "rose-400", "rose-500", "rose-600", "rose-700", "rose-800", "rose-900", "red-100", "red-200", "red-300", "red-400", "red-500", "red-600", "red-700", "red-800", "red-900", "coral-100", "coral-200", "coral-300", "coral-400", "coral-500", "coral-600", "coral-700", "coral-800", "coral-900", "orange-100", "orange-200", "orange-300", "orange-400", "orange-500", "orange-600", "orange-700", "orange-800", "orange-900", "amber-100", "amber-200", "amber-300", "amber-400", "amber-500", "amber-600", "amber-700", "amber-800", "amber-900", "yellow-100", "yellow-200", "yellow-300", "yellow-400", "yellow-500", "yellow-600", "yellow-700", "yellow-800", "yellow-900", "lime-100", "lime-200", "lime-300", "lime-400", "lime-500", "lime-600", "lime-700", "lime-800", "lime-900", "green-100", "green-200", "green-300", "green-400", "green-500", "green-600", "green-700", "green-800", "green-900", "emerald-100", "emerald-200", "emerald-300", "emerald-400", "emerald-500", "emerald-600", "emerald-700", "emerald-800", "emerald-900", "mint-100", "mint-200", "mint-300", "mint-400", "mint-500", "mint-600", "mint-700", "mint-800", "mint-900", "teal-100", "teal-200", "teal-300", "teal-400", "teal-500", "teal-600", "teal-700", "teal-800", "teal-900", "cyan-100", "cyan-200", "cyan-300", "cyan-400", "cyan-500", "cyan-600", "cyan-700", "cyan-800", "cyan-900", "sky-100", "sky-200", "sky-300", "sky-400", "sky-500", "sky-600", "sky-700", "sky-800", "sky-900", "blue-100", "blue-200", "blue-300", "blue-400", "blue-500", "blue-600", "blue-700", "blue-800", "blue-900", "cobalt-100", "cobalt-200", "cobalt-300", "cobalt-400", "cobalt-500", "cobalt-600", "cobalt-700", "cobalt-800", "cobalt-900", "indigo-100", "indigo-200", "indigo-300", "indigo-400", "indigo-500", "indigo-600", "indigo-700", "indigo-800", "indigo-900", "violet-100", "violet-200", "violet-300", "violet-400", "violet-500", "violet-600", "violet-700", "violet-800", "violet-900", "purple-100", "purple-200", "purple-300", "purple-400", "purple-500", "purple-600", "purple-700", "purple-800", "purple-900", "magenta-100", "magenta-200", "magenta-300", "magenta-400", "magenta-500", "magenta-600", "magenta-700", "magenta-800", "magenta-900", "brown-100", "brown-200", "brown-300", "brown-400", "brown-500", "brown-600", "brown-700", "brown-800", "brown-900", "slate-100", "slate-200", "slate-300", "slate-400", "slate-500", "slate-600", "slate-700", "slate-800", "slate-900"];
const CARD_THEMES=["auto", "rose", "sakura", "coral", "peach", "crimson", "ruby", "wine", "amber", "tangerine", "gold", "lemon", "bronze", "sand", "emerald", "mint", "lime", "forest", "matcha", "teal", "ocean", "sky", "cyan", "cobalt", "indigo", "midnight", "ink", "violet", "amethyst", "lavender", "orchid", "magenta", "mono", "silver", "rosegold", "obsidian", "aurora", "nebula", "lagoon", "sunset", "ember", "candy", "bubblegum", "blush", "flamingo", "cherry", "scarlet", "burgundy", "salmon", "apricot", "honey", "mustard", "copper", "caramel", "cream", "pumpkin", "pine", "olive", "sage", "pistachio", "seafoam", "jungle", "azure", "arctic", "denim", "navy", "electric", "periwinkle", "steel", "grape", "plum", "mauve", "lilac", "royalpurple", "berry", "thistle", "pearl", "platinum", "titanium", "graphite", "champagne", "chrome", "neonpink", "neonblue", "neongreen", "neonorange", "neonviolet", "neonyellow", "twilight", "deepsea", "mango", "berrypop", "frost", "blossom", "royalgold", "toxic", "galaxy", "sunrise", "peacock", "mist", "dusk", "mojito"].concat(CARD_THEME_SHADE_IDS);
function cardThemeMap(){try{return JSON.parse(localStorage.getItem('manga_card_themes')||'{}')}catch{return {}}}
function cardThemeFor(x){const map=cardThemeMap();const saved=map[String(x.id)];if(saved&&CARD_THEMES.includes(saved))return saved;const title=String(x.title||x.id||'');let h=0;for(let i=0;i<title.length;i++)h=(h*31+title.charCodeAt(i))|0;const pool=CARD_THEMES.slice(1);return pool[Math.abs(h)%pool.length]}
function saveCardTheme(id,theme){const map=cardThemeMap();if(theme==='auto')delete map[String(id)];else map[String(id)]=theme;localStorage.setItem('manga_card_themes',JSON.stringify(map))}
const state={items:[],types:[],genres:[],collections:[],recent:[],timeline:[],collectionMap:{},completionCards:[],libraryListMode:localStorage.getItem('manga_view_mode')==='list',selectedIds:new Set()};
let activeRewardFolder='all';
let activeRewardTier='all';
const syncState={running:false,paused:false,stop:false,index:0,queue:[],results:[],reviews:[],hosts:{},durations:[],startedAt:0,blockedStreak:0};
function syncCfg(){return {cooldownHours:Math.max(0,Number(localStorage.getItem('manga_sync_cooldown_hours')||6)),delayMs:Math.max(0,Number(localStorage.getItem('manga_sync_delay_ms')||1500)),blockLimit:Math.max(1,Number(localStorage.getItem('manga_sync_block_limit')||3))}}
function setSyncCfg(k,v){localStorage.setItem(k,v)}
function syncDue(x,hrs){const t=x.last_sync_at?new Date(String(x.last_sync_at).replace(' ','T')).getTime():NaN;if(x.sync_status==='running')return !Number.isFinite(t)||Date.now()-t>=10*60*1000;if(['error','partial','review'].includes(x.sync_status)||(x.sync_status==='unverifiable'&&!smUnvOk()))return true;if(!x.last_sync_at)return true;return !Number.isFinite(t)||Date.now()-t>=hrs*3600000}
function newCount(x){return Math.max(0,Number(x.new_chapter_count||0))}
function syncErrorLabel(x){if(x.sync_status==='running')return 'กำลังดึง Chapter ในเบื้องหลัง';if(x.sync_status==='blocked')return '403/429 • ต้องใช้ Browser Import';if(x.sync_status==='error')return x.sync_error||'ซิงก์ไม่สำเร็จ';if(['partial','unverifiable','review'].includes(x.sync_status))return x.sync_error||'ซิงก์แล้วแต่ต้องตรวจสอบ';return ''}

class ApiError extends Error{constructor(message,status=0,data=null){super(message);this.status=status;this.data=data;}}
let tokenPromptPromise=null;
function getStoredToken(){return (localStorage.getItem('manga_token')||'').trim()}
// ถามครั้งเดียวต่อรอบ แม้มีหลายคำขอได้ 401 พร้อมกัน
function promptToken(){
  if(tokenPromptPromise)return tokenPromptPromise;
  tokenPromptPromise=new Promise(resolve=>{
    setTimeout(()=>{
      const next=prompt('ใส่ API Token (ค่าเดียวกับ $MANGA_API_TOKEN ใน api/config.php):');
      if(next===null){resolve(null);return}
      const value=next.trim();
      if(value)localStorage.setItem('manga_token',value);
      resolve(value||null);
    },0);
  }).finally(()=>{tokenPromptPromise=null});
  return tokenPromptPromise;
}

// InfinityFree: ถ้าได้หน้าตรวจบอท (aes.js) แทน JSON ให้ให้เบราว์เซอร์ผ่านด่านผ่าน iframe แล้วลองใหม่
let challengePromise=null;
function isHostChallenge(t){return /slowAES|toNumbers\s*\(|__test/.test(t)}
function solveHostChallenge(){
  if(challengePromise)return challengePromise;
  challengePromise=new Promise(resolve=>{
    const f=document.createElement('iframe');
    f.style.cssText='display:none;width:0;height:0;border:0';
    let loads=0,finished=false;
    const done=()=>{if(finished)return;finished=true;try{f.remove()}catch{}resolve()};
    f.onload=()=>{loads++;if(loads>=2)done()};
    setTimeout(done,8000);
    f.src=API+(String(API).includes('?')?'&':'?')+'warm='+Date.now();
    document.body.appendChild(f);
  }).finally(()=>{challengePromise=null});
  return challengePromise;
}
async function api(action,payload={},retry=true,solved=false){
  const token=getStoredToken()||(isLocalDev?LOCAL_DEV_TOKEN:'');
  let res,data;
  try{
    res=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json','X-Manga-Token':token,'Authorization':token?`Bearer ${token}`:''},body:JSON.stringify({action,...payload,token}),cache:'no-store'});
  }catch(e){throw new ApiError('เชื่อมต่อ API ไม่ได้ กรุณาตรวจสอบอินเทอร์เน็ตและ URL ของ API',0)}
  const raw=await res.text();try{data=JSON.parse(raw)}catch{if(!solved&&isHostChallenge(raw)){await solveHostChallenge();return api(action,payload,retry,true)}throw new ApiError(`API ตอบกลับไม่ใช่ JSON (HTTP ${res.status}): `+raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,160),res.status)}
  if(!res.ok||!data.ok){
    if(res.status===401&&retry){
      const current=getStoredToken()||(isLocalDev?LOCAL_DEV_TOKEN:'');
      // ถ้า Token ถูกเปลี่ยนไปแล้วระหว่างรอ ให้ลองใหม่ด้วยค่าใหม่ ไม่ต้องลบหรือถามซ้ำ
      if(current&&current!==token)return api(action,payload,false);
      const next=isLocalDev?LOCAL_DEV_TOKEN:await promptToken();
      if(next)return api(action,payload,false);
    }
    throw new ApiError(data.message||`เกิดข้อผิดพลาด (HTTP ${res.status})`,res.status,data);
  }
  return data;
}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function num(v){const n=parseFloat(String(v??'').replace(',','.'));return Number.isFinite(n)?n:null}
function chapterNum(v){const m=String(v??'').match(/(\d+(?:\.\d+)?)/);return m?parseFloat(m[1]):0}
function chapterParts(v){const m=String(v??'').trim().match(/^(\d+)(?:\.(\d+))?$/);return m?[Number(m[1]),m[2]===undefined?null:Number(m[2])]:null}
function compareChapterLabels(a,b){const A=chapterParts(a),B=chapterParts(b);if(A&&B){if(A[0]!==B[0])return A[0]-B[0];if(A[1]===null||B[1]===null)return A[1]===B[1]?0:(A[1]===null?-1:1);return A[1]-B[1]}return String(a??'').localeCompare(String(b??''),undefined,{numeric:true,sensitivity:'base'})}
function isValidChapterLabel(v){return /^(?:(?:\d+)(?:\.\d+)?(?:\s*(?:SS|Season|Part)\s*\d+)?|(?:SS|Season)\s*\d+)$/i.test(String(v??'').trim())}
function recordSyncHistory(entry){try{const old=JSON.parse(localStorage.getItem('manga_sync_history')||'[]');old.unshift({...entry,at:new Date().toISOString()});localStorage.setItem('manga_sync_history',JSON.stringify(old.slice(0,100)))}catch{}}
function typeIcon(name){return ({'มังฮวา':'🖌','มังฮวา 18+':'🔞','มังงะ':'📕','มังงะ 18+':'🔞','มันฮัว':'🇨🇳','มันฮัว 18+':'🔞','นิยาย':'📚','นิยาย 18+':'🔞','เว็บตูน':'🌐','เว็บตูน 18+':'🔞','โดจิน':'🎨','โดจิน 18+':'🔞','อื่นๆ':'📁'})[name]||'🏷'}
function adultType(t){return !!(t?.adult||/18\s*\+/i.test(t?.name||''))}
function statusName(s){return ({reading:'กำลังอ่าน',completed:'อ่านจบแล้ว',planned:'วางแผนอ่าน',paused:'พักการอ่าน',dropped:'เลิกอ่าน'})[s]||s}
function completionStatusName(s){return s==='completed'?'🔵 จบแล้ว':'🟢 ยังไม่จบ'}
function timeAgo(value){if(!value)return 'ยังไม่มีการอ่าน';const d=new Date(String(value).replace(' ','T'));if(Number.isNaN(d.getTime()))return String(value);const diff=Math.max(0,Date.now()-d.getTime()),m=Math.floor(diff/60000);if(m<1)return 'เมื่อสักครู่';if(m<60)return `${m} นาทีที่แล้ว`;const h=Math.floor(m/60);if(h<24)return `${h} ชั่วโมงที่แล้ว`;const day=Math.floor(h/24);if(day<30)return `${day} วันที่แล้ว`;return d.toLocaleDateString('th-TH')}
function applyTheme(t,animate=false){
 t=t==='light'?'light':'dark';const root=document.documentElement;
 clearTimeout(window.__themeTransitionTimer);
 if(animate&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){root.dataset.themeTransition='1';root.dataset.theme=t;window.__themeTransitionTimer=setTimeout(()=>root.removeAttribute('data-theme-transition'),190)}
 else{root.removeAttribute('data-theme-transition');root.dataset.theme=t}
 localStorage.setItem('manga_theme',t);const b=$('themeBtn');if(b){b.textContent=t==='light'?'☀':'☾';b.setAttribute('aria-label',t==='light'?'สลับเป็นโหมดมืด':'สลับเป็นโหมดสว่าง');b.title=t==='light'?'สลับเป็นโหมดมืด':'สลับเป็นโหมดสว่าง'}const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute('content',t==='light'?'#f3f6fa':'#090c11')
}
function initTheme(){applyTheme(localStorage.getItem('manga_theme')||'dark')}
function genreIds(x){return String(x?.genre_ids||'').split(',').filter(Boolean).map(Number)}
const GENRE_TH={
 Action:'แอ็กชัน',Adult:'ผู้ใหญ่',Adventure:'ผจญภัย',Comedy:'ตลก',Drama:'ดราม่า',Ecchi:'เอคจิ',
 Fantasy:'แฟนตาซี',Harem:'ฮาเร็ม',Historical:'ประวัติศาสตร์',Horror:'สยองขวัญ',Isekai:'ต่างโลก',
 Josei:'โชโจวัยผู้ใหญ่', 'Martial Arts':'ศิลปะการต่อสู้',Mature:'ผู้ใหญ่/เนื้อหาเข้มข้น',Mystery:'ลึกลับ',
 NTR:'นอกใจ/แย่งคู่',Office:'ออฟฟิศ',Psychology:'จิตวิทยา',Reincarnation:'เกิดใหม่',
 Romance:'โรแมนซ์', 'School Life':'ชีวิตในโรงเรียน','Sci-Fi':'ไซไฟ',Seinen:'เซเน็น',
 Shounen:'โชเน็น','Slice of Life':'ชีวิตประจำวัน',Smut:'อีโรติก',Sports:'กีฬา',
 Supernatural:'เหนือธรรมชาติ',System:'ระบบ','Oneshot':'จบในตอนเดียว','Anthology':'รวมเรื่องสั้น','Academy':'สถาบัน/อคาเดมี','Animals':'สัตว์','Boys Love':'ชายรักชาย','Girls Love':'หญิงรักหญิง','Business':'ธุรกิจ','Coming of Age':'การเติบโต','Cooking':'ทำอาหาร','Crime':'อาชญากรรม','Cultivation':'บำเพ็ญเพียร','Cyberpunk':'ไซเบอร์พังก์','Delinquents':'นักเลง','Demons':'ปีศาจ','Dungeon':'ดันเจี้ยน','Family':'ครอบครัว','Gender Bender':'สลับเพศ','Ghosts':'วิญญาณ','Gore':'โหดเลือดสาด','Gyaru':'สาวแกลล','Hentai':'เฮ็นไท','Housewife':'แม่บ้าน','Hunter':'นักล่า','Idol':'ไอดอล','Magic':'เวทมนตร์','Magical Girls':'สาวน้อยเวทมนตร์','Mecha':'หุ่นยนต์','Medical':'การแพทย์','Military':'ทหาร','Monster Girls':'สาวมอนสเตอร์','Monsters':'สัตว์ประหลาด','Music':'ดนตรี','Overpowered':'ตัวเอกเทพ','Palace Intrigue':'ชิงอำนาจในวัง','Post-Apocalyptic':'โลกหลังล่มสลาย','Regression':'ย้อนเวลากลับมาแก้ตัว','Revenge':'แก้แค้น','Romantic Comedy':'โรแมนติกคอมเมดี้','Royalty':'ราชวงศ์','Samurai':'ซามูไร','Shoujo':'โชโจ','Survival':'เอาชีวิตรอด','Thriller':'ระทึกขวัญ','Time Travel':'ย้อนเวลา','Tower Climbing':'ปีนหอคอย','Tragedy':'โศกนาฏกรรม','Vampires':'แวมไพร์','Vanilla':'รักหวาน','Video Games':'เกม','Villainess':'นางร้าย','Wuxia':'กำลังภายใน','Zombies':'ซอมบี้'
};
function genreLabel(name){const n=String(name||'');const th=GENRE_TH[n]||GENRE_TH[n.trim()];return th?`${n} - ${th}`:n}
function normalizeLeadType(v){const x=String(v||'').trim().toLowerCase();return x==='yaoi'?'gay':['male','female','gay','lesbian'].includes(x)?x:''}
function leadTypeLabel(v){return ({male:'👨 Male Lead - ตัวเอกชาย',female:'👩 Female Lead - ตัวเอกหญิง',gay:'🏳️‍🌈 (Gay) เกย์',lesbian:'🏳️‍🌈 (Lesbian) เลสเบี้ยน'})[normalizeLeadType(v)]||'ไม่ระบุ'}
function genreNames(x){return String(x?.genre_names||'').split('||').filter(Boolean)}
function progressPercent(x){const a=chapterNum(x.current_chapter),b=chapterNum(x.last_chapter||x.latest_chapter);return b>0?Math.max(0,Math.min(100,Math.round(a/b*100))):0}
function unreadCount(x){if(Number.isFinite(Number(x.unread_count)))return Math.max(0,Number(x.unread_count));return Math.max(0,chapterNum(x.last_chapter||x.latest_chapter)-chapterNum(x.current_chapter))}
function collectionIds(x){return x.collection_ids?String(x.collection_ids).split(',').filter(Boolean).map(Number):(state.collectionMap[x.id]||[])}
function typeOf(x){return state.types.find(t=>Number(t.id)===Number(x.type_id??x.category_id))}
function showToast(msg,error=false,duration=3300){const x=$('toast');x.textContent=msg;x.style.background=error?'#b91c1c':'#111820';x.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>x.classList.remove('show'),Math.max(2500,Number(duration)||3300))}
function handleCoverAiError(err){const message=String(err?.message||'ส่งงานสร้างปกไม่สำเร็จ');const balanceExhausted=err?.data?.error_code==='FAL_BALANCE_EXHAUSTED'||/exhausted balance|user is locked|insufficient balance|top.?up.*balance|เครดิต.*หมด/i.test(message);if(balanceExhausted){showToast('บัญชี fal.ai เครดิตหมดหรือถูกล็อกชั่วคราว — เติมเครดิตที่ fal.ai/dashboard/billing ก่อนลองใหม่',true,10000);if(confirm('บัญชี fal.ai ใช้ยอดคงเหลือหมด จึงยังสร้างวิดีโอไม่ได้ ต้องการเปิดหน้าเติมเครดิต fal.ai ตอนนี้หรือไม่?')){location.href='https://fal.ai/dashboard/billing'}return}showToast(message,true,6500)}
function setSaveButtonState(status='idle',progress=0,label=''){
 const btn=$('saveBtn');if(!btn)return;const fill=$('saveBtnFill'),icon=$('saveBtnIcon'),txt=$('saveBtnLabel');
 const fallback=editingId?'บันทึกการเปลี่ยนแปลง':'บันทึกและนำเข้า Chapter';
 btn.dataset.status=status;btn.disabled=status==='downloading';if(fill)fill.style.width=`${Math.max(0,Math.min(100,Number(progress)||0))}%`;
 if(txt)txt.textContent=label||(status==='downloading'?'กำลังบันทึก...':status==='downloaded'?'บันทึกแล้ว':status==='complete'?'เสร็จแล้ว':fallback);
 if(icon)icon.textContent=status==='downloading'?'↻':status==='downloaded'||status==='complete'?'✓':'↓';
}
function clearBackgroundImportTimers(){
 clearTimeout(window.__backgroundImportHideTimer);clearTimeout(window.__backgroundImportExitTimer);
 window.__backgroundImportHideTimer=0;window.__backgroundImportExitTimer=0;
}
function scheduleBackgroundImportAutoHide(state){
 clearTimeout(window.__backgroundImportHideTimer);window.__backgroundImportHideTimer=0;
 const p=$('backgroundImportPanel');if(!p)return;
 const durations={success:7000,partial:7000,error:7000};
 const duration=durations[state];
 if(!duration){delete p.dataset.autohide;p.style.removeProperty('--import-dismiss-ms');return}
 p.dataset.autohide=state;p.style.setProperty('--import-dismiss-ms',`${duration}ms`);
 window.__backgroundImportHideTimer=setTimeout(()=>hideBackgroundImportPanel(true),duration);
}
function setBackgroundImportPanel({state='downloading',progress=0,title='กำลังนำเข้า Chapter',detail='',id=0,url='',canBrowser=false,percentLabel=''}={}){
 const panel=$('backgroundImportPanel');if(!panel)return;clearBackgroundImportTimers();panel.classList.remove('is-hiding');panel.hidden=false;panel.dataset.state=state;
 $('backgroundImportTitle').textContent=title;$('backgroundImportDetail').textContent=detail||'';
 $('backgroundImportSymbol').textContent=state==='success'?'✓':state==='error'?'!':state==='partial'?'⚠':'↻';
 $('backgroundImportFill').style.width=`${Math.max(0,Math.min(100,Number(progress)||0))}%`;
 $('backgroundImportPercent').textContent=percentLabel||`${Math.round(progress)}%`;
 const b=$('backgroundImportBrowser');if(b){b.hidden=!canBrowser;b.dataset.id=String(Number(id)||0);b.dataset.url=String(url||'')}
 // Keep active progress visible; auto-dismiss only terminal statuses.
 scheduleBackgroundImportAutoHide(state);
}
function hideBackgroundImportPanel(animate=true){
 const p=$('backgroundImportPanel');if(!p)return;clearBackgroundImportTimers();delete p.dataset.autohide;p.style.removeProperty('--import-dismiss-ms');
 if(p.hidden)return;
 if(!animate){p.classList.remove('is-hiding');p.hidden=true;return}
 p.classList.add('is-hiding');window.__backgroundImportExitTimer=setTimeout(()=>{p.hidden=true;p.classList.remove('is-hiding');window.__backgroundImportExitTimer=0},240);
}
function directOpenUrl(url){try{const target=new URL(String(url||''),location.href);if(!['http:','https:'].includes(target.protocol))return false;const a=document.createElement('a');a.href=target.href;a.target='_blank';a.rel='noopener noreferrer';a.referrerPolicy='no-referrer';a.style.display='none';document.body.appendChild(a);a.click();a.remove();return true}catch{return false}}


async function refreshAll(){
  // ถ้า Modal เพิ่ม/แก้ไขเปิดอยู่ ห้ามรีเซ็ตค่าที่ผู้ใช้กำลังเลือก
  // เพราะ visibilitychange / interval refresh สามารถเรียก load() ระหว่างกรอกข้อมูลได้
  const modalOpen=!!$('modal')&&!$('modal').classList.contains('hidden');
  const draft=modalOpen?selectedTaxonomy():null;
  const results=await Promise.allSettled([api('list'),api('recent_activity'),api('list_collections'),api('collection_map'),api('list_completion_cards')]);
  const [l,r,c,m,rc]=results;
  if(l.status==='rejected')throw l.reason;
  state.items=(l.value.items||[]).map(x=>({...x,lead_type:normalizeLeadType(x.lead_type)}));state.types=l.value.types||l.value.categories||[];state.genres=l.value.genres||[];
  state.recent=r.status==='fulfilled'?(r.value.latest||[]):[];state.timeline=r.status==='fulfilled'?(r.value.timeline||[]):[];
  state.collections=c.status==='fulfilled'?(c.value.collections||[]):[];state.collectionMap=m.status==='fulfilled'?(m.value.map||{}):{};state.completionCards=rc.status==='fulfilled'?(rc.value.cards||[]):[];
  renderControls();render();renderRecent();renderTimeline();
  if(modalOpen){
    renderPickers(
      draft?.type_id||preferredDefaultTypeId(),
      draft?.genre_ids||[],
      draft?.collection_ids||[],
      draft?.completion_status||'ongoing',
      draft?.lead_type||''
    );
  }else{
    renderPickers();
  }
  renderRewards();
}
function showLibrarySkeleton(){const el=$('mmtLoadingSkeleton');if(!el)return;el.hidden=false;el.classList.remove('hidden');el.setAttribute('aria-hidden','false')}
function hideLibrarySkeleton(){const el=$('mmtLoadingSkeleton');if(!el)return;el.hidden=true;el.classList.add('hidden');el.setAttribute('aria-hidden','true')}
async function load(){
 const firstLoad=!window.__mmtInitialLoadStarted;
 if(firstLoad){window.__mmtInitialLoadStarted=true;showLibrarySkeleton()}
 try{await refreshAll()}
 catch(e){showToast(e.message,true);render()}
 finally{if(firstLoad){hideLibrarySkeleton();window.__mmtInitialLoadDone=true}}
}

function renderControls(){
  $('typeFilter').innerHTML='<option value="all">ทุกประเภท</option>'+state.types.map(t=>`<option value="${t.id}">${esc(typeIcon(t.name)+' '+t.name)}</option>`).join('');
  $('genreFilter').innerHTML='<option value="all">ทุกแนว</option>'+state.genres.map(g=>`<option value="${g.id}">${esc(genreLabel(g.name))}</option>`).join('');
  renderSourceFilter();
  if($('leadFilter'))$('leadFilter').innerHTML='<option value="all">ทุกลักษณะตัวเอก</option><option value="male">👨 Male Lead - ตัวเอกชาย</option><option value="female">👩 Female Lead - ตัวเอกหญิง</option><option value="gay">🏳️‍🌈 (Gay) เกย์</option><option value="lesbian">🏳️‍🌈 (Lesbian) เลสเบี้ยน</option>';
  $('collectionFilter').innerHTML='<option value="all">ทุก Collection</option>'+state.collections.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  $('typeChips').innerHTML='<button class="chip active" data-type="all">ทั้งหมด <small>'+state.items.length+'</small></button>'+state.types.map(t=>`<button class="chip" data-type="${t.id}">${esc(typeIcon(t.name)+' '+t.name)} <small>${state.items.filter(x=>String(x.type_id??x.category_id)===String(t.id)).length}</small></button>`).join('');
  $('genreChips').innerHTML=state.genres.map(g=>`<button class="chip" data-genre="${g.id}">${esc(genreLabel(g.name))} <small>${state.items.filter(x=>genreIds(x).includes(Number(g.id))).length}</small></button>`).join('');
  state.types.forEach(t=>{const b=document.querySelector(`[data-pick-type="${t.id}"]`);if(b)b.hidden=false});
  renderManagers();
  document.querySelectorAll('[data-type]').forEach(b=>b.onclick=()=>{resetAndSet('typeFilter',b.dataset.type);$('genreFilter').value='all';render()});
  document.querySelectorAll('[data-genre]').forEach(b=>b.onclick=()=>{resetAndSet('genreFilter',b.dataset.genre);$('typeFilter').value='all';render()});
}
function resetAndSet(id,v){$(id).value=v;const sel=$(id);if(sel)sel.dispatchEvent(new Event('change',{bubbles:true}));location.hash='library'}
function renderManagers(){
  const mt=$('typeManager'),mg=$('genreManager'),mc=$('collectionManager');if(!mt||!mg)return;
  mt.innerHTML=`<div class="manager-add"><input id="newTypeName" placeholder="เช่น มังฮวา 18+"><label><input id="newTypeAdult" type="checkbox"> 18+</label><button class="red btn" id="addTypeBtn">＋ เพิ่มประเภท</button></div>`+state.types.map(t=>`<div class="manager-row"><div><b>${esc(typeIcon(t.name)+' '+t.name)}</b><small>${t.adult?'ประเภทผู้ใหญ่':'ทั่วไป'} • ${state.items.filter(x=>String(x.type_id??x.category_id)===String(t.id)).length} เรื่อง</small></div><button class="danger-link" data-delete-type="${t.id}">ลบ</button></div>`).join('');
  mg.innerHTML=`<div class="manager-add"><input id="newGenreName" placeholder="เช่น Action / Romance / Fantasy"><button class="red btn" id="addGenreBtn">＋ เพิ่มแนว</button></div>`+state.genres.map(g=>`<div class="manager-row"><div><b>${esc(g.name)}</b><small>${state.items.filter(x=>genreIds(x).includes(Number(g.id))).length} เรื่อง</small></div><button class="danger-link" data-delete-genre="${g.id}">ลบ</button></div>`).join('');
  if(mc){mc.innerHTML=`<div class="manager-add"><input id="newCollectionName" placeholder="เช่น รออ่าน / เรื่องโปรด / Archive"><button class="red btn" id="addCollectionBtn">＋ เพิ่ม Collection</button></div>`+state.collections.map(c=>`<div class="manager-row"><div><b>📁 ${esc(c.name)}</b><small>${Object.values(state.collectionMap).filter(a=>a.includes(Number(c.id))).length} เรื่อง</small></div><button class="danger-link" data-delete-collection="${c.id}">ลบ</button></div>`).join('')}
}
function renderManagersBindings(){
  const b=$('addTypeBtn');if(b)b.onclick=async()=>{const n=$('newTypeName').value.trim();if(!n)return showToast('กรุณาใส่ชื่อประเภท',true);try{await api('add_type',{name:n,adult:$('newTypeAdult').checked?1:0});showToast('เพิ่มประเภทแล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}};
  const g=$('addGenreBtn');if(g)g.onclick=async()=>{const n=$('newGenreName').value.trim();if(!n)return showToast('กรุณาใส่ชื่อแนว',true);try{await api('add_genre',{name:n});showToast('เพิ่มแนวแล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}};
  const c=$('addCollectionBtn');if(c)c.onclick=async()=>{const n=$('newCollectionName').value.trim();if(!n)return showToast('กรุณาใส่ชื่อ Collection',true);try{await api('add_collection',{name:n});showToast('เพิ่ม Collection แล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}};
  document.querySelectorAll('[data-delete-type]').forEach(b=>b.onclick=async()=>{const id=Number(b.dataset.deleteType);const t=state.types.find(x=>Number(x.id)===id);if(!t||!confirm(`ลบประเภท “${t.name}” หรือไม่?\nเรื่องที่ใช้ประเภทนี้จะถูกย้ายไป “อื่นๆ”`))return;try{await api('delete_type',{id});showToast('ลบประเภทแล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}});
  document.querySelectorAll('[data-delete-genre]').forEach(b=>b.onclick=async()=>{const id=Number(b.dataset.deleteGenre);const g=state.genres.find(x=>Number(x.id)===id);if(!g||!confirm(`ลบแนว “${g.name}” หรือไม่?`))return;try{await api('delete_genre',{id});showToast('ลบแนวแล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}});
  document.querySelectorAll('[data-delete-collection]').forEach(b=>b.onclick=async()=>{const id=Number(b.dataset.deleteCollection);if(!confirm('ลบ Collection นี้หรือไม่? เรื่องจะไม่ถูกลบ'))return;try{await api('delete_collection',{id});showToast('ลบ Collection แล้ว');await refreshAll();openTaxonomy()}catch(e){showToast(e.message,true)}});
}
function preferredDefaultTypeId(){
  const preferred=state.types.find(t=>t.name==='มังฮวา 18+');
  const other=state.types.find(t=>t.name==='อื่นๆ');
  return preferred?.id||other?.id||state.types[0]?.id||0;
}
function renderTagsSelector(hostId,kind,options,selectedIds,labelOf){
  const host=$(hostId);if(!host)return;
  const attr=kind==='genre'?'data-pick-genre':'data-pick-collection';
  const chosen=new Set((selectedIds||[]).map(Number));
  const all=(options||[]).map(o=>({id:Number(o.id),label:String(labelOf(o))}));
  const picked=all.filter(t=>chosen.has(t.id));
  const available=all.filter(t=>!chosen.has(t.id));
  host.classList.add('mmt-tags-selector-host');
  const emptyLabel=kind==='genre'?'แนวเรื่อง':'Collection';
  const selectedHtml=picked.length?picked.map(t=>`<button type="button" class="mmt-tag-chip pick selected" ${attr}="${t.id}" aria-pressed="true" title="นำ ${esc(t.label)} ออกจากรายการ"><span>${esc(t.label)}</span><b aria-hidden="true">×</b></button>`).join(''):`<span class="mmt-tags-empty">ยังไม่ได้เลือก${emptyLabel}</span>`;
  const availableHtml=available.length?available.map(t=>`<button type="button" class="mmt-tag-option pick" ${attr}="${t.id}" aria-pressed="false"><span class="mmt-tag-plus" aria-hidden="true">＋</span><span>${esc(t.label)}</span></button>`).join(''):'<span class="mmt-tags-all-selected">เลือกครบทั้งหมดแล้ว</span>';
  host.innerHTML=`<div class="mmt-tags-selector" data-kind="${kind}">
    <div class="mmt-tags-selected" aria-label="แท็กที่เลือก" aria-live="polite">${selectedHtml}</div>
    <div class="mmt-tags-subhead"><span>เลือกเพิ่ม</span><small>${picked.length} / ${all.length} รายการ</small></div>
    <div class="mmt-tags-options">${availableHtml}</div>
  </div>`;
}
function toggleTagsSelector(hostId,kind,id){
  const host=$(hostId);if(!host)return;
  const attr=kind==='genre'?'data-pick-genre':'data-pick-collection';
  const selected=[...host.querySelectorAll(`[${attr}].selected`)].map(b=>Number(b.getAttribute(attr))).filter(Number.isFinite);
  const next=selected.includes(Number(id))?selected.filter(v=>v!==Number(id)):[...selected,Number(id)];
  const options=kind==='genre'?state.genres:state.collections;
  renderTagsSelector(hostId,kind,options,next,o=>kind==='genre'?genreLabel(o.name):o.name);
}
function renderPickers(typeId=null,selectedG=[],selectedC=[],completionStatus='ongoing',leadType=''){
  const tp=$('typePicker'),gp=$('genrePicker'),cp=$('collectionPicker'),sp=$('completionPicker'),lp=$('leadPicker');if(!tp||!gp||!cp||!sp||!lp)return;
  if(typeId==null)typeId=preferredDefaultTypeId();
  completionStatus=completionStatus==='completed'?'completed':'ongoing';
  leadType=normalizeLeadType(leadType);
  tp.innerHTML=state.types.map(t=>`<button type="button" class="pick ${String(t.id)===String(typeId)?'selected':''} ${adultType(t)?'adult-pick':''}" data-pick-type="${t.id}">${esc(typeIcon(t.name)+' '+t.name)}</button>`).join('');
  renderTagsSelector('genrePicker','genre',state.genres,selectedG,o=>genreLabel(o.name));
  renderTagsSelector('collectionPicker','collection',state.collections,selectedC,o=>o.name);
  lp.innerHTML=[['','⚪ ไม่ระบุ'],['male','👨 Male Lead - ตัวเอกชาย'],['female','👩 Female Lead - ตัวเอกหญิง'],['gay','🏳️‍🌈 (Gay) เกย์'],['lesbian','🏳️‍🌈 (Lesbian) เลสเบี้ยน']].map(([value,label])=>`<button type="button" class="pick lead-pick ${value===leadType?'selected':''}" data-pick-lead="${value}">${label}</button>`).join('');
  sp.innerHTML=[['ongoing','🟢 ยังไม่จบ'],['completed','🔵 จบแล้ว']].map(([value,label])=>`<button type="button" class="pick completion-pick ${value===completionStatus?'selected':''}" data-pick-completion="${value}">${label}</button>`).join('');
}
function selectedTaxonomy(){return{type_id:Number(document.querySelector('[data-pick-type].selected')?.dataset.pickType||0),genre_ids:[...document.querySelectorAll('[data-pick-genre].selected')].map(b=>Number(b.dataset.pickGenre)),collection_ids:[...document.querySelectorAll('[data-pick-collection].selected')].map(b=>Number(b.dataset.pickCollection)),lead_type:document.querySelector('[data-pick-lead].selected')?.dataset.pickLead||'',completion_status:document.querySelector('[data-pick-completion].selected')?.dataset.pickCompletion||'ongoing'}}

const VIDEO_COVER_RE=/\.(mp4|webm|m4v)(?:[?#].*)?$/i;
function isVideoCover(u){return VIDEO_COVER_RE.test(String(u||'').trim())}
function videoCoverHtml(src,cls='',attrs=''){return `<video class="${cls}" src="${esc(src)}" muted loop playsinline preload="metadata" disablepictureinpicture ${attrs} data-cover-video="1"></video>`}
function coverHtml(x){const src=String(x.cover_url||'');if(isVideoCover(src)){return `${videoCoverHtml(src,'cover-motion-video cover-file-video','aria-label="ปกเคลื่อนไหว"')}<span class="cover-light-sweep" aria-hidden="true"></span>`}const motion=String(x.cover_motion_url||'');const isToonjai=/\btoonjai\.com\//i.test(String(x.source_url||''))||/storage\.toonjai\.com/i.test(src);const backdrop=src?`<span class="cover-art-backdrop" aria-hidden="true" style="background-image:url(&quot;${esc(src)}&quot;)"></span>`:'';const sweep='<span class="cover-light-sweep" aria-hidden="true"></span>';if(motion&&x.cover_motion_status==='completed')return `${backdrop}<video class="cover-motion-video ${isToonjai?'toonjai-cover-img':''}" src="${esc(motion)}" poster="${esc(src)}" autoplay muted loop playsinline preload="metadata" aria-label="ปกเคลื่อนไหว"></video>${sweep}`;return src?`${backdrop}<img class="${isToonjai?'toonjai-cover-img':''}" src="${esc(src)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.style.display='none';const f=this.parentElement.querySelector('.cover-fallback');if(f)f.style.display='grid'">${sweep}`:''}

/* v17.11 — card-theme swatch picker (reads colours from the .manga-theme-* CSS so there is one source of truth) */
function syncThemeSwatches(){const sel=$('cardTheme'),host=$('themeSwatches');if(!sel||!host)return;host.querySelectorAll('[data-theme-pick]').forEach(b=>b.classList.toggle('active',b.dataset.themePick===sel.value))}
function buildThemeSwatches(){
 const sel=$('cardTheme'),host=$('themeSwatches');if(!sel||!host||host.dataset.ready)return;host.dataset.ready='1';
 host.innerHTML=[...sel.options].map(o=>{
  const name=esc(o.textContent.trim());
  if(o.value==='auto')return `<button type="button" class="theme-swatch auto" data-theme-pick="auto" title="${name}" aria-label="${name}"><span>A</span></button>`;
  return `<button type="button" class="theme-swatch manga-theme-${o.value}" data-theme-pick="${o.value}" data-theme-label="${name.toLowerCase()}" title="${name}" aria-label="${name}"></button>`;
 }).join('');
 host.addEventListener('click',e=>{const b=e.target.closest('[data-theme-pick]');if(!b)return;sel.value=b.dataset.themePick;syncThemeSwatches()});
 const search=$('themeSearch');const filter=()=>{const q=(search?.value||'').trim().toLowerCase();host.querySelectorAll('[data-theme-pick]').forEach(b=>{b.hidden=!!q&&!(`${b.dataset.themePick||''} ${b.dataset.themeLabel||b.title||''}`).toLowerCase().includes(q)})};
 search?.addEventListener('input',filter);sel.addEventListener('change',syncThemeSwatches);syncThemeSwatches();
}

/* v17.10 — Oneshot (1 เรื่อง 1 ตอน) helpers: detect, declutter cards, separate shelf */
function isOneshot(x){
 if(!x)return false;
 if(genreNames(x).some(n=>/^one[\s-]?shot$/i.test(String(n).trim())))return true;
 if(/จบในตอนเดียว|ตอนเดียวจบ/.test(`${x.title||''} ${x.alt_title||''}`))return true;
 return x.completion_status==='completed'&&Number(x.chapter_count||0)===1;
}
function oneshotBrowsing(q,tid,gid,lt,st,rf,cf,sf){return !q&&tid==='all'&&gid==='all'&&lt==='all'&&st==='all'&&rf==='all'&&cf==='all'&&sf==='all'}
function fillOneshotGrid(){
 const grid=$('oneshotGrid');if(!grid)return;
 const list=state.items.filter(isOneshot).sort((a,b)=>new Date(b.updated_at||0)-new Date(a.updated_at||0));
 grid.innerHTML=list.map(x=>card(x,true)).join('');
}
function renderOneshotShelf(){
 const sec=$('oneshotShelf');if(!sec)return;
 const os=$('oneshotFilter')?.value||'separate';
 const browse=oneshotBrowsing(($('search')?.value||'').trim().toLowerCase(),$('typeFilter').value,$('genreFilter').value,$('leadFilter')?.value||'all',$('statusFilter').value,$('readFilter').value,$('collectionFilter').value,$('sourceFilter')?.value||'all');
 const total=state.items.filter(isOneshot).length;
 const show=os==='separate'&&browse&&total>0;
 sec.hidden=!show;sec.classList.toggle('hidden',!show);
 if(!show){const g=$('oneshotGrid');if(g)g.innerHTML='';return}
 $('oneshotCount').textContent=`${total} เรื่อง`;
 if(sec.open)fillOneshotGrid();else{const g=$('oneshotGrid');if(g)g.innerHTML=''}
}
function setupOneshotShelf(){
 const sec=$('oneshotShelf');if(!sec||sec.dataset.ready)return;sec.dataset.ready='1';
 try{sec.open=localStorage.getItem('mmt_oneshot_open')==='1'}catch{}
 sec.addEventListener('toggle',()=>{try{localStorage.setItem('mmt_oneshot_open',sec.open?'1':'0')}catch{}if(sec.open)fillOneshotGrid();else{const g=$('oneshotGrid');if(g)g.innerHTML=''}});
}
function card(x,compact=false){
 const t=typeOf(x),label=t?.name||x.category_name||'อื่นๆ',g=genreNames(x).slice(0,3),cols=collectionIds(x).map(id=>state.collections.find(c=>Number(c.id)===id)?.name).filter(Boolean).slice(0,2),unread=unreadCount(x),pct=progressPercent(x),host=sourceHost(x.source_url),syncText=x.sync_status==='blocked'?'ต้องใช้ Browser Import':x.sync_status==='error'?'ซิงก์ล้มเหลว':x.sync_status==='partial'?'ดึงไม่ครบ':x.sync_status==='unverifiable'?'ยืนยันจำนวนไม่ได้':x.sync_status==='review'?'ตรวจสอบผลแล้ว':x.sync_status==='success'?'ซิงก์แล้ว':'ยังไม่ซิงก์';
 const selected=state.selectedIds.has(Number(x.id));
 const one=isOneshot(x),oneRead=chapterNum(x.current_chapter)>=1;
 const theme=cardThemeFor(x);
 const ratingVal=Number(x.rating||0);
 const starSvg='<svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.2l-5.9 3.4 1.3-6.6-4.9-4.6 6.6-.8z" fill="currentColor"/></svg>';
 const scoreChip=ratingVal>0?`<span class="card-score" title="คะแนน ${ratingVal.toFixed(1)} / 5">${starSvg}<b>${ratingVal.toFixed(1)}</b></span>`:`<span class="card-score empty" title="ยังไม่ให้คะแนน">${starSvg}<b>—</b></span>`;
 const listScore=`<div class="list-score ${ratingVal>0?'':'no-score'}" title="${ratingVal>0?'คะแนน '+ratingVal.toFixed(1)+' / 5':'ยังไม่ให้คะแนน'}">${starSvg}<b>${ratingVal>0?ratingVal.toFixed(1):'—'}</b></div>`;
 // In list view, move every informational badge out of the cover image.
 // Compact cards (continue/recent/favorites) keep their original cover badges.
 const listMode=!!state.libraryListMode&&!compact;
 const coverBadges=listMode?'':`<span class="type-tag ${adultType(t)?'adult-tag':''}">${esc(typeIcon(label)+' '+label)}</span>${unread?`<span class="new-badge">＋${unread} ตอนใหม่</span>`:''}${x.completion_status?`<span class="completion-badge ${x.completion_status==='completed'?'completed':''}">${completionStatusName(x.completion_status)}</span>`:''}${x.lead_type?`<span class="lead-badge">${esc(leadTypeLabel(x.lead_type))}</span>`:''}<span class="genre-stack">${g.map(z=>`<i>${esc(genreLabel(z))}</i>`).join('')}${cols.map(z=>`<i class="collection-chip">📁 ${esc(z)}</i>`).join('')}</span>`;
 const listTags=listMode?`<div class="card-list-tags" aria-label="แท็กของเรื่อง"><span class="card-list-tag tag-type ${adultType(t)?'adult':''}">${esc(typeIcon(label)+' '+label)}</span>${unread?`<span class="card-list-tag tag-new">＋${unread} ตอนใหม่</span>`:''}${x.completion_status?`<span class="card-list-tag tag-completion ${x.completion_status==='completed'?'completed':''}">${completionStatusName(x.completion_status)}</span>`:''}${x.lead_type?`<span class="card-list-tag tag-lead">${esc(leadTypeLabel(x.lead_type))}</span>`:''}${g.map(z=>`<span class="card-list-tag tag-genre">${esc(genreLabel(z))}</span>`).join('')}${cols.map(z=>`<span class="card-list-tag tag-collection">📁 ${esc(z)}</span>`).join('')}</div>`:'';
 const mobileTags=(!compact&&!listMode)?`<div class="card-mobile-tags" aria-label="หมวดหมู่เรื่อง"><span class="card-list-tag tag-type ${adultType(t)?'adult':''}">${esc(typeIcon(label)+' '+label)}</span>${unread?`<span class="card-list-tag tag-new">＋${unread} ตอนใหม่</span>`:''}${x.completion_status?`<span class="card-list-tag tag-completion ${x.completion_status==='completed'?'completed':''}">${completionStatusName(x.completion_status)}</span>`:''}${x.lead_type?`<span class="card-list-tag tag-lead">${esc(leadTypeLabel(x.lead_type))}</span>`:''}${g.slice(0,2).map(z=>`<span class="card-list-tag tag-genre">${esc(genreLabel(z))}</span>`).join('')}${cols.slice(0,1).map(z=>`<span class="card-list-tag tag-collection">📁 ${esc(z)}</span>`).join('')}</div>`:'';
 return `<article class="card manga-theme-${theme} ${one?'oneshot-card':''} ${compact?'compact-card':''} ${listMode?'list-card':''} ${selected?'bulk-selected':''}" data-card-id="${x.id}" data-card-theme="${theme}">${listMode?'<div class="list-side">':''}<div class="card-cover-wrap"><a href="manga.html?id=${x.id}"><div class="card-cover cover-3d">${coverBadges}${coverHtml(x)}<div class="cover-fallback" ${x.cover_url?'style="display:none"':''}>${esc(String(x.title||'').slice(0,42))}</div></div></a><button class="fav-btn ${Number(x.favorite)?'active':''}" data-fav="${x.id}" title="รายการโปรด" type="button">★</button></div>${!compact?`${listMode?listScore:''}<div class="card-select-row"><label class="card-select"><input type="checkbox" data-bulk-select="${x.id}" ${selected?'checked':''} aria-label="เลือก ${esc(x.title)}"><span>เลือก</span></label>${listMode?'':scoreChip}</div>`:''}${listMode?'</div><div class="list-main">':''}<div class="card-title">${esc(x.title)}</div>${mobileTags}${listTags}<div class="card-sub">${esc(statusName(x.status))} • ${Number(x.chapter_count||0)} ตอน • ${timeAgo(x.last_read_at)}</div>${one?`<div class="card-line"><span class="chapter-pill oneshot-pill">📄 ตอนเดียวจบ</span><span class="chapter-pill ${oneRead?'accent':''}">${oneRead?'✓ อ่านแล้ว':'ยังไม่อ่าน'}</span></div>`:`<div class="card-line"><span class="chapter-pill accent">อ่านถึง ${esc(x.current_chapter||'0')}</span><span class="chapter-pill">ล่าสุด ${esc(x.last_chapter||x.latest_chapter||'-')}</span></div><div class="progress-row"><div class="progress-track"><i style="width:${pct}%"></i></div><span>${pct}%</span></div>`}<div class="card-source-meta"><span title="${esc(x.source_url||'')}">🌐 ${esc(host||'ไม่ทราบเว็บ')}</span><span class="sync-pill sync-${esc(x.sync_status||'idle')}" title="${esc(x.sync_error||'')}">${esc(syncText)}</span></div>${listMode?'</div>':''}<div class="card-actions"><button class="mini-action" data-edit="${x.id}">✎ แก้ไข</button><button class="mini-action" data-delete="${x.id}" aria-label="ลบเรื่อง">${DEL_ICO.trash}<span>ลบ</span></button></div></article>`
}
// ---- v13.7: กรอง/ค้นหาตามเว็บต้นทาง (ไว้วางแผนย้ายเรื่องเมื่อเว็บล่ม) ----
function sourceHost(u){try{return new URL(String(u||'').trim()).hostname.toLowerCase().replace(/^www\./,'')}catch{return ''}}
function siteMatch(h,site){return !!h&&!!site&&(h===site||h.endsWith('.'+site))}
function siteFromQuery(q){const t=String(q||'').trim();if(!t||/\s/.test(t)||!/^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}([\/?#]\S*)?$/i.test(t))return '';try{return new URL(/^https?:\/\//i.test(t)?t:'https://'+t).hostname.toLowerCase().replace(/^www\./,'')}catch{return ''}}
function activeSite(){const v=$('sourceFilter')?.value||'all';return v!=='all'?v:siteFromQuery($('search')?.value||'')}
function renderSourceFilter(){
  const el=$('sourceFilter');if(!el)return;
  const prev=el.value||'all',counts={};
  const all=new Set(state.items.map(x=>sourceHost(x.source_url)).filter(Boolean));
  const parentOf=h=>{let best=h;all.forEach(o=>{if(o!==h&&h.endsWith('.'+o)&&o.length<best.length)best=o});return best};
  state.items.forEach(x=>{const h=sourceHost(x.source_url);if(h){const g=parentOf(h);counts[g]=(counts[g]||0)+1}});
  const hosts=Object.keys(counts).sort((a,b)=>counts[b]-counts[a]||a.localeCompare(b));
  el.innerHTML='<option value="all">ทุกเว็บต้นทาง</option>'+hosts.map(h=>`<option value="${esc(h)}">${esc(h)} (${counts[h]})</option>`).join('');
  el.value=hosts.includes(prev)?prev:'all';
}
function syncSourceTools(a){const b=$('copySourceBtn');if(!b)return;const on=!!activeSite()&&a.length>0;b.classList.toggle('hidden',!on);b.textContent=`📋 คัดลอกรายชื่อ (${a.length})`}
async function copySourceList(){
  const a=filteredItems();if(!a.length)return;
  const text=a.map(x=>`${x.title}\t${x.source_url||''}`).join('\n');
  try{await navigator.clipboard.writeText(text);showToast(`คัดลอก ${a.length} เรื่องแล้ว (ชื่อ + ลิงก์)`)}
  catch{const t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();try{document.execCommand('copy');showToast(`คัดลอก ${a.length} เรื่องแล้ว (ชื่อ + ลิงก์)`)}catch{showToast('คัดลอกไม่สำเร็จ',true)}t.remove()}
}
function filteredItems(){
 const q=($('search')?.value||'').trim().toLowerCase(),tid=$('typeFilter').value,gid=$('genreFilter').value,lt=$('leadFilter')?.value||'all',st=$('statusFilter').value,rf=$('readFilter').value,sort=$('sortFilter').value,rtf=$('ratingFilter')?.value||'all',cf=$('collectionFilter').value,sf=$('sourceFilter')?.value||'all',os=$('oneshotFilter')?.value||'separate',qSite=siteFromQuery(q),hostLoose=!qSite&&q.length>=3&&!/\s/.test(q)&&!state.items.some(x=>`${x.title||''} ${x.alt_title||''} ${x.note||''} ${genreNames(x).join(' ')}`.toLowerCase().includes(q));
 const osHide=(os==='separate'||os==='hide')&&oneshotBrowsing(q,tid,gid,lt,st,rf,cf,sf),osOnly=os==='only';
    let a=state.items.filter(x=>{if(osHide&&isOneshot(x))return false;if(osOnly&&!isOneshot(x))return false;const host=sourceHost(x.source_url),siteOk=(sf==='all'||siteMatch(host,sf))&&(!qSite||siteMatch(host,qSite));const text=`${x.title||''} ${x.alt_title||''} ${x.note||''} ${genreNames(x).join(' ')}`.toLowerCase(),cols=collectionIds(x),unread=unreadCount(x)>0;const readOk=rf==='all'?true:rf==='unread'?unread:rf==='synced'?!unread:rf==='favorite'?Number(x.favorite)===1:true;const textOk=qSite?true:hostLoose?host.includes(q):(!q||text.includes(q));return textOk&&siteOk&&(tid==='all'||String(x.type_id??x.category_id)===String(tid))&&(gid==='all'||genreIds(x).includes(Number(gid)))&&(st==='all'||x.status===st)&&(lt==='all'||String(x.lead_type||'')===lt)&&(cf==='all'||cols.includes(Number(cf)))&&readOk&&(rtf==='all'||(rtf==='unrated'?!(Number(x.rating)>0):Number(x.rating)>=Number(rtf)))});
 if(sort==='title')a.sort((x,y)=>String(x.title).localeCompare(String(y.title),'th'));if(sort==='chapter')a.sort((x,y)=>compareChapterLabels(y.last_chapter||y.latest_chapter||'0',x.last_chapter||x.latest_chapter||'0'));if(sort==='favorite')a.sort((x,y)=>Number(y.favorite)-Number(x.favorite)||new Date(y.updated_at||0)-new Date(x.updated_at||0));if(sort==='rating')a.sort((x,y)=>Number(y.rating||0)-Number(x.rating||0)||new Date(y.updated_at||0)-new Date(x.updated_at||0));if(sort==='rating_low')a.sort((x,y)=>{const rx=Number(x.rating)>0?Number(x.rating):99,ry=Number(y.rating)>0?Number(y.rating):99;return rx-ry||new Date(y.updated_at||0)-new Date(x.updated_at||0)});if(sort==='recent')a.sort((x,y)=>new Date(y.last_read_at||0)-new Date(x.last_read_at||0));if(sort==='updated')a.sort((x,y)=>new Date(y.updated_at||0)-new Date(x.updated_at||0));return a}
function ratingStarsHtml(rating){
  const r=Math.max(0,Math.min(5,Math.round((Number(rating)||0)*2)/2));
  if(!r)return '☆☆☆☆☆';
  const full=Math.floor(r),half=r-full>=.5?1:0;
  return '★'.repeat(full)+(half?'<span class="half-star" aria-hidden="true">☆</span>':'')+'☆'.repeat(5-full-half);
}
function ratingSelectValue(v){const n=Number(v);return Number.isFinite(n)&&n>0?String(n):''}
function rewardStars(rating){return ratingStarsHtml(rating)}
const REWARD_RARITY_META={
  "common":{key:"common",group:"common",label:"COMMON I",icon:"◈",note:"0–9 Chapters",min:0,max:9},
  "common-ii":{key:"common-ii",group:"common",label:"COMMON II",icon:"◈",note:"10–19 Chapters",min:10,max:19},
  "common-iii":{key:"common-iii",group:"common",label:"COMMON III",icon:"◈",note:"20–29 Chapters",min:20,max:29},
  "common-iv":{key:"common-iv",group:"common",label:"COMMON IV",icon:"◈",note:"30–39 Chapters",min:30,max:39},
  "common-v":{key:"common-v",group:"common",label:"COMMON V",icon:"◈",note:"40–49 Chapters",min:40,max:49},
  "uncommon":{key:"uncommon",group:"uncommon",label:"UNCOMMON I",icon:"◇",note:"50–59 Chapters",min:50,max:59},
  "uncommon-ii":{key:"uncommon-ii",group:"uncommon",label:"UNCOMMON II",icon:"◇",note:"60–69 Chapters",min:60,max:69},
  "uncommon-iii":{key:"uncommon-iii",group:"uncommon",label:"UNCOMMON III",icon:"◇",note:"70–79 Chapters",min:70,max:79},
  "uncommon-iv":{key:"uncommon-iv",group:"uncommon",label:"UNCOMMON IV",icon:"◇",note:"80–89 Chapters",min:80,max:89},
  "uncommon-v":{key:"uncommon-v",group:"uncommon",label:"UNCOMMON V",icon:"◇",note:"90–99 Chapters",min:90,max:99},
  "rare":{key:"rare",group:"rare",label:"RARE I",icon:"◆",note:"100–124 Chapters",min:100,max:124},
  "rare-ii":{key:"rare-ii",group:"rare",label:"RARE II",icon:"◆",note:"125–149 Chapters",min:125,max:149},
  "rare-iii":{key:"rare-iii",group:"rare",label:"RARE III",icon:"◆",note:"150–174 Chapters",min:150,max:174},
  "rare-iv":{key:"rare-iv",group:"rare",label:"RARE IV",icon:"◆",note:"175–199 Chapters",min:175,max:199},
  "rare-v":{key:"rare-v",group:"rare",label:"RARE V",icon:"◆",note:"200–224 Chapters",min:200,max:224},
  "rare-vi":{key:"rare-vi",group:"rare",label:"RARE VI",icon:"◆",note:"225–249 Chapters",min:225,max:249},
  "rare-vii":{key:"rare-vii",group:"rare",label:"RARE VII",icon:"◆",note:"250–274 Chapters",min:250,max:274},
  "rare-viii":{key:"rare-viii",group:"rare",label:"RARE VIII",icon:"◆",note:"275–299 Chapters",min:275,max:299},
  "epic":{key:"epic",group:"epic",label:"EPIC I",icon:"✦",note:"300–324 Chapters",min:300,max:324},
  "epic-ii":{key:"epic-ii",group:"epic",label:"EPIC II",icon:"✦",note:"325–349 Chapters",min:325,max:349},
  "epic-iii":{key:"epic-iii",group:"epic",label:"EPIC III",icon:"✦",note:"350–374 Chapters",min:350,max:374},
  "epic-iv":{key:"epic-iv",group:"epic",label:"EPIC IV",icon:"✦",note:"375–399 Chapters",min:375,max:399},
  "epic-v":{key:"epic-v",group:"epic",label:"EPIC V",icon:"✦",note:"400–424 Chapters",min:400,max:424},
  "epic-vi":{key:"epic-vi",group:"epic",label:"EPIC VI",icon:"✦",note:"425–449 Chapters",min:425,max:449},
  "epic-vii":{key:"epic-vii",group:"epic",label:"EPIC VII",icon:"✦",note:"450–474 Chapters",min:450,max:474},
  "epic-viii":{key:"epic-viii",group:"epic",label:"EPIC VIII",icon:"✦",note:"475–499 Chapters",min:475,max:499},
  "legendary":{key:"legendary",group:"legendary",label:"LEGENDARY",icon:"♛",note:"500+ Chapters",min:500,max:Infinity}
};
const REWARD_RARITY_ORDER=Object.keys(REWARD_RARITY_META);
function normalizeRewardRarityOverride(value){
  if(REWARD_RARITY_META[value])return value;
  // Compatibility: old manual levels above 500 now fold into the single 500+ LEGENDARY level.
  if(['legendary-ii','mythic','divine','celestial','eternal'].includes(String(value||'')))return 'legendary';
  return 'auto';
}
function rewardRarity(chapters,override='auto'){
  const n=Math.max(0,Number(chapters||0));
  const normalized=normalizeRewardRarityOverride(override);
  if(normalized!=='auto')return {...REWARD_RARITY_META[normalized],note:'กำหนดระดับเอง'};
  for(let i=REWARD_RARITY_ORDER.length-1;i>=0;i--){const tier=REWARD_RARITY_META[REWARD_RARITY_ORDER[i]];if(n>=tier.min)return tier;}
  return REWARD_RARITY_META.common;
}
function rewardRarityOptionsHtml(card){
  const current=normalizeRewardRarityOverride(card.rarity_override);
  const options=[{key:'auto',label:'AUTO',icon:'↻',desc:`ตามจำนวนตอน · ${rewardRarity(card.chapter_count).label}`},...REWARD_RARITY_ORDER.map(key=>({...REWARD_RARITY_META[key],desc:REWARD_RARITY_META[key].note}))];
  return options.map(o=>`<button type="button" class="tcg-rarity-choice ${o.key!=='auto'?'rarity-'+o.key:''} ${current===o.key?'selected':''}" data-set-rarity="${o.key}" aria-pressed="${current===o.key?'true':'false'}"><span class="tcg-rarity-icon">${o.icon}</span><span class="tcg-rarity-label">${o.label}</span><small>${esc(o.desc)}</small></button>`).join('');
}
function rewardRatingHtml(rating){
  const r=Number(rating||0);
  return r>0
    ? `<span class="reward-rating" title="คะแนนปัจจุบันของเรื่อง"><span class="reward-stars">${rewardStars(r)}</span><b>${r.toFixed(1)}</b><small>/5</small></span>`
    : `<span class="reward-rating empty" title="ยังไม่ได้ให้คะแนนเรื่อง"><span class="reward-stars">☆☆☆☆☆</span><b>—</b><small>/5</small></span>`;
}
function rewardDateHtml(dateValue){
  if(!dateValue)return '-';
  const d=new Date(String(dateValue).replace(' ','T'));
  if(Number.isNaN(d.getTime()))return esc(String(dateValue));
  return esc(d.toLocaleDateString('th-TH',{day:'2-digit',month:'short',year:'numeric'}));
}
function rewardCardHtml(card,large=false){
  const num=String(card.card_number||card.id||0).padStart(3,'0');
  const chapters=Number(card.chapter_count||0);
  const rating=Number(card.rating||0);
  const rarity=rewardRarity(chapters,card.rarity_override);
  const cover=card.cover_snapshot
    ? `<img src="${esc(card.cover_snapshot)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
    : '<div class="reward-cover-fallback">🏆</div>';
  const rewardTheme=['aurora','rose','cosmic','royal','sunset'][Math.abs(Number(card.manga_id||card.id||0))%5];
  const messages={common:'🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว',uncommon:'✨ อีกหนึ่งเรื่องราวที่คุณพาไปจนถึงบทสุดท้าย',rare:'💎 ความสำเร็จชิ้นพิเศษได้เพิ่มในคอลเลกชัน',epic:'👑 เรื่องราวระดับมหากาพย์ที่คุณอ่านจนจบ',legendary:'🏆 ตำนานบทนี้จะอยู่ในคอลเลกชันของคุณตลอดไป',mythic:'🌌 การ์ดระดับ Mythic ได้เข้าสู่คลังสะสม',divine:'🔱 ความสำเร็จระดับ Divine ที่หาได้ยากยิ่ง',celestial:'🌠 การ์ด Celestial ส่องประกายเหนือคอลเลกชัน',eternal:'♾️ การ์ด Eternal — ความสำเร็จระดับสูงสุดของคอลเลกชัน'};
  const message=card.message||messages[rarity.group]||messages[rarity.key]||'🎉 ยินดีด้วย! คุณอ่านเรื่องนี้จบแล้ว';
  const ratingBlock=rewardRatingHtml(card.rating);
  return `<article class="reward-card reward-theme-${rewardTheme} rarity-${rarity.key} ${large?'reward-card-large':''}" data-reward-id="${card.id}" tabindex="0" role="button" aria-label="ดูการ์ดสะสม ${esc(card.title_snapshot)} แบบ 3D และเลือกระดับความหายาก">
    <div class="reward-card-aura"></div>
    <div class="reward-card-shimmer"></div>
    <div class="reward-card-inner">
      <div class="reward-bg" aria-hidden="true">${cover}</div>

      <div class="reward-card-cover">
        <div class="reward-image-frame">${cover}</div>
        <div class="reward-cover-vignette"></div>
        <div class="reward-cover-gloss"></div>
        <div class="reward-holo"></div>
        <div class="reward-corner-mark reward-corner-tl">✦</div>
        <div class="reward-corner-mark reward-corner-tr">✦</div>
        <div class="reward-corner-mark reward-corner-bl">✧</div>
        <div class="reward-corner-mark reward-corner-br">✧</div>

        <span class="reward-edition">${rarity.icon} ${rarity.label}</span>
        <span class="reward-number"><small>NO.</small> #${num}</span>

        <div class="reward-cover-title">
          <span>MANGA COMPLETION</span>
          <b>${esc(card.title_snapshot)}</b>
        </div>

        <span class="reward-complete-seal">
          <b>✓</b>
          <span>COMPLETED</span>
        </span>

        <span class="reward-cover-score">${rating?'★ '+rating.toFixed(1):'☆ —'}</span>
        <div class="reward-foil"></div>
      </div>

      <div class="reward-card-body">
        <div class="reward-topline">
          <span>🏆 COMPLETION ARCHIVE</span>
          <i>MYMANGA COLLECTION</i>
        </div>

        <h3>${esc(card.title_snapshot)}</h3>

        <div class="reward-rarity-line">
          <span class="rarity-dot"></span>
          <b>${rarity.label}</b>
          <small>${rarity.note}</small>
        </div>

        <div class="reward-title-rule">
          <span></span><b>READ • COMPLETE • COLLECT</b><span></span>
        </div>

        <p class="reward-message">${esc(message)}</p>

        <div class="reward-stat-grid">
          <div class="reward-stat">
            <small>CHAPTERS</small>
            <b>${chapters}</b>
            <span>ตอน</span>
          </div>
          <div class="reward-stat reward-stat-rating">
            <small>RATING</small>
            ${ratingBlock}
          </div>
        </div>

        <div class="reward-footer">
          <div>
            <small>UNLOCKED</small>
            <b>${rewardDateHtml(card.completed_at)}</b>
          </div>
          <div class="reward-footer-mark">✦</div>
          <div class="reward-serial">
            <small>COMPLETION</small>
            <b>#${num}</b>
          </div>
        </div>

        <div class="reward-bottom-line">
          <span>MYMANGA TRACKER</span>
          <span>AUTHENTIC COMPLETION</span>
          <span>${rarity.icon}</span>
        </div>
        <div class="reward-card-open-hint"><span>◇</span><b>ดูการ์ด 3D / ปรับระดับ</b><i>FLIP CARD</i></div>
      </div>
    </div>
  </article>`;
}
const REWARD_FOLDER_GROUPS=[
  {key:'common',label:'COMMON',symbol:'◈',range:'0–49 CHAPTERS',tiers:'I–V · 5 ระดับ',tone:'steel',desc:'เริ่มต้นคอลเลกชัน'},
  {key:'uncommon',label:'UNCOMMON',symbol:'◇',range:'50–99 CHAPTERS',tiers:'I–V · 5 ระดับ',tone:'venom',desc:'การ์ดระดับก้าวหน้า'},
  {key:'rare',label:'RARE',symbol:'◆',range:'100–299 CHAPTERS',tiers:'I–VIII · 8 ระดับ',tone:'sapphire',desc:'การ์ดหายาก'},
  {key:'epic',label:'EPIC',symbol:'✦',range:'300–499 CHAPTERS',tiers:'I–VIII · 8 ระดับ',tone:'amethyst',desc:'การ์ดระดับสูง'},
  {key:'legendary',label:'LEGENDARY',symbol:'♛',range:'500+ CHAPTERS',tiers:'สูงสุด · 500+',tone:'bloodsteel',desc:'ตำนานแห่งคอลเลกชัน'}
];
// Archive grouping and counts always follow the actual Chapter range, not a manually styled badge.
function rewardFolderGroupForCard(card){return rewardRarity(Number(card.chapter_count||0)).group||'common'}
function renderRewardFolders(){
  const host=$('collectorFolderGrid');if(!host)return;
  const counts={common:0,uncommon:0,rare:0,epic:0,legendary:0};
  state.completionCards.forEach(card=>{const g=rewardFolderGroupForCard(card);if(counts[g]!==undefined)counts[g]++});
  host.innerHTML=REWARD_FOLDER_GROUPS.map(folder=>{
    const selected=activeRewardFolder===folder.key;
    const count=counts[folder.key]||0;
    return `<button type="button" class="collector-glass-folder tone-${folder.tone}${selected?' is-selected':''}" data-reward-folder="${folder.key}" aria-pressed="${selected?'true':'false'}" aria-label="กรองการ์ดระดับ ${folder.label} ${count} ใบ">
      <span class="collector-folder-tab" aria-hidden="true"></span>
      <span class="collector-folder-back" aria-hidden="true"></span>
      <span class="collector-folder-paper paper-one" aria-hidden="true"></span><span class="collector-folder-paper paper-two" aria-hidden="true"></span>
      <span class="collector-folder-glass" aria-hidden="true"></span>
      <span class="collector-folder-front">
        <span class="collector-folder-topline"><span class="collector-folder-symbol">${folder.symbol}</span><span class="collector-folder-index">COLLECTION / ${String(REWARD_FOLDER_GROUPS.indexOf(folder)+1).padStart(2,'0')}</span></span>
        <strong>${folder.label}</strong>
        <span class="collector-folder-range">${folder.range}</span>
        <span class="collector-folder-divider"></span>
        <span class="collector-folder-bottom"><span>${folder.tiers}</span><b>${count} <small>ใบ</small></b></span>
        <span class="collector-folder-desc">${folder.desc}</span>
      </span>
      <span class="collector-folder-open-indicator">${selected?'กำลังแสดง':'แตะเพื่อเปิด'}</span>
    </button>`;
  }).join('');
  host.querySelectorAll('[data-reward-folder]').forEach(button=>button.addEventListener('click',()=>{
    const key=String(button.dataset.rewardFolder||'all');
    activeRewardFolder=activeRewardFolder===key?'all':key;
    activeRewardTier='all';
    renderRewards();
  }));
}
function renderRewardTierFilters(){
  const host=$('collectorSubtierFilters');if(!host)return;
  const folder=REWARD_FOLDER_GROUPS.find(x=>x.key===activeRewardFolder);
  if(!folder){host.hidden=true;host.innerHTML='';return;}
  const tiers=REWARD_RARITY_ORDER.map(key=>REWARD_RARITY_META[key]).filter(t=>t.group===folder.key);
  const cardsInGroup=state.completionCards.filter(card=>rewardFolderGroupForCard(card)===folder.key);
  const tierCounts={};
  state.completionCards.forEach(card=>{const key=rewardRarity(Number(card.chapter_count||0)).key;tierCounts[key]=(tierCounts[key]||0)+1;});
  const tierButton=(key,label,note,count,icon='◈')=>{
    const selected=activeRewardTier===key;
    const classTier=key==='all'?` tone-${folder.tone}`:` tcg-rarity-choice rarity-${key}`;
    const countText=`${count} ใบ`;
    return `<button type="button" class="collector-subtier-chip${classTier}${selected?' selected is-active':''}" data-reward-tier="${key}" aria-pressed="${selected?'true':'false'}"><span class="tcg-rarity-icon">${icon}</span><span class="tcg-rarity-label">${label}</span><small>${note} · ${countText}</small></button>`;
  };
  host.hidden=false;
  host.innerHTML=`<div class="collector-subtier-head"><div><b>${folder.label} <span>· ระดับย่อย</span></b><small>เลือกระดับย่อยตามช่วง Chapter ที่กำหนด แล้วดูการ์ดเฉพาะระดับนั้น</small></div><span class="collector-subtier-total">${tiers.length} ระดับ</span></div><div class="collector-subtier-grid">${tierButton('all',`ทุกระดับ ${folder.label}`,folder.range,cardsInGroup.length,folder.symbol)}${tiers.map(t=>tierButton(t.key,t.label,t.note,tierCounts[t.key]||0,t.icon)).join('')}</div>`;
  host.querySelectorAll('[data-reward-tier]').forEach(button=>button.addEventListener('click',()=>{
    const key=String(button.dataset.rewardTier||'all');
    activeRewardTier=activeRewardTier===key&&key!=='all'?'all':key;
    renderRewards();
  }));
}
function renderRewards(){
  const grid=$('rewardsGrid'),count=$('rewardCount'),recent=$('latestReward'),status=$('rewardFilterStatus'),reset=$('resetRewardFolderFilter');
  if(count)count.textContent=`${state.completionCards.length} ใบ`;
  if(recent)recent.innerHTML=state.completionCards.length?rewardCardHtml(state.completionCards[0],true):'<div class="reward-empty">ยังไม่มีการ์ดรางวัล<br><small>อ่านเรื่องใดเรื่องหนึ่งจนจบ แล้วการ์ดจะถูกสร้างให้ที่นี่โดยอัตโนมัติ</small></div>';
  renderRewardFolders();
  renderRewardTierFilters();
  const groupFiltered=activeRewardFolder==='all'?state.completionCards:state.completionCards.filter(card=>rewardFolderGroupForCard(card)===activeRewardFolder);
  const filtered=activeRewardFolder==='all'||activeRewardTier==='all'?groupFiltered:groupFiltered.filter(card=>rewardRarity(Number(card.chapter_count||0)).key===activeRewardTier);
  const folder=REWARD_FOLDER_GROUPS.find(x=>x.key===activeRewardFolder);
  const tier=REWARD_RARITY_META[activeRewardTier];
  if(status){
    if(tier&&folder)status.textContent=`กำลังแสดง ${tier.label} · ${tier.note} · ${filtered.length} ใบ`;
    else if(folder)status.textContent=`กำลังแสดง ${folder.label} · ${filtered.length} ใบ`;
    else status.textContent=`แสดงการ์ดทั้งหมด · ${filtered.length} ใบ`;
  }
  if(reset){reset.hidden=activeRewardFolder==='all'&&activeRewardTier==='all';reset.onclick=()=>{activeRewardFolder='all';activeRewardTier='all';renderRewards()};}
  if(grid)grid.innerHTML=filtered.length?filtered.map(x=>rewardCardHtml(x)).join(''):(state.completionCards.length?'<div class="reward-empty">ยังไม่มีการ์ดในระดับนี้<br><small>ยังไม่มีการ์ดที่ตรงกับช่วง Chapter ที่เลือก</small></div>':'<div class="reward-empty">ยังไม่มีการ์ดสะสม</div>');
  document.querySelectorAll('[data-reward-id]').forEach(b=>{
    const open=()=>{const c=state.completionCards.find(x=>Number(x.id)===Number(b.dataset.rewardId));if(c)showCompletionReward(c)};
    b.onclick=open;b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}};
  });
}

function reward3DViewerHtml(card){
  const num=String(card.card_number||card.id||0).padStart(3,'0');
  const chapters=Number(card.chapter_count||0),rating=Number(card.rating||0);
  const rarity=rewardRarity(chapters,card.rarity_override);
  // Keep old completion cards compatible: many snapshots were saved before cover_snapshot existed.
  const linkedManga=state.items.find(x=>Number(x.id)===Number(card.manga_id))
    || state.items.find(x=>String(x.title||x.title_original||'').trim().toLowerCase()===String(card.title_snapshot||'').trim().toLowerCase());
  const coverUrl=String(card.cover_snapshot||linkedManga?.cover_url||linkedManga?.cover||'');
  const liveCoverUrl=String(linkedManga?.cover_url||linkedManga?.cover||'');
  const coverMotionUrl=String(linkedManga?.cover_motion_url||'');
  const hasCoverMotion=!!coverMotionUrl&&linkedManga?.cover_motion_status==='completed';
  const coverArtwork=hasCoverMotion
    ? `<video class="tcg-art-img tcg-art-video" src="${esc(coverMotionUrl)}" poster="${esc(coverUrl)}" autoplay muted loop playsinline preload="metadata" aria-label="ปกการ์ดเคลื่อนไหว"></video>`
    : `<img src="${esc(coverUrl)}" data-fallback-src="${esc(liveCoverUrl)}" alt="ปก ${esc(card.title_snapshot||'การ์ดสะสม')}" class="tcg-art-img" loading="eager" decoding="async" referrerpolicy="no-referrer" onerror="if(this.dataset.fallbackSrc&&this.dataset.fallbackSrc!==this.src&&!this.dataset.didFallback){this.dataset.didFallback='1';this.src=this.dataset.fallbackSrc;const bg=this.parentElement.querySelector('.tcg-art-backdrop');if(bg)bg.style.backgroundImage='url('+JSON.stringify(this.dataset.fallbackSrc)+')'}else{this.style.display='none';const f=this.parentElement.querySelector('.tcg-art-fallback');if(f)f.hidden=false}">`;
  const cover=coverUrl
    ? `<span class="tcg-art-backdrop" aria-hidden="true" style="background-image:url(&quot;${esc(coverUrl)}&quot;)"></span>${coverArtwork}<span class="tcg-art-light-sweep" aria-hidden="true"></span>`
    : '<span class="tcg-art-light-sweep" aria-hidden="true"></span>';
  const defaultRarity=rewardRarity(chapters);
  const autoText=`ระบบอัตโนมัติ: ${defaultRarity.label} (${defaultRarity.note})`;
  const currentText=card.rarity_override?`เลือกเอง: ${rarity.label} · ${rarity.note}`:autoText;
  return `<div class="tcg-experience" data-tcg-card-id="${Number(card.id)}">
    <div class="tcg-viewer-labels"><span><i></i> MYMANGA COLLECTOR SERIES</span><span>NO. ${num}</span></div>
    <div class="tcg-stage" data-tcg-stage>
      <div class="tcg-tilt-surface" data-tcg-tilt>
        <div class="tcg-flip-shell" data-tcg-flip-shell>
          <article class="tcg-face tcg-front rarity-${rarity.key}" aria-label="ด้านหน้าการ์ด">
            <div class="tcg-art-layer">${cover}<div class="tcg-art-fallback" ${coverUrl?'hidden':''}>📖<span>MYMANGA</span></div></div>
            <div class="tcg-front-vignette"></div>
            <div class="tcg-front-foil"></div>
            <div class="tcg-front-prism"></div>
            <div class="tcg-front-glitter" aria-hidden="true"></div>
            <div class="tcg-front-sparkles" aria-hidden="true"><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i></div>
            <div class="tcg-front-frame"></div>
            <div class="tcg-front-inner">
              <div class="tcg-front-top"><span class="tcg-rarity-ribbon"><b>${rarity.icon}</b> ${rarity.label}</span><span class="tcg-front-number">#${num}</span></div>
              <div class="tcg-front-bottom">
                <div class="tcg-front-title"><h3>${esc(card.title_snapshot||'เรื่องที่อ่านจบ')}</h3><p>อ่านจบแล้ว · ${esc(rewardDateHtml(card.completed_at))}</p></div>
                <div class="tcg-front-stats"><span><small>CHAPTERS</small><b>${chapters}</b></span><span><small>RATING</small><b>${rating?`★ ${rating.toFixed(1)}`:'—'}</b></span></div>
              </div>
              <div class="tcg-corner tcg-corner-a">✦</div><div class="tcg-corner tcg-corner-b">✧</div><div class="tcg-corner tcg-corner-c">✧</div><div class="tcg-corner tcg-corner-d">✦</div>
            </div>
          </article>
          <article class="tcg-face tcg-back rarity-${rarity.key}" aria-label="ด้านหลังการ์ด">
            <div class="tcg-back-art ${coverUrl?'tcg-back-art-cover':''}" ${coverUrl?`style="--tcg-back-cover:url(&quot;${esc(coverUrl)}&quot;)"`:''} aria-hidden="true"></div>
            <div class="tcg-back-aurora" aria-hidden="true"></div>
            <div class="tcg-back-pattern" aria-hidden="true"></div>
            <div class="tcg-back-foil" aria-hidden="true"></div>
            <div class="tcg-back-glitter" aria-hidden="true"></div>
            <div class="tcg-back-sparkles" aria-hidden="true"><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i></div>
            <div class="tcg-back-frame" aria-hidden="true"></div>
            <div class="tcg-back-content">
              <div class="tcg-back-top"><span>MYMANGA</span><span>COLLECTOR SERIES</span></div>
              <div class="tcg-back-centerpiece">
                <div class="tcg-back-crest" aria-hidden="true">
                  <span class="tcg-back-crest-orbit tcg-back-crest-orbit-a"></span>
                  <span class="tcg-back-crest-orbit tcg-back-crest-orbit-b"></span>
                  <span class="tcg-back-crest-diamond tcg-back-crest-diamond-a"></span>
                  <span class="tcg-back-crest-diamond tcg-back-crest-diamond-b"></span>
                  <span class="tcg-back-crest-core">✦</span>
                </div>
                <strong>MYMANGA</strong>
                <small>THE COLLECTOR'S ARCHIVE</small>
              </div>
              <div class="tcg-back-insignia-line" aria-hidden="true"><span></span><i>✧</i><span></span></div>
              <div class="tcg-back-bottom"><span>OFFICIAL COLLECTION</span><span>CARD No. ${num}</span></div>
            </div>
          </article>
        </div>
      </div>
    </div>
    <div class="tcg-viewer-controls"><button type="button" class="tcg-flip-btn" data-tcg-flip aria-pressed="false">⤾ พลิกดูด้านหลัง</button><span>แตะเพื่อดูการ์ดอีกด้าน • โฮโลแกรมตามระดับ</span></div>
    <section class="tcg-rarity-panel" aria-label="เลือกระดับการ์ด">
      <div class="tcg-rarity-panel-head"><div><b>ระดับความหายาก</b><small>เลือก AUTO หรือกำหนดระดับเอง</small></div><span class="tcg-current-rarity rarity-${rarity.key}">${rarity.icon} ${rarity.label}</span></div>
      <div class="tcg-rarity-options">${rewardRarityOptionsHtml(card)}</div>
      <p class="tcg-rarity-status" data-tcg-rarity-status>${esc(currentText)}</p>
    </section>
    <p class="tcg-save-note">การเลือกระดับจะบันทึกในฐานข้อมูล เพื่อให้ตรงกันเมื่อเปิดเว็บจากอุปกรณ์อื่น</p>
  </div>`;
}
function bindReward3DViewer(card){
  const wrap=$('rewardModalCard');if(!wrap)return;
  const shell=wrap.querySelector('[data-tcg-flip-shell]'),flip=wrap.querySelector('[data-tcg-flip]'),tilt=wrap.querySelector('[data-tcg-tilt]');
  if(flip&&shell)flip.addEventListener('click',()=>{const flipped=shell.classList.toggle('is-flipped');flip.setAttribute('aria-pressed',String(flipped));flip.textContent=flipped?'⤾ ดูด้านหน้า':'⤾ พลิกดูด้านหลัง'});
  if(tilt&&window.matchMedia('(hover:hover) and (pointer:fine)').matches&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    tilt.addEventListener('pointermove',e=>{const r=tilt.getBoundingClientRect();const x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;tilt.style.setProperty('--tcg-tilt-x',`${(-(y-.5)*7).toFixed(2)}deg`);tilt.style.setProperty('--tcg-tilt-y',`${((x-.5)*8).toFixed(2)}deg`);tilt.style.setProperty('--tcg-pointer-x',`${Math.max(0,Math.min(100,x*100)).toFixed(1)}%`);tilt.style.setProperty('--tcg-pointer-y',`${Math.max(0,Math.min(100,y*100)).toFixed(1)}%`)});
    tilt.addEventListener('pointerleave',()=>{tilt.style.setProperty('--tcg-tilt-x','0deg');tilt.style.setProperty('--tcg-tilt-y','0deg');tilt.style.setProperty('--tcg-pointer-x','50%');tilt.style.setProperty('--tcg-pointer-y','44%')});
  }
  wrap.querySelectorAll('[data-set-rarity]').forEach(btn=>btn.addEventListener('click',()=>saveCompletionRarity(Number(card.id),String(btn.dataset.setRarity||'auto'))));
}
async function saveCompletionRarity(id,rarity){
  const wrap=$('rewardModalCard');if(!wrap)return;
  const choices=[...wrap.querySelectorAll('[data-set-rarity]')];choices.forEach(b=>b.disabled=true);
  try{
    const result=await api('update_completion_rarity',{id,rarity_override:rarity});
    const current=state.completionCards.find(x=>Number(x.id)===Number(id));
    if(current)current.rarity_override=result.rarity_override||null;
    const refreshed=current||result.card||null;
    if(refreshed){renderRewards();showCompletionReward(refreshed)}
    showToast(rarity==='auto'?'กลับไปใช้ระดับอัตโนมัติแล้ว':`บันทึกระดับการ์ด ${REWARD_RARITY_META[rarity]?.label||rarity} แล้ว`);
  }catch(err){choices.forEach(b=>b.disabled=false);showToast(`บันทึกระดับการ์ดไม่สำเร็จ: ${err.message||'ลองอีกครั้ง'}`,true)}
}
function showCompletionReward(card){
  const modal=$('rewardModal');if(!modal)return;
  const wrap=$('rewardModalCard');if(wrap){wrap.dataset.cardId=String(card.id);wrap.innerHTML=reward3DViewerHtml(card);bindReward3DViewer(card)}
  const n=$('rewardModalNumber');if(n)n.textContent=`COMPLETION #${String(card.card_number||card.id).padStart(3,'0')} · แตะพลิกดูด้านหลัง`;
  modal.classList.remove('hidden');
}
function closeRewardModal(){if($('rewardModal'))$('rewardModal').classList.add('hidden')}

function renderNewChapterCenter(){
 const grid=$('newChapterGrid');if(!grid)return;
 const mode=$('newChapterFilter')?.value||'all';
 let list=state.items.filter(x=>newCount(x)>0);
 if(mode==='reading')list=list.filter(x=>x.status==='reading');
 if(mode==='favorite')list=list.filter(x=>Number(x.favorite)===1);
 list.sort((a,b)=>newCount(b)-newCount(a)||new Date(b.last_sync_at||0)-new Date(a.last_sync_at||0));
 $('newChapterCount').textContent=String(list.length);
 $('newChapterBadge').textContent=String(list.length);
 $('newChapterBadge').classList.toggle('hidden',!list.length);
 const syncBadge=$('syncNewBadge');if(syncBadge){syncBadge.textContent=String(list.length);syncBadge.classList.toggle('hidden',!list.length)}
 grid.innerHTML=list.length?list.map(x=>{
   const n=newCount(x), err=syncErrorLabel(x), next=x.next_chapter_url||'';
   return `<article class="new-chapter-card">
     <a class="new-chapter-cover" href="manga.html?id=${x.id}">${coverHtml(x)}</a>
     <div class="new-chapter-info">
       <div class="new-chapter-top"><div><h3>${esc(x.title)}</h3><small>ซิงก์เมื่อ ${esc(x.last_sync_at?timeAgo(x.last_sync_at):'ยังไม่เคยซิงก์')}</small></div><span class="new-count-pill">+${n} ตอนใหม่</span></div>
       <div class="new-chapter-range">${esc(newChapterRange(x))}</div>
       ${err?`<div class="new-sync-error">⚠ ${esc(err)}</div>`:''}
       <div class="new-chapter-actions">
         ${next?`<a class="btn red" href="${esc(next)}" target="_blank" rel="noopener">▶ อ่านตอนถัดไป</a>`:`<a class="btn red" href="manga.html?id=${x.id}">▶ อ่านต่อ</a>`}
         <button class="btn ghost" data-sync-one="${x.id}" type="button">↻ ซิงก์</button>
         <button class="btn ghost" data-seen="${x.id}" type="button">✓ ดูแล้ว</button>
       </div>
     </div>
   </article>`;
 }).join(''):'<div class="empty new-chapter-empty">🎉 ตอนนี้ยังไม่มีตอนใหม่</div>';
}
function newChapterRange(x){
 const current=String(x.last_seen_chapter||'0'),latest=String(x.last_chapter||x.latest_chapter||'');const count=newCount(x);if(!latest)return 'มีตอนใหม่';if(count===1)return `ตอน ${latest}`;return `อ่านถึง ${current} → ล่าสุด ${latest} • พบ ${count} ตอนใหม่`;
}
function fmtChapter(n){return Number.isInteger(n)?String(n):String(n).replace(/\.0+$/,'')}
function openNewChapterCenter(){
 const modal=$('newChapterModal');if(!modal)return;
 modal.classList.remove('hidden');modal.setAttribute('aria-hidden','false');
 renderNewChapterCenter();
}
function closeNewChapterCenter(){
 const modal=$('newChapterModal');if(!modal)return;
 modal.classList.add('hidden');modal.setAttribute('aria-hidden','true');
}
async function sleepSync(ms){const step=100;let left=ms;while(left>0&&!syncState.stop){while(syncState.paused&&!syncState.stop)await new Promise(r=>setTimeout(r,200));await new Promise(r=>setTimeout(r,Math.min(step,left)));left-=step}}
function previewReviewReason(x,p){
 const labels=(p.chapters||[]).map(c=>String(c.chapter||''));
 if(p.sync_state!=='complete')return p.sync_state==='partial'?`ต้นทางแจ้ง ${p.expected_chapters} ตอน แต่พบ ${p.chapter_count} ตอน`:'ต้นทางไม่เปิดเผยจำนวนตอนทั้งหมด จึงยืนยันความครบถ้วนไม่ได้';
 if(Number(p.existing_count||0)>=5&&Number(p.existing_matched||0)/Number(p.existing_count)<0.9)return `ตอนที่ดึงมาตรงกับตอนเดิมเพียง ${p.existing_matched} จาก ${p.existing_count} ตอน อาจอ่านเลขตอนผิด`;
 if((p.suspicious_labels||[]).length)return `พบเลขตอนผิดปกติที่ห่างจากตอนล่าสุดมาก (${p.suspicious_labels.slice(0,3).join(', ')}) จะไม่ถูกบันทึก`;
 if(Number(p.unparsed_chapter_count||0)>0)return `มี ${p.unparsed_chapter_count} รายการที่อ่านเลข Chapter ไม่ได้`;
 if(p.duplicate_chapter_labels)return 'พบเลข Chapter ซ้ำบนเว็บต้นทาง';
 if(labels.some(v=>!isValidChapterLabel(v)))return 'พบป้าย Chapter ที่ไม่ใช่เลขมาตรฐาน ควรตรวจสอบก่อนบันทึก';
 const current=chapterParts(x.last_chapter||x.latest_chapter||''),next=chapterParts(p.last_found||'');
 if(current&&next&&current[0]-next[0]>=50)return `เลขล่าสุดเดิม (${x.last_chapter||x.latest_chapter}) ห่างจากที่พบ (${p.last_found}) มากผิดปกติ`;
 if(current&&next&&compareChapterLabels(p.last_found||'',x.last_chapter||x.latest_chapter||'')<0&&current[0]>next[0]+2)return `เลขล่าสุดจากเว็บ (${p.last_found}) ต่ำกว่าที่บันทึกไว้ (${x.last_chapter||x.latest_chapter})`;
 const seen=new Set();for(const v of labels){if(seen.has(v))return `พบเลข Chapter ซ้ำ (${v})`;seen.add(v)}
 return '';
}
function openSyncReview(x,p,reason){
 return new Promise(resolve=>{
  const old=document.getElementById('syncReviewModal');if(old)old.remove();
  const modal=document.createElement('div');modal.className='modal';modal.id='syncReviewModal';
  const stateLabel=p.sync_state==='complete'?'ดึงครบ':p.sync_state==='partial'?'ดึงไม่ครบ':'ตรวจสอบไม่ได้';
  const chapters=(p.chapters||[]).slice(-14).reverse().map(c=>`<div class="sync-review-row"><strong>Chapter ${esc(c.chapter)}</strong><a href="${esc(c.chapter_url||'#')}" target="_blank" rel="noopener">เปิด URL ↗</a></div>`).join('')||'<div class="empty">ไม่มี Chapter อ่านได้</div>';
  modal.innerHTML=`<div class="modal-box sync-review-box"><div class="modal-head"><div><div class="section-kicker">SYNC REVIEW</div><h2>ตรวจสอบก่อนซิงก์</h2><p class="modal-note">${esc(x.title)}</p></div><button type="button" class="close-btn" data-review-skip>×</button></div><div class="review-status review-${esc(p.sync_state)}"><b>${esc(stateLabel)}</b><span>${esc(reason)}</span></div><div class="sync-review-stats"><div><small>จำนวนที่คาด</small><b>${p.expected_chapters>0?esc(p.expected_chapters):'ไม่ระบุ'}</b></div><div><small>ดึงได้</small><b>${esc(p.chapter_count||0)}</b></div><div><small>ขาด</small><b>${p.missing_chapters===null?'ไม่ทราบ':esc(p.missing_chapters)}</b></div></div><p class="modal-note">ตอนที่พบล่าสุด: <b>${esc(p.last_found||'-')}</b> · ล่าสุดในคลัง: <b>${esc(x.last_chapter||x.latest_chapter||'-')}</b></p><div class="sync-review-list">${chapters}</div><div class="review-safe-note">การบันทึกแบบปลอดภัยจะเพิ่มเฉพาะ Chapter ที่ยังไม่มี และไม่ลบหรือเขียนทับ Chapter เดิมจากรอบที่น่าสงสัย</div><div class="modal-actions"><button type="button" class="btn ghost" data-review-skip>ข้ามและเก็บข้อมูลเดิม</button><button type="button" class="red btn" data-review-commit>บันทึกตอนที่พบแบบปลอดภัย</button></div></div>`;
  document.body.appendChild(modal);let done=false;const finish=v=>{if(done)return;done=true;modal.remove();resolve(v)};modal.querySelectorAll('[data-review-skip]').forEach(b=>b.onclick=()=>finish({commit:false}));modal.querySelector('[data-review-commit]').onclick=()=>finish({commit:true,allowPartial:p.sync_state!=='complete'});modal.onclick=e=>{if(e.target===modal)finish({commit:false})};
 });
}
// =====================================================================
// v16.6 — Sync Center 2.0
// =====================================================================
const SYNC_TIMEOUT_MS=100000;
const BASE_DOC_TITLE=document.title;
let syncWakeLock=null;
function syncPrefs(){return {scope:localStorage.getItem('manga_sync_scope')||'all',host:localStorage.getItem('manga_sync_host')||'all',auto:localStorage.getItem('manga_sync_auto')==='1',strict:localStorage.getItem('manga_sync_strict')==='1'}}
function syncAvgMs(){return Math.max(1500,Number(localStorage.getItem('manga_sync_avg_ms')||4500))}
function fmtEta(ms){const m=Math.round(ms/60000);if(m<1)return 'ไม่ถึง 1 นาที';if(m<60)return `~${m} นาที`;return `~${Math.floor(m/60)} ชม. ${m%60} นาที`}
function fmtDur(ms){const s=Math.max(0,Math.round(ms/1000));if(s<60)return `${s} วินาที`;const m=Math.floor(s/60);return m<60?`${m} นาที ${s%60} วินาที`:`${Math.floor(m/60)} ชม. ${m%60} นาที`}
function withTimeout(p,ms){let t;return Promise.race([p,new Promise((_,rej)=>{t=setTimeout(()=>{const e=new ApiError('หมดเวลารอเซิร์ฟเวอร์ (เว็บต้นทางตอบช้า)',0);e.timeout=true;rej(e)},ms)})]).finally(()=>clearTimeout(t))}
async function syncWake(on){try{if(on){if('wakeLock' in navigator&&!syncWakeLock){syncWakeLock=await navigator.wakeLock.request('screen');syncWakeLock.addEventListener('release',()=>{syncWakeLock=null})}}else if(syncWakeLock){await syncWakeLock.release();syncWakeLock=null}}catch{syncWakeLock=null}}
function setSyncTitle(){
  if(syncState.running)document.title=`⟳ ${syncState.results.length}/${syncState.queue.length} · ${BASE_DOC_TITLE}`;
  else if(syncState.results.length&&document.hidden)document.title=`✔ ซิงก์เสร็จ · ${BASE_DOC_TITLE}`;
  else document.title=BASE_DOC_TITLE;
}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&syncState.running)syncWake(true);setSyncTitle()});

function syncActiveHost(){const h=syncPrefs().host;if(h==='all')return 'all';return state.items.some(x=>siteMatch(sourceHost(x.source_url),h))?h:'all'}
function syncScopeItems(scope='all',host='all'){
  let a=state.items.filter(x=>x.completion_status!=='completed'&&String(x.source_url||'').trim()!=='');
  if(scope==='reading')a=a.filter(x=>x.status==='reading');
  else if(scope==='favorite')a=a.filter(x=>Number(x.favorite)===1);
  else if(scope==='issues')a=a.filter(x=>['error','partial','unverifiable','review'].includes(x.sync_status));
  if(host&&host!=='all')a=a.filter(x=>siteMatch(sourceHost(x.source_url),host));
  return a;
}
// เรียงตามความสำคัญ (กำลังอ่าน > โปรด > อื่นๆ) แล้วซิงก์นานที่สุดก่อน จากนั้นสลับเว็บไปมา ไม่ยิงเว็บเดียวกันติดกัน
function orderSyncQueue(list){
  const ts=x=>{const v=x.last_sync_at?new Date(String(x.last_sync_at).replace(' ','T')).getTime():0;return Number.isFinite(v)?v:0};
  const pri=x=>x.status==='reading'?0:(Number(x.favorite)?1:2);
  const sorted=[...list].sort((a,b)=>pri(a)-pri(b)||ts(a)-ts(b)||Number(a.id)-Number(b.id));
  const byHost=new Map();sorted.forEach(x=>{const h=sourceHost(x.source_url)||'-';if(!byHost.has(h))byHost.set(h,[]);byHost.get(h).push(x)});
  const hosts=[...byHost.keys()],out=[];let left=sorted.length;
  while(left>0){for(const h of hosts){const q=byHost.get(h);if(q.length){out.push(q.shift());left--}}}
  return out;
}
function syncQueueFor(scope,host,c){return orderSyncQueue(syncScopeItems(scope,host).filter(x=>syncDue(x,c.cooldownHours)))}

function renderSyncPanel(){
  const c=syncCfg(),p=syncPrefs(),host=syncActiveHost();
  if($('syncCooldown'))$('syncCooldown').value=c.cooldownHours;
  if($('syncDelay'))$('syncDelay').value=(c.delayMs/1000).toFixed(1);
  if($('syncBlockLimit'))$('syncBlockLimit').value=c.blockLimit;
  const hostSel=$('syncHost');
  if(hostSel&&document.activeElement!==hostSel){
    const counts={};state.items.forEach(x=>{if(x.completion_status!=='completed'){const h=sourceHost(x.source_url);if(h)counts[h]=(counts[h]||0)+1}});
    const hosts=Object.keys(counts).sort((a,b)=>counts[b]-counts[a]||a.localeCompare(b));
    const sig=hosts.map(h=>h+':'+counts[h]).join('|')+'#'+host;
    if(hostSel.dataset.sig!==sig){hostSel.innerHTML='<option value="all">ทุกเว็บ</option>'+hosts.map(h=>`<option value="${esc(h)}">${esc(h)} (${counts[h]})</option>`).join('');hostSel.value=host;hostSel.dataset.sig=sig}
  }
  if($('syncScope')&&document.activeElement!==$('syncScope'))$('syncScope').value=p.scope;
  if($('syncAuto'))$('syncAuto').checked=p.auto;
  if($('syncStrict'))$('syncStrict').checked=p.strict;
  const wholeOpen=state.items.filter(x=>x.completion_status!=='completed'&&String(x.source_url||'').trim()!=='');
  const dueQueue=syncQueueFor(p.scope,host,c);
  const openNew=wholeOpen.reduce((sum,x)=>sum+newCount(x),0);
  const issueCount=wholeOpen.filter(smIsIssue).length;
  if($('syncMetricOpen'))$('syncMetricOpen').textContent=String(wholeOpen.length);
  if($('syncMetricDue'))$('syncMetricDue').textContent=String(dueQueue.length);
  if($('syncMetricNew'))$('syncMetricNew').textContent=String(openNew);
  if($('syncMetricIssues'))$('syncMetricIssues').textContent=String(issueCount);
  if($('syncEligibleCount'))$('syncEligibleCount').textContent=dueQueue.length?`${dueQueue.length} เรื่องถึงคิว · ${fmtEta(dueQueue.length*(syncAvgMs()+c.delayMs))}`:'ไม่มีเรื่องถึงคิวซิงก์';
  if($('syncStartBtn')&&!syncState.running)$('syncStartBtn').textContent=dueQueue.length?`🔄 เริ่มซิงก์ ${dueQueue.length} เรื่อง`:'🔄 เริ่มซิงก์';
  renderSyncLastRun();
  renderSyncManage();
}

// =====================================================================
// v17.17.13 — รอบซิงก์ล่าสุด: ระบบจำว่าซิงก์ครบเมื่อไหร่ และเหลือกี่เรื่องที่ยังไม่ได้ซิงก์
// หลักคิด: ดูจาก last_sync_at ของทุกเรื่องในฐานข้อมูล (ใช้ได้ข้ามเครื่อง) แล้วหา "รอบ" = กลุ่มเรื่องที่ซิงก์ต่อเนื่องกัน
// (เว้นช่วงไม่เกิน 60 นาที) รอบล่าสุดที่มีเรื่องจำนวนมากพอ → เรื่องที่ last_sync_at ก่อนรอบนั้น/ไม่เคยซิงก์ = "ยังไม่ได้ซิงก์"
// ไม่เกี่ยวกับ "ข้ามเรื่องที่ซิงก์ภายใน N ชม." (ตัวนั้นใช้ตัดสินแค่ว่า เรื่องไหนถึงคิวซิงก์รอบใหม่)
// =====================================================================
function syncTsOf(x){return x&&x.last_sync_at?new Date(String(x.last_sync_at).replace(' ','T')).getTime():NaN}
function syncRunInfo(){
  const items=syncScopeItems('all','all');
  if(!items.length)return null;
  const stamps=items.map(syncTsOf).filter(Number.isFinite).sort((a,b)=>b-a);
  if(!stamps.length)return {items,run:null,ok:[],issue:[],untouched:items};
  const GAP=60*60000,minSize=Math.max(3,Math.ceil(items.length*0.25));
  const clusters=[];let cur=[stamps[0]];
  for(let i=1;i<stamps.length;i++){if(stamps[i-1]-stamps[i]>GAP){clusters.push(cur);cur=[]}cur.push(stamps[i])}
  clusters.push(cur);
  const pick=clusters.find(c=>c.length>=minSize)||clusters.reduce((a,b)=>b.length>a.length?b:a);
  const start=pick[pick.length-1],end=pick[0];
  const ok=[],issue=[],untouched=[];
  items.forEach(x=>{const t=syncTsOf(x);if(!Number.isFinite(t)||t<start)untouched.push(x);else if(smIsIssue(x))issue.push(x);else ok.push(x)});
  return {items,run:{start,end},ok,issue,untouched};
}
function saveSyncRunSummary(){
  try{
    const k=syncCounts();if(!syncState.results.length)return;
    localStorage.setItem('manga_sync_last_run',JSON.stringify({at:Date.now(),total:syncState.queue.length,done:syncState.results.length,stopped:!!syncState.stop,ok:k.ok,newChapters:k.newChapters,newStories:k.newStories,review:k.review,blocked:k.blocked+k.skipped,failed:k.failed}));
  }catch{}
}
function renderSyncLastRun(){
  const box=$('syncLastRun');if(!box)return;
  const info=syncRunInfo();
  if(!info){box.classList.add('hidden');box.innerHTML='';return}
  const hrs=syncCfg().cooldownHours,fmt=t=>new Date(t).toLocaleString('th-TH',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
  if(!info.run){
    box.classList.remove('hidden');
    box.innerHTML=`<div class="slr-main"><b>🕐 ยังไม่เคยซิงก์</b><span>มี ${info.items.length} เรื่องที่ยังไม่จบและมี URL ต้นทาง</span></div>`;
    return;
  }
  const {run,ok,issue,untouched}=info,running=syncState.running;
  let saved=null;try{saved=JSON.parse(localStorage.getItem('manga_sync_last_run')||'null')}catch{}
  const savedLine=saved&&Math.abs(saved.at-run.end)<2*3600000?`<span class="slr-extra">รอบที่ซิงก์เอง: ตอนใหม่ ${saved.newChapters} ตอน (${saved.newStories} เรื่อง)${saved.stopped?' · หยุดกลางคัน':''}${saved.failed?` · พลาด ${saved.failed}`:''}</span>`:'';
  const stale=info.items.filter(x=>syncDue(x,hrs)).length;
  const allDone=untouched.length===0;
  box.classList.remove('hidden');
  box.classList.toggle('slr-warn',!allDone);
  box.innerHTML=`<div class="slr-main"><b>${allDone?'✅':'🕐'} ซิงก์รอบล่าสุด ${esc(timeAgo(new Date(run.end).toISOString()))}</b><span>${esc(fmt(run.start))} – ${esc(fmt(run.end))}</span></div>`
   +`<div class="slr-stats"><span class="slr-chip ok"><b>${ok.length}</b> ซิงก์แล้ว</span><span class="slr-chip issue"><b>${issue.length}</b> ซิงก์แล้วแต่ต้องตรวจสอบ</span><span class="slr-chip miss${untouched.length?'':' zero'}"><b>${untouched.length}</b> ยังไม่ได้ซิงก์ในรอบนั้น</span></div>`
   +`<div class="slr-note">${allDone?'ทุกเรื่องถูกซิงก์ในรอบล่าสุดแล้ว':`มี ${untouched.length} เรื่องที่ไม่ได้ถูกซิงก์ในรอบล่าสุด (ไม่เคยซิงก์/ถูกข้าม/หยุดก่อน)`} · ครบรอบซิงก์ใหม่ (เกิน ${hrs} ชม.) ${stale} เรื่อง ${savedLine}</div>`
   +(untouched.length&&!running?`<button type="button" class="btn ghost slr-btn" data-sync-remain>🔄 ซิงก์เฉพาะที่ยังไม่ได้ซิงก์ (${untouched.length})</button>`:'');
}
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('[data-sync-remain]');if(!b)return;
  const info=syncRunInfo();if(!info||!info.untouched.length)return;
  startBulkSync(false,{ids:new Set(info.untouched.map(x=>Number(x.id)))});
});

function syncCounts(){
  const r=syncState.results,ok=r.filter(x=>x.ok);
  return {
    ok:ok.length,
    newStories:ok.filter(x=>x.newCount>0).length,
    newChapters:ok.reduce((t,x)=>t+(Number(x.newCount)||0),0),
    review:r.filter(x=>x.review).length+ok.filter(x=>['partial','unverifiable','review'].includes(x.data?.sync_status)).length,
    blocked:r.filter(x=>x.blocked&&!x.skipped).length,
    skipped:r.filter(x=>x.skipped).length,
    failed:r.filter(x=>!x.ok&&!x.review&&!x.blocked&&!x.skipped).length
  };
}
function syncSummaryText(){const k=syncCounts();return `สำเร็จ ${k.ok} เรื่อง · ตอนใหม่ ${k.newChapters} ตอน (${k.newStories} เรื่อง) · ต้องตรวจสอบ ${k.review} · บล็อก/ข้าม ${k.blocked+k.skipped} · พลาด ${k.failed}`}
function syncRowHTML(r){
  let icon='✔',cls='ok',text='ไม่มีตอนใหม่';
  if(r.review){icon='⚠';cls='review';text=`รอตรวจสอบ · ${r.reason||r.message||''}`}
  else if(r.skipped){icon='⏭';cls='skip';text=r.message||'ข้าม'}
  else if(r.blocked){icon='⛔';cls='blocked';text='เว็บบล็อก → ใช้ Browser Import'}
  else if(!r.ok){icon='✖';cls='fail';text=r.timeout?'หมดเวลารอเว็บต้นทาง':String(r.message||'ล้มเหลว').slice(0,140)}
  else if(['partial','unverifiable','review'].includes(r.data?.sync_status)){icon=r.newCount>0?'🆕':'⚠';cls=r.newCount>0?'new':'review';const found=r.preview?.chapter_count,exp=r.preview?.expected_chapters;text=`${r.newCount>0?'+'+r.newCount+' ตอนใหม่':'ไม่มีตอนใหม่'} · ดึงได้ไม่ครบ/ยืนยันจำนวนไม่ได้${found?` (พบ ${found}${exp?'/'+exp:''} ตอน)`:''}`}
  else if(r.newCount>0){icon='🆕';cls='new';text=`+${r.newCount} ตอนใหม่`}
  return `<a class="sync-row sync-row-${cls}" href="manga.html?id=${Number(r.id)}"><i>${icon}</i><b>${esc(r.title)}</b><small>${esc(r.host||'')}</small><span>${esc(text)}</span></a>`;
}
function renderSyncProgress(){
  const box=$('syncProgress');if(!box)return;
  const total=syncState.queue.length,done=syncState.results.length,cur=syncState.queue[syncState.index];
  box.classList.toggle('hidden',!syncState.running&&!done);
  const k=syncCounts();
  if(syncState.running){
    const recent=syncState.durations.slice(-8),avg=recent.length?recent.reduce((a,b)=>a+b,0)/recent.length:syncAvgMs();
    const remaining=syncState.queue.slice(done).filter(x=>!syncState.hosts[sourceHost(x.source_url)||'-']?.tripped).length;
    const pct=total?Math.floor(done/total*100):0;
    $('syncProgressText').textContent=cur?`กำลังซิงก์ ${Math.min(done+1,total)}/${total} (${pct}%) — ${cur.title}`:'กำลังเตรียมซิงก์...';
    const sb=$('syncStartBtn');if(sb){sb.textContent=`⟳ กำลังซิงก์ ${Math.min(done+1,total)}/${total}`;sb.disabled=true}
    if($('syncNow'))$('syncNow').textContent=(cur?`${sourceHost(cur.source_url)||''}`:'')+(remaining>0?` · เหลือ ${fmtEta(remaining*(avg+syncCfg().delayMs))}`:'')+(syncWakeLock?' · เปิดหน้าจอค้างไว้':'');
    $('syncProgressBar').style.width=total?`${Math.min(100,(done/total)*100)}%`:'0%';
    $('syncPauseBtn').textContent=syncState.paused?'▶ ทำต่อ':'⏸ หยุดชั่วคราว';
    $('syncStopBtn').disabled=false;
  }else if(done){
    if($('syncStartBtn'))$('syncStartBtn').disabled=false;
    $('syncProgressText').textContent=syncSummaryText();
    if($('syncNow'))$('syncNow').textContent=syncState.startedAt?`ใช้เวลา ${fmtDur(Date.now()-syncState.startedAt)}`:'';
    $('syncProgressBar').style.width='100%';
    $('syncPauseBtn').textContent='ปิดผลลัพธ์';
    $('syncStopBtn').disabled=true;
  }
  if($('syncStats'))$('syncStats').innerHTML=done?[['✔',k.ok,'สำเร็จ','ok'],['🆕',k.newChapters,'ตอนใหม่','new'],['⚠',k.review,'ตรวจสอบ','review'],['⛔',k.blocked+k.skipped,'บล็อก/ข้าม','blocked'],['✖',k.failed,'พลาด','fail']].map(([i,n,l,c])=>`<span class="sync-chip sync-chip-${c}${n?'':' zero'}"><i>${i}</i><b>${n}</b>${l}</span>`).join(''):'';
  if($('syncRetryBtn'))$('syncRetryBtn').classList.toggle('hidden',!(!syncState.running&&syncState.results.some(r=>!r.ok&&!r.review&&(r.skipped||!r.blocked))));
  if($('syncReviewBtn')){const n=syncState.reviews.length;$('syncReviewBtn').classList.toggle('hidden',syncState.running||!n);$('syncReviewBtn').textContent=`🔍 ตรวจสอบ ${n} เรื่อง`}
  if($('syncIssuesBtn'))$('syncIssuesBtn').classList.toggle('hidden',syncState.running||!syncState.results.some(r=>r.blocked));
  const wrap=$('syncResultsWrap');if(wrap){wrap.classList.toggle('hidden',!done);const list=$('syncResults');if(list)list.innerHTML=[...syncState.results].reverse().slice(0,120).map(syncRowHTML).join('')}
  setSyncTitle();
}

function syncFail(x,e,preview,t0){
  const msg=String(e?.message||'');
  const blocked=!!e?.data?.browser_required||(e?.status===409&&!e?.data?.needs_review)||/403|429|บล็อก|ปฏิเสธ/i.test(msg);
  recordSyncHistory({id:Number(x.id),title:x.title,status:blocked?'blocked':(e?.timeout?'timeout':'error'),message:msg,found:preview?.chapter_count,expected:preview?.expected_chapters});
  return {ok:false,id:Number(x.id),title:x.title,host:sourceHost(x.source_url),message:msg,blocked,timeout:!!e?.timeout,retryable:!!e?.data?.retryable,ms:Date.now()-t0};
}
async function syncCommit(payload){
  for(let attempt=0;attempt<2;attempt++){
    try{return await withTimeout(api('sync_manga',payload),SYNC_TIMEOUT_MS)}
    catch(e){if((e.data?.retryable||e.status===503)&&attempt===0){await new Promise(r=>setTimeout(r,1200));continue}throw e}
  }
}
// opts.bulk: ไม่เปิด Modal ระหว่างคิว — เรื่องที่มีจุดน่าสงสัยจะถูกเก็บไว้ตรวจสอบตอนท้าย
async function syncOneForQueue(x,force=false,opts={}){
  const t0=Date.now(),host=sourceHost(x.source_url);
  let preview=null,lastErr=null;
  for(let attempt=0;attempt<2;attempt++){
    try{preview=await withTimeout(api('sync_preview',{id:Number(x.id),force:!!force}),SYNC_TIMEOUT_MS);lastErr=null;break}
    catch(e){lastErr=e;const transient=!!e.data?.retryable||e.status===503||(e.status===0&&!e.timeout);if(transient&&attempt===0&&!syncState.stop){await new Promise(r=>setTimeout(r,1200));continue}break}
  }
  if(lastErr)return syncFail(x,lastErr,null,t0);
  const prog=opts.prog;
  prog?.step(64,'ตรวจรายการ Chapter','ตรวจความครบถ้วน',`พบ ${preview.chapter_count??0} ตอน${Number(preview.expected_chapters)>0?` จาก ${preview.expected_chapters}`:''}`);
  try{
    const incomplete=preview.sync_state!=='complete';
    const strict=!opts.bulk||syncPrefs().strict;
    // โหมดคิว (ไม่เข้มงวด): ดึงไม่ครบ/ยืนยันจำนวนไม่ได้ → บันทึกแบบเพิ่มอย่างเดียว (ไม่ลบของเดิม) ถามเฉพาะเมื่อพบความผิดปกติของเลขตอน
    const structural=previewReviewReason(x,{...preview,sync_state:'complete'});
    const reason=strict?previewReviewReason(x,preview):structural;
    let allowPartial=incomplete,preserve=!!reason||incomplete;
    // v17.17.13: ซิงก์ทีละเรื่อง (ไม่ใช่คิวใหญ่) แสดงหน้าตรวจสอบก่อนบันทึกทุกครั้ง แม้ไม่พบความผิดปกติ
    const manualOk=!reason&&!opts.bulk;
    if(reason||manualOk){
      if(opts.bulk){
        recordSyncHistory({id:Number(x.id),title:x.title,status:'review',message:reason,found:preview.chapter_count,expected:preview.expected_chapters});
        return {ok:false,review:true,id:Number(x.id),title:x.title,host,reason,message:reason,preview,ms:Date.now()-t0};
      }
      prog?.hide();
      const choice=await openSyncReview(x,preview,reason||'ตรวจแล้วไม่พบความผิดปกติ — ตรวจรายการก่อนบันทึก');
      if(!choice.commit){recordSyncHistory({id:Number(x.id),title:x.title,status:'skipped',message:'ผู้ใช้ข้าม Sync Review',found:preview.chapter_count,expected:preview.expected_chapters});return {ok:false,skipped:true,id:Number(x.id),title:x.title,host,message:'ผู้ใช้ข้าม Sync Review'}}
      allowPartial=!!choice.allowPartial;preserve=!manualOk;
    }
    prog?.step(74,'กำลังบันทึก Chapter','บันทึกตอนใหม่',`พบ ${preview.chapter_count??0} ตอน`);prog?.creep(96);
    const d=await syncCommit({id:Number(x.id),force:!!force,allow_partial:allowPartial,preserve_existing:preserve,use_preview:true});
    recordSyncHistory({id:Number(x.id),title:x.title,status:d.sync_status||'success',message:d.sync_error||d.sync_state||preview.sync_state,found:preview.chapter_count,expected:preview.expected_chapters,last:d.last_chapter||preview.last_found});
    return {ok:true,id:Number(x.id),title:x.title,host,newCount:Number(d.new_chapter_count||d.new_chapters||0),data:d,preview,ms:Date.now()-t0};
  }catch(e){return syncFail(x,e,preview,t0)}
}

async function runSyncReviews(){
  const list=[...syncState.reviews];if(!list.length)return;
  let saved=0,skipped=0;
  for(const it of list){
    const x=state.items.find(v=>Number(v.id)===Number(it.id));
    if(!x){syncState.reviews=syncState.reviews.filter(v=>v.id!==it.id);continue}
    const choice=await openSyncReview(x,it.preview,it.reason);
    syncState.reviews=syncState.reviews.filter(v=>v.id!==it.id);
    const row=syncState.results.find(v=>v.id===it.id&&v.review);
    if(!choice.commit){skipped++;if(row){row.review=false;row.skipped=true;row.message='ผู้ใช้ข้ามตอนตรวจสอบ'}continue}
    try{
      const d=await syncCommit({id:Number(it.id),force:true,allow_partial:it.preview.sync_state!=='complete',preserve_existing:true,use_preview:true});
      saved++;if(row){row.review=false;row.ok=true;row.data=d;row.newCount=Number(d.new_chapter_count||d.new_chapters||0)}
      recordSyncHistory({id:Number(it.id),title:x.title,status:d.sync_status||'review',message:'บันทึกหลังตรวจสอบ',found:it.preview.chapter_count,expected:it.preview.expected_chapters,last:d.last_chapter});
    }catch(e){showToast(`${x.title}: ${e.message}`,true);if(row){row.review=false;row.message=e.message}}
  }
  try{await refreshAll()}catch{}
  renderSyncProgress();showToast(`ตรวจสอบเสร็จ • บันทึก ${saved} เรื่อง · ข้าม ${skipped} เรื่อง`);
}

async function startBulkSync(retryOnly=false,opts={}){
  if(syncState.running)return;
  const c=syncCfg(),p=syncPrefs();
  let queue;
  if(retryOnly){
    const ids=new Set(syncState.results.filter(r=>!r.ok&&!r.review&&(r.skipped||!r.blocked)).map(r=>Number(r.id)));
    queue=orderSyncQueue(state.items.filter(x=>ids.has(Number(x.id))));
  }else if(opts.ids){queue=orderSyncQueue(state.items.filter(x=>opts.ids.has(Number(x.id))&&String(x.source_url||'').trim()!==''))}
  else queue=syncQueueFor(opts.scope||p.scope,opts.host||syncActiveHost(),c);
  if(opts.limit)queue=queue.slice(0,opts.limit);
  if(!queue.length){if(!opts.auto)showToast(retryOnly?'ไม่มีเรื่องที่พลาดให้ลองใหม่':'ยังไม่มีเรื่องที่ถึงเวลาซิงก์');return}
  Object.assign(syncState,{running:true,paused:false,stop:false,index:0,queue,results:[],reviews:[],blockedStreak:0,serverErrStreak:0,haltMessage:'',hosts:{},durations:[],startedAt:Date.now()});
  syncWake(true);renderSyncProgress();
  if(!opts.auto){try{$('syncProgress')?.scrollIntoView({behavior:'smooth',block:'center'})}catch{}}
  if(opts.auto)showToast(`ซิงก์อัตโนมัติ ${queue.length} เรื่อง`);
  for(let i=0;i<queue.length;i++){
    syncState.index=i;renderSyncProgress();
    while(syncState.paused&&!syncState.stop){await new Promise(r=>setTimeout(r,250))}
    if(syncState.stop)break;
    const x=queue[i],host=sourceHost(x.source_url)||'-';
    const hs=syncState.hosts[host]||(syncState.hosts[host]={bad:0,tripped:false});
    // เว็บที่บล็อก/หมดเวลาติดกันหลายเรื่อง: ข้ามเรื่องที่เหลือของเว็บนั้น แต่ซิงก์เว็บอื่นต่อ
    if(hs.tripped){syncState.results.push({ok:false,skipped:true,blocked:true,id:Number(x.id),title:x.title,host,message:`ข้าม: ${host} บล็อก/ไม่ตอบติดกัน ${c.blockLimit} เรื่อง`});renderSyncProgress();continue}
    const r=await syncOneForQueue(x,retryOnly,{bulk:true});
    syncState.results.push(r);
    if(r.review)syncState.reviews.push({id:r.id,preview:r.preview,reason:r.reason});
    if(r.ms)syncState.durations.push(r.ms);
    if(r.blocked||r.timeout){hs.bad++;if(hs.bad>=c.blockLimit)hs.tripped=true}else if(r.ok||r.review)hs.bad=0;
    if(!r.ok&&!r.blocked&&!r.review&&!r.timeout&&/SQLSTATE|Unknown column|Column not found|Call to undefined|Fatal|Internal Server/i.test(r.message||''))syncState.serverErrStreak=(syncState.serverErrStreak||0)+1;else syncState.serverErrStreak=0;
    if(syncState.serverErrStreak>=3){syncState.haltMessage=r.message||'ไม่ทราบสาเหตุ';break}
    renderSyncProgress();
    if((i+1)%4===0){try{await refreshAll()}catch{}}
    const nextHost=queue[i+1]?(sourceHost(queue[i+1].source_url)||'-'):'';
    if(i<queue.length-1&&!(syncState.hosts[nextHost]?.tripped))await sleepSync(Math.round(c.delayMs*(0.75+Math.random()*0.5)));
  }
  syncState.running=false;syncWake(false);
  saveSyncRunSummary();
  if(syncState.durations.length)localStorage.setItem('manga_sync_avg_ms',String(Math.round(syncState.durations.reduce((a,b)=>a+b,0)/syncState.durations.length)));
  try{await refreshAll()}catch{}
  renderSyncProgress();
  if(syncState.haltMessage){showToast(`เซิร์ฟเวอร์ผิดพลาดซ้ำ ระบบหยุดซิงก์: ${syncState.haltMessage}`,true);syncState.haltMessage='';return}
  if(syncState.stop){showToast(`หยุดการซิงก์แล้ว • ${syncSummaryText()}`);return}
  if(syncState.results.length){if(opts.auto)showToast(syncSummaryText(),syncState.results.some(r=>!r.ok&&!r.review&&!r.skipped));else openSyncDone()}
}
// v17.17.15 — หน้าต่างสรุปเมื่อซิงก์เสร็จ (แทนข้อความ toast แถบสีแดงเดิม)
function openSyncDone(){
  const old=document.getElementById('syncDoneModal');if(old)old.remove();
  const k=syncCounts(),r=syncState.results,total=syncState.queue.length;
  const withNew=r.filter(x=>x.ok&&x.newCount>0).sort((a,b)=>b.newCount-a.newCount);
  const reasons={};r.filter(x=>x.review).forEach(x=>{const t=String(x.reason||x.message||'ต้องตรวจสอบ').replace(/\(.*?\)/g,'').trim();reasons[t]=(reasons[t]||0)+1});
  const retryable=r.filter(x=>!x.ok&&!x.review&&(x.skipped||!x.blocked)).length;
  const failedRows=r.filter(x=>!x.ok&&!x.review).slice(0,6);
  const warn=k.failed>0||k.review>0||k.blocked+k.skipped>0,stopped=!!syncState.stop;
  const title=stopped?'⏹ หยุดซิงก์แล้ว':warn?'⚠ ซิงก์เสร็จ — มีบางเรื่องต้องดู':'✅ ซิงก์เสร็จเรียบร้อย';
  const sub=`${stopped?`ซิงก์ไป ${r.length} จาก ${total} เรื่อง`:`ซิงก์ครบ ${r.length} เรื่อง`} · ใช้เวลา ${fmtDur(Date.now()-syncState.startedAt)}`;
  const stat=(n,l,c)=>`<div class="sd-stat sd-${c}${n?'':' zero'}"><b>${n}</b><span>${l}</span></div>`;
  const newList=withNew.length?`<div class="sd-block"><h3>🆕 เรื่องที่มีตอนใหม่ (${withNew.length})</h3>${withNew.slice(0,10).map(x=>`<a class="sd-line" href="manga.html?id=${Number(x.id)}"><b>${esc(x.title)}</b><span>+${x.newCount} ตอน</span></a>`).join('')}${withNew.length>10?`<small>และอีก ${withNew.length-10} เรื่อง — ดูทั้งหมดที่ปุ่ม “ตอนใหม่”</small>`:''}</div>`:'<div class="sd-block sd-empty">ไม่พบตอนใหม่ในรอบนี้</div>';
  const revList=k.review?`<div class="sd-block"><h3>🔍 รอตรวจสอบ (${k.review})</h3>${Object.entries(reasons).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([t,n])=>`<div class="sd-line"><b>${esc(t)}</b><span>${n} เรื่อง</span></div>`).join('')}<small>กด “ตรวจสอบ” เพื่อดูทีละเรื่องแล้วเลือกบันทึกหรือข้าม</small></div>`:'';
  const failList=failedRows.length?`<div class="sd-block"><h3>✖ ซิงก์ไม่สำเร็จ (${k.failed+k.blocked+k.skipped})</h3>${failedRows.map(x=>`<div class="sd-line"><b>${esc(x.title)}</b><span>${esc(x.blocked?'เว็บบล็อก':x.timeout?'หมดเวลา':String(x.message||'ล้มเหลว').slice(0,50))}</span></div>`).join('')}</div>`:'';
  const modal=document.createElement('div');modal.className='modal';modal.id='syncDoneModal';
  modal.innerHTML=`<div class="modal-box sync-done-box ${warn?'sd-warn':'sd-ok'}"><div class="modal-head"><div><div class="section-kicker">SYNC COMPLETE</div><h2>${title}</h2><p class="modal-note">${esc(sub)}</p></div><button type="button" class="close-btn" data-sd-close>×</button></div>`
   +`<div class="sd-stats">${stat(k.ok,'สำเร็จ','ok')}${stat(k.newChapters,'ตอนใหม่','new')}${stat(k.review,'ต้องตรวจสอบ','review')}${stat(k.blocked+k.skipped,'บล็อก/ข้าม','blocked')}${stat(k.failed,'พลาด','fail')}</div>`
   +newList+revList+failList
   +`<div class="modal-actions sd-actions">${k.review?`<button type="button" class="red btn" data-sd-review>🔍 ตรวจสอบ ${k.review} เรื่อง</button>`:''}${withNew.length?`<button type="button" class="btn ghost" data-sd-new>🆕 ดูตอนใหม่</button>`:''}${retryable?`<button type="button" class="btn ghost" data-sd-retry>↻ ลองใหม่เฉพาะที่พลาด (${retryable})</button>`:''}<button type="button" class="btn ghost" data-sd-close>ปิด</button></div></div>`;
  document.body.appendChild(modal);
  const close=()=>modal.remove();
  modal.onclick=e=>{if(e.target===modal)close()};
  modal.querySelectorAll('[data-sd-close]').forEach(b=>b.onclick=close);
  modal.querySelector('[data-sd-review]')?.addEventListener('click',()=>{close();runSyncReviews()});
  modal.querySelector('[data-sd-new]')?.addEventListener('click',()=>{close();$('openNewChapterBtn')?.click()});
  modal.querySelector('[data-sd-retry]')?.addEventListener('click',()=>{close();startBulkSync(true)});
  try{if(document.hidden&&'Notification' in window&&Notification.permission==='granted')new Notification('MyManga — ซิงก์เสร็จแล้ว',{body:`สำเร็จ ${k.ok} · ตอนใหม่ ${k.newChapters} ตอน · ต้องตรวจสอบ ${k.review} · พลาด ${k.failed}`})}catch{}
}
function maybeAutoSync(){
  try{
    const p=syncPrefs();
    if(!p.auto||syncState.running||!getStoredToken()||document.hidden)return;
    if(document.querySelector('.modal:not(.hidden)'))return;
    const last=Number(localStorage.getItem('manga_sync_auto_last')||0);if(Date.now()-last<30*60*1000)return;
    if(!syncQueueFor(p.scope,syncActiveHost(),syncCfg()).length)return;
    localStorage.setItem('manga_sync_auto_last',String(Date.now()));
    startBulkSync(false,{auto:true,limit:15});
  }catch{}
}
async function syncOne(id){
 const x=state.items.find(v=>Number(v.id)===Number(id));if(!x)return;
 const prog=mmtSyncProgress('กำลังเริ่มซิงก์',x.title);
 prog.step(6,'กำลังเริ่มซิงก์','เตรียมซิงก์');
 prog.creep(58,'กำลังอ่านเว็บต้นทาง','อ่านรายการ Chapter','กำลังตรวจรายการ Chapter จากเว็บต้นทาง');
 let r;try{r=await syncOneForQueue(x,true,{prog})}catch(e){r={ok:false,message:e?.message||'ซิงก์ไม่สำเร็จ'}}
 try{await refreshAll()}catch{}
 if(r.ok){const st=mmtSyncResultState(r.data?.sync_status);prog.done(st,st==='partial'?'ซิงก์แล้ว แต่ควรตรวจสอบ':'ซิงก์สำเร็จ',`พบ ${r.preview?.chapter_count??'-'} ตอน · ${r.newCount?`เพิ่ม ${r.newCount} ตอนใหม่`:'ไม่มีตอนใหม่'}`)}
 else if(r.skipped)prog.hide();
 else prog.done('error',r.blocked?'เว็บต้นทางบล็อกการดึงข้อมูล':'ซิงก์ไม่สำเร็จ',String(r.message||'').slice(0,160),{canBrowser:!!r.blocked,id:x.id,url:x.source_url});
 const bb=$('backgroundImportBrowser');if(bb){bb.dataset.id=String(Number(x.id));bb.dataset.url=String(x.source_url||'')}
}
async function markNewSeen(id){try{await api('mark_new_seen',{id:Number(id)});await refreshAll();showToast('ทำเครื่องหมายว่าดูแล้ว');}catch(e){showToast(e.message,true)}}
async function markAllNewSeen(){try{await api('mark_all_new_seen');await refreshAll();showToast('ล้างป้ายตอนใหม่ทั้งหมดแล้ว')}catch(e){showToast(e.message,true)}}
function render(){
 const a=filteredItems(),reading=[...state.items].filter(x=>x.status==='reading'&&x.completion_status!=='completed').sort((x,y)=>new Date(y.last_read_at||0)-new Date(x.last_read_at||0)),fav=[...state.items].filter(x=>Number(x.favorite)).sort((x,y)=>new Date(y.last_read_at||y.updated_at||0)-new Date(x.last_read_at||x.updated_at||0));
 $('continueCount').textContent=`${reading.length} เรื่อง`;$('continueGrid').innerHTML=reading.length?reading.slice(0,16).map(x=>card(x,true)).join(''):'<div class="empty">ยังไม่มีเรื่องที่กำลังอ่าน</div>';
 renderCompleted();renderNewChapterCenter();renderSyncPanel();
 $('favoriteGrid').innerHTML=fav.length?fav.slice(0,16).map(x=>card(x,true)).join(''):'<div class="empty">ยังไม่มีรายการโปรด — กด ★ บนการ์ดเพื่อเพิ่ม</div>';
 $('libraryGrid').className=`grid library-grid ${state.libraryListMode?'list-mode':''}`;$('libraryGrid').innerHTML=a.length?a.map(x=>card(x)).join(''):'<div class="empty">ไม่พบเรื่องตามเงื่อนไข</div>';renderOneshotShelf();
 $('smartSummary').textContent=`กำลังแสดง ${a.length} จาก ${state.items.length} เรื่อง`+(activeSite()?` · เว็บต้นทาง: ${activeSite()}`:'');renderActiveFilterChips();renderBulkToolbar();syncSourceTools(a);$('statAll').textContent=state.items.length;$('statReading').textContent=state.items.filter(x=>x.status==='reading').length;$('statFav').textContent=state.items.filter(x=>Number(x.favorite)).length;$('statChapters').textContent=state.items.reduce((n,x)=>n+Number(x.chapter_count||0),0);if($('statCompleted'))$('statCompleted').textContent=state.items.filter(x=>x.status==='completed').length;if($('statNewChapters'))$('statNewChapters').textContent=state.items.reduce((n,x)=>n+newCount(x),0);
 bindCardActions();renderManagersBindings();
}
function completedItems(){
 const rewardByManga=new Map(state.completionCards.map(c=>[Number(c.manga_id),c]));
 return state.items
  .filter(x=>x.status==='completed'||rewardByManga.has(Number(x.id)))
  .sort((a,b)=>{
    const ra=rewardByManga.get(Number(a.id)),rb=rewardByManga.get(Number(b.id));
    const da=ra?.completed_at||a.updated_at||a.last_read_at||0;
    const db=rb?.completed_at||b.updated_at||b.last_read_at||0;
    return new Date(db).getTime()-new Date(da).getTime();
  });
}
function renderCompleted(){
 const list=completedItems(),grid=$('completedGrid'),count=$('completedCount');
 if(count)count.textContent=`${list.length} เรื่อง`;
 if(!grid)return;
 grid.innerHTML=list.length?list.slice(0,24).map(x=>{
   const reward=state.completionCards.find(c=>Number(c.manga_id)===Number(x.id));
   return card(reward?{...x,status:'completed'}:x,true);
 }).join(''):'<div class="empty">ยังไม่มีเรื่องที่อ่านจบ</div>';
}
function renderRecent(){$('recentGrid').innerHTML=state.recent.length?state.recent.slice(0,16).map(x=>card({...x,manga_id:undefined,id:x.manga_id,title:x.title,cover_url:x.cover_url,type_id:x.type_id,current_chapter:x.chapter,last_chapter:x.chapter,last_read_at:x.read_at,genre_names:''},true)).join(''):'<div class="empty">ยังไม่มีประวัติการอ่าน</div>'}
function renderTimeline(){$('timelineBody').innerHTML=state.timeline.length?state.timeline.map(x=>`<div class="timeline-item"><div class="timeline-dot">●</div><div class="timeline-content"><strong>${esc(x.title)}</strong><span>Chapter ${esc(x.chapter)}</span><small>${timeAgo(x.read_at)} • ${esc(x.detection_method||'extension')}</small></div><a class="timeline-open" href="manga.html?id=${x.manga_id}">ดูเรื่อง</a></div>`).join(''):'<div class="empty">ยังไม่มีประวัติการอ่าน</div>'}
function bindCardActions(){
 if(window.__mymangaCardActionsBound)return;
 window.__mymangaCardActionsBound=true;
 document.addEventListener('click',e=>{
  const b=e.target.closest('[data-edit],[data-delete],[data-delete-cancel],[data-fav],[data-sync-one],[data-seen],[data-animate-cover]');
  if(!b)return;
  e.preventDefault();
  e.stopPropagation();
  if(b.dataset.animateCover!==undefined){animateCover(Number(b.dataset.animateCover));return}
  if(b.dataset.edit!==undefined){openEdit(Number(b.dataset.edit));return}
  if(b.dataset.deleteCancel!==undefined){resetDeleteButton(b.closest('.card-actions')?.querySelector('[data-delete]'));return}
  if(b.dataset.delete!==undefined){handleCardDeleteClick(b);return}
  if(b.dataset.fav!==undefined){toggleFavorite(Number(b.dataset.fav));return}
  if(b.dataset.syncOne!==undefined){syncOne(Number(b.dataset.syncOne));return}
  if(b.dataset.seen!==undefined){markNewSeen(Number(b.dataset.seen));return}
 });
}
const DEL_ICO={trash:`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,check:`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,x:`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`};
const COVER_MOTION_DEFAULT_PROMPT='Animate this anime/manga cover subtly: gentle hair and clothing movement, soft atmospheric particles and delicate light shimmer. Preserve the same characters, composition, colors, and all visible lettering/logos. Keep the camera nearly still, no cuts, no new characters, no text changes, no morphing. Vertical cover art.';
const coverMotionWait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function animateCover(id){
 const item=state.items.find(x=>Number(x.id)===Number(id));
 if(!item){showToast('ไม่พบเรื่องในคลัง',true);return}
 if(!item.cover_url){showToast('เรื่องนี้ยังไม่มีรูปปก กรุณาเพิ่มหรือซิงก์ปกก่อน',true);return}
 const pending=['queued','IN_QUEUE','IN_PROGRESS'].includes(String(item.cover_motion_status||''));
 if(!pending){
   if(item.cover_motion_url&&!confirm(`เรื่อง “${item.title}” มีปกเคลื่อนไหวแล้ว\nต้องการสร้างใหม่หรือไม่? การสร้างใหม่อาจใช้เครดิต AI เพิ่ม`))return;
   const promptText=window.prompt('อธิบายส่วนที่อยากให้ขยับ (เว้นว่างเพื่อใช้ค่ามาตรฐาน)',COVER_MOTION_DEFAULT_PROMPT);
   if(promptText===null)return;
   if(!confirm('เริ่มสร้างวิดีโอปกด้วย AI? บริการภายนอกอาจคิดค่าใช้จ่ายตามบัญชีของคุณ'))return;
   try{
    const started=await api('animate_cover_submit',{id:Number(id),prompt:promptText.trim()||COVER_MOTION_DEFAULT_PROMPT,force:!!item.cover_motion_url});
    item.cover_motion_status=started.status||'queued';
    render();
    if(started.status==='completed'&&started.cover_motion_url){item.cover_motion_url=started.cover_motion_url;item.cover_motion_status='completed';render();showToast('เรื่องนี้มีปกเคลื่อนไหวแล้ว');return}
    showToast('ส่งงานสร้างปกแล้ว กำลังรอ AI...');
   }catch(err){handleCoverAiError(err);return}
 }
 // Poll an already submitted job; the server stores the provider request ID, so closing the page is safe.
 const statusButton=document.querySelector(`[data-animate-cover="${Number(id)}"]`);if(statusButton){statusButton.disabled=true;statusButton.textContent='⏳ กำลังสร้าง'}
 for(let attempt=0;attempt<45;attempt++){
  try{
   const result=await api('animate_cover_status',{id:Number(id)});
   item.cover_motion_status=result.status||item.cover_motion_status;
   if(result.status==='completed'&&result.cover_motion_url){item.cover_motion_url=result.cover_motion_url;item.cover_motion_status='completed';render();showToast('สร้างปกเคลื่อนไหวสำเร็จ 🎬');return}
   if(result.status==='failed'){render();if(result.error_code==='FAL_BALANCE_EXHAUSTED')handleCoverAiError(result);else showToast(result.message||'AI สร้างปกไม่สำเร็จ คุณสามารถลองใหม่ได้',true,6500);return}
   const b=document.querySelector(`[data-animate-cover="${Number(id)}"]`);if(b){b.disabled=true;b.textContent='⏳ กำลังสร้าง'}
  }catch(err){const retryButton=document.querySelector(`[data-animate-cover="${Number(id)}"]`);if(retryButton){retryButton.disabled=false;retryButton.textContent='⏳ ตรวจสถานะ'}handleCoverAiError(err);return}
  await coverMotionWait(7000);
 }
 const retryButton=document.querySelector(`[data-animate-cover="${Number(id)}"]`);if(retryButton){retryButton.disabled=false;retryButton.textContent='⏳ ตรวจสถานะ'}
 showToast('AI ยังทำงานอยู่ ปกจะพร้อมเมื่อเสร็จ คุณสามารถกดตรวจ/สร้างปกอีกครั้งภายหลังได้');
}
let deleteArmTimer=null;
function resetDeleteButton(button){
 if(!button)return;
 clearTimeout(deleteArmTimer);
 const actions=button.closest('.card-actions');
 button.classList.remove('delete-armed');button.innerHTML=`${DEL_ICO.trash}<span>ลบ</span>`;button.setAttribute('aria-label','ลบเรื่อง');
 actions?.classList.remove('delete-open');
 actions?.querySelector('[data-delete-cancel]')?.remove();
}
function handleCardDeleteClick(button){
 const id=Number(button.dataset.delete), actions=button.closest('.card-actions');
 if(!id||!actions)return;
 if(button.classList.contains('delete-armed')){clearTimeout(deleteArmTimer);deleteManga(id,true);return}
 document.querySelectorAll('[data-delete].delete-armed').forEach(resetDeleteButton);
 button.classList.add('delete-armed');button.innerHTML=`${DEL_ICO.check}<span>ยืนยันลบ</span>`;button.setAttribute('aria-label','ยืนยันการลบเรื่อง');
 actions.classList.add('delete-open');
 const cancel=document.createElement('button');cancel.type='button';cancel.className='mini-action delete-cancel';cancel.dataset.deleteCancel='';cancel.innerHTML=DEL_ICO.x;cancel.setAttribute('aria-label','ยกเลิกการลบ');
 button.after(cancel);
 clearTimeout(deleteArmTimer);deleteArmTimer=setTimeout(()=>resetDeleteButton(button),5000);
}
function openEdit(id){const x=state.items.find(v=>Number(v.id)===id);if(x)openModal(x)}
async function deleteManga(id,confirmed=false){const x=state.items.find(v=>Number(v.id)===id);if(!x||(!confirmed&&!confirm(`ลบเรื่อง “${x.title}” พร้อม Chapter และประวัติการอ่านหรือไม่?`)))return;try{await api('delete_manga',{id});showToast('ลบเรื่องแล้ว');await refreshAll()}catch(e){showToast(e.message,true)}}
async function toggleFavorite(id){try{await api('toggle_favorite',{id});showToast('อัปเดตรายการโปรดแล้ว');await refreshAll()}catch(e){showToast(e.message,true)}}
let editingId=0;
let ratingSvgSequence=0;
function ratingSvgStarsHtml(value,{size=20,prefix='rating'}={}){
 const rating=Math.max(0,Math.min(5,Math.round((Number(value)||0)*2)/2));
 return `<span class="rating-svg-stars" style="--rating-star-size:${size}px" aria-hidden="true">${[1,2,3,4,5].map(i=>{
   const id=`mmt-rating-${prefix}-${++ratingSvgSequence}`;
   const fill=rating>=i?100:rating>i-1?(rating-(i-1))*100:0;
   const path='M12 2.2 14.9 8.4 21.7 9.2 16.7 13.9 18 20.8 12 17.4 6 20.8 7.3 13.9 2.3 9.2 9.1 8.4Z';
   return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" focusable="false"><defs><clipPath id="${id}"><rect x="0" y="0" width="${24*fill/100}" height="24"/></clipPath></defs><path d="${path}" class="rating-star-outline"/><path d="${path}" class="rating-star-fill" clip-path="url(#${id})"/></svg>`;
 }).join('')}</span>`;
}
function syncRatingControl(){
 const select=$('rating'),trigger=$('ratingTrigger'),text=$('ratingTriggerText'),stars=$('ratingTriggerStars'),options=$('ratingOptions');
 if(!select||!trigger||!text||!stars||!options)return;
 const value=select.value,score=Number(value)||0;
 stars.innerHTML=ratingSvgStarsHtml(score,{size:19,prefix:'trigger'});
 text.textContent=value?score.toFixed(1)+' / 5':'ไม่ให้คะแนน';
 options.querySelectorAll('[data-rating-value]').forEach(b=>{
   const selected=b.dataset.ratingValue===value;
   b.classList.toggle('is-selected',selected);b.setAttribute('aria-selected',String(selected));
 });
}
function setupRatingControl(){
 const select=$('rating'),picker=$('ratingPicker'),trigger=$('ratingTrigger'),options=$('ratingOptions');
 if(!select||!picker||!trigger||!options)return;
 const values=['','5','4.5','4','3.5','3','2.5','2','1.5','1'];
 options.innerHTML=values.map((value)=>{
   if(!value)return `<button type="button" class="rating-option rating-option-none" role="option" aria-selected="false" data-rating-value=""><span class="rating-none-icon">○</span><span class="rating-option-label">ไม่ให้คะแนน</span><span class="rating-option-value">—</span></button>`;
   const score=Number(value);
   return `<button type="button" class="rating-option" role="option" aria-selected="false" data-rating-value="${value}"><span class="rating-option-stars">${ratingSvgStarsHtml(score,{size:22,prefix:'option'})}</span><span class="rating-option-value">${score.toFixed(1)}</span></button>`;
 }).join('');
 const close=()=>{options.hidden=true;trigger.setAttribute('aria-expanded','false');picker.classList.remove('is-open')};
 const open=()=>{options.hidden=false;trigger.setAttribute('aria-expanded','true');picker.classList.add('is-open');const selected=options.querySelector('[aria-selected="true"]');selected?.scrollIntoView({block:'nearest'});};
 trigger.addEventListener('click',()=>options.hidden?open():close());
 options.addEventListener('click',e=>{
   const b=e.target.closest('[data-rating-value]');if(!b)return;
   select.value=b.dataset.ratingValue;select.dispatchEvent(new Event('change',{bubbles:true}));syncRatingControl();close();trigger.focus();
 });
 document.addEventListener('click',e=>{if(!picker.contains(e.target))close()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!options.hidden){close();trigger.focus()}});
 select.addEventListener('change',syncRatingControl);
 syncRatingControl();
}

function openModal(x=null){const edit=!!x;const modal=$('modal');setSaveButtonState('idle',0,edit?'บันทึกการเปลี่ยนแปลง':'บันทึกและนำเข้า Chapter');modal.classList.remove('hidden');const formScroll=$('mangaFormScroll');if(formScroll)formScroll.scrollTop=0;$('modalTitle').textContent=edit?'แก้ไขการ์ตูน':'เพิ่มการ์ตูน';$('mangaId').value=edit?x.id:'';editingId=edit?(Number(x.id)||0):0;$('title').value=x?.title||'';$('altTitle').value=x?.alt_title||'';$('source').value=x?.source_url||'';$('cover').value=x?.cover_url||'';$('status').value=x?.status||'reading';$('rating').value=ratingSelectValue(x?.rating);syncRatingControl();$('note').value=x?.note||'';const themeSelect=$('cardTheme');if(themeSelect)themeSelect.value=edit?(cardThemeMap()[String(x.id)]||'auto'):'auto';syncThemeSwatches();$('autoImport').checked=!edit;const gs=edit?genreIds(x):[],cs=edit?collectionIds(x):[],completion=edit?(x.completion_status||'ongoing'):'ongoing';renderPickers(edit?(x.type_id??x.category_id):null,gs,cs,completion,edit?(x.lead_type||''):'');$('importStatus').textContent=edit?'แก้ไขข้อมูลแล้วกดบันทึก':'นำเข้าอัตโนมัติจะทำงานหลังบันทึก'}
function closeModal(){$('modal').classList.add('hidden');editingId=0}
function appendTitleAliases(existing,baseTitle,...values){
 const parts=String(existing||'').split(/[|;\n]+/).map(v=>v.trim()).filter(Boolean),base=dupNorm(baseTitle||'');
 for(const v of values)for(const alias of String(v||'').split(/[|;\n]+/).map(a=>a.trim()).filter(Boolean)){const k=dupNorm(alias);if(!k||k===base||parts.some(p=>dupNorm(p)===k))continue;parts.push(alias)}
 return parts.join(' | ').slice(0,255);
}
function duplicateAckKey(url){return dupUrl(url).key||String(url||'').trim()}
function hasDuplicateAcknowledgement(url){try{return JSON.parse(sessionStorage.getItem('dup_ack')||'[]').includes(duplicateAckKey(url))}catch{return false}}
function markDuplicateAcknowledgement(url){try{const a=JSON.parse(sessionStorage.getItem('dup_ack')||'[]'),k=duplicateAckKey(url);if(k&&!a.includes(k))a.push(k);sessionStorage.setItem('dup_ack',JSON.stringify(a.slice(-100)))}catch{}}
function importChapterLabel(imp){const chapters=Array.isArray(imp?.chapters)?imp.chapters:[];return imp?.last_chapter||chapters.slice(-1)[0]?.chapter||chapters.slice(-1)[0]?.number||''}
async function mergeImportedDuplicateIntoExisting(newId,url,imp,meta,matched){
 const existingId=Number(matched.id);let newItem=(state.items||[]).find(v=>Number(v.id)===Number(newId));
 if(!newItem){try{await refreshAll()}catch{};newItem=(state.items||[]).find(v=>Number(v.id)===Number(newId))}
 const oldUrl=String(matched.source_url||''),aliases=appendTitleAliases(matched.alt_title,matched.title,meta?.title,meta?.alt_title,imp?.title),cover=matched.cover_url||imp?.cover_url||'';
 // This row was inserted by this flow and has not yet received chapters. Move its URL out of the way for the normal API validation.
 const tempUrl=new URL(url);tempUrl.searchParams.set('mmt_merge_hold',`${Number(newId)}-${Date.now()}`);
 let moved=false,existingUpdated=false;
 try{
  if(newItem){await api('update_manga',fullUpdatePayload(newItem,{source_url:tempUrl.toString()}));moved=true}
  await api('update_manga',fullUpdatePayload(matched,{source_url:url,alt_title:aliases,cover_url:cover}));existingUpdated=true;
  if(moved)await api('delete_manga',{id:Number(newId)});
  if(oldUrl!==url)recordSourceUrlHistory(matched,oldUrl,url);
  let saved=null,importIssue='';
  if(Array.isArray(imp?.chapters)&&imp.chapters.length){
   try{saved=await api('save_imported_chapters',{id:existingId,source_url:url,import:imp,title_was_blank:!matched.title,cover_was_blank:!matched.cover_url,imported_title:imp.title||'',imported_cover_url:imp.cover_url||''})}
   catch(importErr){importIssue=String(importErr?.message||'บันทึก Chapter ไม่สำเร็จ');try{await api('set_import_status',{id:existingId,source_url:url,sync_status:'error',sync_error:importIssue})}catch{}}
  }else{importIssue='เปลี่ยนเว็บต้นทางแล้ว แต่ยังดึง Chapter ไม่ได้';try{await api('set_import_status',{id:existingId,source_url:url,sync_status:'unverifiable',sync_error:importIssue+' กรุณากด Browser Import ภายหลัง'})}catch{}}
  try{await refreshAll()}catch{}
  const found=Number(saved?.imported_chapter_count||imp?.chapter_count||0),expected=Number(saved?.expected_chapters||imp?.total_chapters||0),complete=!!saved?.import_complete;
  setBackgroundImportPanel({state:complete?'success':importIssue?'error':'partial',progress:100,title:complete?'รวมเรื่องและนำเข้า Chapter สำเร็จ':importIssue?'รวมเรื่องแล้ว แต่ Chapter ต้องตรวจสอบ':'รวมเข้ากับเรื่องเดิมแล้ว',detail:`${matched.title} • ${saved?`นำเข้า ${found}${expected?`/${expected}`:''} Chapter`:importIssue}`,id:existingId,url,canBrowser:!complete,percentLabel:complete?'รวมเรื่องและนำเข้า Chapter ครบ':'รวมเรื่องแล้ว • ตรวจ Chapter ต่อ'});
  showToast(complete?`ใช้เรื่องเดิม “${matched.title}” แล้วและนำเข้า Chapter สำเร็จ`: `ใช้เรื่องเดิม “${matched.title}” แล้ว • ${importIssue||'Chapter ยังไม่ครบ'}`,!complete);
 }catch(err){
  if(moved&&!existingUpdated&&newItem){try{await api('update_manga',fullUpdatePayload(newItem,{source_url:url}))}catch{}}
  throw err;
 }
}
async function _runNewMangaBackgroundImportCore(id,url,meta={}){
 setBackgroundImportPanel({state:'downloading',progress:8,title:'กำลังเริ่มนำเข้า Chapter',detail:meta.title||url,id,url,percentLabel:'8% · เตรียมดึงข้อมูล'});
 try{
  await api('set_import_status',{id,source_url:url,sync_status:'running',sync_error:'กำลังดึง Chapter ในเบื้องหลัง'});
  setBackgroundImportPanel({state:'downloading',progress:28,title:'กำลังอ่านเว็บต้นทาง',detail:'กำลังตรวจชื่อเรื่อง รูปปก และรายการ Chapter',id,url,percentLabel:'28% · อ่านข้อมูลต้นทาง'});
  try{await refreshAll()}catch{}
  const scanned=await api('import_source',{source_url:url}),imp=scanned.import||{};
  const duplicate=await resolveImportedDuplicate(id,url,imp,meta);
  if(duplicate.action==='cancel'){
   await api('delete_manga',{id:Number(id)});await refreshAll();
   setBackgroundImportPanel({state:'partial',progress:100,title:'ยกเลิกรายการใหม่แล้ว',detail:'ตรวจพบเรื่องที่น่าจะซ้ำและยกเลิกการเพิ่มแล้ว',id,url,percentLabel:'ยกเลิกแล้ว'});showToast('ยกเลิกรายการใหม่แล้ว • เก็บเรื่องเดิมไว้');return;
  }
  if(duplicate.action==='reuse'){await mergeImportedDuplicateIntoExisting(id,url,imp,meta,duplicate.match);return}
  if(!Array.isArray(imp.chapters)||imp.chapters.length===0){
   const msg='เว็บตอบกลับแล้ว แต่ยังไม่พบรายการ Chapter ที่อ่านได้';try{await api('set_import_status',{id,source_url:url,sync_status:'unverifiable',sync_error:msg})}catch{}
   await refreshAll();setBackgroundImportPanel({state:'partial',progress:100,title:'ยังไม่พบ Chapter',detail:`${imp.title||meta.title||'เรื่องใหม่'} • ${msg}`,id,url,canBrowser:true,percentLabel:'ต้องใช้ Browser Import'});showToast('บันทึกเรื่องแล้ว แต่ยังไม่พบ Chapter • กด Browser Import ในแถบสถานะ',true);return;
  }
  setBackgroundImportPanel({state:'downloading',progress:74,title:'กำลังบันทึก Chapter',detail:`พบ ${Number(imp.chapter_count||imp.chapters.length)}${imp.total_chapters?`/${Number(imp.total_chapters)}`:''} ตอน`,id,url,percentLabel:'74% · บันทึกรายการตอน'});
  const saved=await api('save_imported_chapters',{id,source_url:url,import:imp,title_was_blank:!!meta.title_was_blank,cover_was_blank:!!meta.cover_was_blank,imported_title:imp.title||'',imported_cover_url:imp.cover_url||''});
  const found=Number(saved.imported_chapter_count||imp.chapter_count||0),expected=Number(saved.expected_chapters||imp.total_chapters||0),complete=!!saved.import_complete;
  recordSyncHistory({manga_id:id,title:imp.title||meta.title||'เรื่องใหม่',status:saved.sync_status||'success',message:saved.sync_error||`ดึง ${found}${expected?`/${expected}`:''} Chapter`,found,expected});await refreshAll();
  setBackgroundImportPanel({state:complete?'success':'partial',progress:100,title:complete?'นำเข้า Chapter สำเร็จ':'นำเข้า Chapter แล้ว แต่ยังยืนยันความครบไม่ได้',detail:`${imp.title||meta.title||'เรื่องใหม่'} • ${found}${expected?`/${expected}`:''} Chapter`,id,url,canBrowser:!complete,percentLabel:complete?'เสร็จสมบูรณ์':`พบ ${found}${expected?` จาก ${expected}`:''} ตอน`});
  if(complete)showToast(`นำเข้า Chapter สำเร็จ ${saved.new_chapters||0} ตอนใหม่${expected?` • ครบ ${expected} ตอน`:''}`);else showToast(`นำเข้า ${found}${expected?`/${expected}`:''} ตอน แต่ยังยืนยันความครบถ้วนไม่ได้`,true);
 }catch(err){
  const message=String(err?.message||'นำเข้า Chapter ไม่สำเร็จ'),blocked=!!(err?.data?.browser_required||/403|429|ปฏิเสธคำขอ|ดึงหน้าเว็บต้นทางไม่สำเร็จ/i.test(message));
  try{await api('set_import_status',{id,source_url:url,sync_status:blocked?'blocked':'error',sync_error:message})}catch{}
  recordSyncHistory({manga_id:id,title:meta.title||url,status:blocked?'blocked':'error',message,found:0,expected:0});try{await refreshAll()}catch{}
  setBackgroundImportPanel({state:blocked?'partial':'error',progress:100,title:blocked?'เว็บต้นทางบล็อกการดึงอัตโนมัติ':'นำเข้า Chapter ไม่สำเร็จ',detail:`${meta.title||url} • ${message}`,id,url,canBrowser:true,percentLabel:blocked?'ต้องใช้ Browser Import':'ต้องลองใหม่'});
  showToast(blocked?'บันทึกเรื่องแล้ว แต่เว็บบล็อกการดึงอัตโนมัติ • กด Browser Import เพื่อดำเนินการต่อ':`บันทึกเรื่องแล้ว แต่ดึง Chapter ไม่สำเร็จ: ${message}`,true);
 }
}
async function saveManga(e){
 e.preventDefault();const editId=editingId||Number($('mangaId').value)||0,edit=editId>0,tx=selectedTaxonomy();if(!tx.type_id)return showToast('กรุณาเลือกประเภทหลัก',true);
 const chosenCardTheme=$('cardTheme')?.value||'auto';const payload={id:editId||'',title:$('title').value.trim(),alt_title:$('altTitle').value.trim(),source_url:$('source').value.trim(),cover_url:$('cover').value.trim(),type_id:tx.type_id,lead_type:tx.lead_type,status:$('status').value,rating:$('rating').value,note:$('note').value.trim(),genre_ids:tx.genre_ids,collection_ids:tx.collection_ids,completion_status:tx.completion_status,auto_import:$('autoImport').checked};
 if(!payload.source_url)return showToast('กรุณาใส่ URL หน้าหลักของเรื่อง',true);const shouldImportInBackground=!edit&&payload.auto_import,meta={title:payload.title,title_was_blank:!payload.title,cover_was_blank:!payload.cover_url};
 let duplicateChoice={action:'add'};if(!edit){duplicateChoice=await duplicateGuardBeforeAdd(payload);if(duplicateChoice.action==='cancel')return}
 setSaveButtonState('downloading',18,shouldImportInBackground?'กำลังบันทึกเรื่องก่อนนำเข้า Chapter...':'กำลังบันทึก...');
 try{
  if(!edit&&duplicateChoice.action==='reuse'){
   const existing=duplicateChoice.match||state.items.find(v=>Number(v.id)===Number(duplicateChoice.matchId));if(!existing)throw new Error('ไม่พบรายการเดิมที่เลือก กรุณาลองเปิดคลังใหม่');
   const oldUrl=existing.source_url,aliases=appendTitleAliases(existing.alt_title,existing.title,payload.title,payload.alt_title);await api('update_manga',fullUpdatePayload(existing,{source_url:payload.source_url,alt_title:aliases,cover_url:existing.cover_url||payload.cover_url||''}));await pushBookmarkChapters(existing.id,payload.source_url);if(oldUrl!==payload.source_url)recordSourceUrlHistory(existing,oldUrl,payload.source_url);
   closeModal();setSaveButtonState('downloaded',100,'ใช้รายการเดิมแล้ว');try{await refreshAll()}catch{}
   if(shouldImportInBackground){setBackgroundImportPanel({state:'downloading',progress:8,title:'ใช้เรื่องเดิม • กำลังซิงก์เว็บต้นทางใหม่',detail:existing.title,id:Number(existing.id),url:payload.source_url,percentLabel:'8% · เตรียมซิงก์'});void runNewMangaBackgroundImport(Number(existing.id),payload.source_url,{...meta,title:existing.title,skipDuplicatePrompt:true,title_was_blank:false,cover_was_blank:!existing.cover_url})}else showToast(`ใช้รายการเดิม “${existing.title}” แล้ว`);
   return;
  }
  const requestPayload=shouldImportInBackground?{...payload,auto_import:false}:payload,d=await api(edit?'update_manga':'add_manga',requestPayload);if(editId)saveCardTheme(editId,chosenCardTheme);else if(d.id)saveCardTheme(Number(d.id),chosenCardTheme);
  if(!edit&&d.id)await pushBookmarkChapters(d.id,payload.source_url);
  setSaveButtonState('downloaded',100,'บันทึกแล้ว');closeModal();
  if(!edit&&shouldImportInBackground){showToast('เพิ่มเรื่องแล้ว • กำลังนำเข้า Chapter ในเบื้องหลัง');try{await refreshAll()}catch{};void runNewMangaBackgroundImport(Number(d.id),payload.source_url,meta)}
  else{showToast(edit?'แก้ไขข้อมูลเรื่องเรียบร้อยแล้ว':'เพิ่มเรื่องแล้ว');await refreshAll();if(d.reward_unlocked&&d.completion_card)showCompletionReward(d.completion_card)}
 }catch(err){const dup=err.status===409?err.data?.duplicate:null;if(dup&&!edit)showToast(`URL นี้ถูกใช้แล้วในเรื่อง “${dup.title}” • กรุณาใช้รายการเดิมจากคำเตือน`,true);else showToast(err.message,true)}
 finally{await new Promise(r=>setTimeout(r,420));setSaveButtonState('idle',0,editingId?'บันทึกการเปลี่ยนแปลง':'บันทึกและนำเข้า Chapter')}
}
function buildBrowserImportUrl(url,id){try{const u=new URL(url);if(Number(id)>0)u.hash=`mymanga_import=${encodeURIComponent(id)}`;return u.toString()}catch{return url}}
function buildBookmarklet(){
 const dest=location.origin+location.pathname;
 const src="(function(){var d=document,q=function(p){var e=d.querySelector('meta[property=\"'+p+'\"],meta[name=\"'+p+'\"]');return e?(e.content||''):''};var base=location.href.split('\\x23')[0],seen={},ch=[];[].forEach.call(d.querySelectorAll('a[href]'),function(a){var h=a.href.split('\\x23')[0],x=(a.textContent||'').replace(/\\s+/g,' ').trim();if(h.indexOf(location.origin)!==0||seen[h]||h===base)return;var k;try{k=decodeURIComponent(h)}catch(e){k=h}if(/(chapter|chap|episode|ep|ch|ตอน)[-_\\/ .]*\\d/i.test(k+' '+x)){seen[h]=1;ch.push([h,x.slice(0,80)])}});var img=q('og:image')||q('twitter:image');var p={u:base,t:(q('og:title')||d.title||'').trim(),c:img?new URL(img,location.href).href:'',ch:ch.slice(0,500)};location.href="+JSON.stringify(dest)+"+'\\x23mmimport='+encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(p)))))})();";
 return 'javascript:'+src;
}
function openBrowserImport(id,url){
 const src=(url||$('source')?.value||'').trim();
 const old=document.getElementById('bmHelpModal');if(old)old.remove();
 const bm=buildBookmarklet();
 const modal=document.createElement('div');modal.className='modal';modal.id='bmHelpModal';
 modal.innerHTML=`<div class="modal-box"><div class="modal-head"><div><div class="section-kicker">BROWSER IMPORT</div><h2>นำเข้าผ่านเบราว์เซอร์</h2><p class="modal-note">ใช้เมื่อเว็บต้นทางบล็อกเซิร์ฟเวอร์ (HTTP 403) • ไม่ต้องลง Extension ใช้ได้ทั้งคอมและมือถือ</p></div><button class="close-btn" type="button" data-bm-close>×</button></div><div class="modal-form-scroll"><ol class="bm-steps"><li><b>ตั้งค่าครั้งเดียว:</b> กด “คัดลอกสคริปต์” แล้วสร้างบุ๊กมาร์กใหม่ในเบราว์เซอร์ ตั้งชื่อว่า <b>MyManga</b> และวางสคริปต์ในช่อง URL<br><small>คอม: ลากปุ่ม 🔖 ไปวางที่แถบบุ๊กมาร์กได้เลย</small></li><li>กด “เปิดเว็บต้นทาง” แล้วเข้าไปที่หน้าหลักของเรื่อง (รอจนหน้าโหลดครบ)</li><li>กดบุ๊กมาร์ก <b>MyManga</b> (มือถือ: พิมพ์ MyManga ที่แถบ URL แล้วเลือกรายการที่มีไอคอนดาว) ระบบจะพากลับมาที่นี่พร้อมชื่อ ปก และ Chapter ที่กรอกให้แล้ว</li><li>เลือกประเภทหลัก แล้วกดบันทึก</li></ol><div class="import-actions"><a class="btn ghost bm-drag" id="bmDragLink" href="#">🔖 MyManga</a><button class="btn ghost" type="button" id="bmCopyBtn">📋 คัดลอกสคริปต์</button><button class="btn ghost" type="button" id="bmOpenBtn">↗ เปิดเว็บต้นทาง</button></div></div></div>`;
 document.body.appendChild(modal);
 const close=()=>modal.remove();
 modal.querySelectorAll('[data-bm-close]').forEach(b=>b.onclick=close);modal.addEventListener('click',e=>{if(e.target===modal)close()});
 const drag=modal.querySelector('#bmDragLink');drag.setAttribute('href',bm);drag.onclick=e=>{e.preventDefault();showToast('ลากปุ่มนี้ไปวางที่แถบบุ๊กมาร์ก หรือกด “คัดลอกสคริปต์”')};
 modal.querySelector('#bmCopyBtn').onclick=async()=>{try{await navigator.clipboard.writeText(bm);showToast('คัดลอกสคริปต์แล้ว • นำไปวางในช่อง URL ของบุ๊กมาร์ก')}catch{const ta=document.createElement('textarea');ta.value=bm;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');showToast('คัดลอกสคริปต์แล้ว')}catch{showToast('คัดลอกไม่สำเร็จ',true)}ta.remove()}};
 modal.querySelector('#bmOpenBtn').onclick=()=>{const target=buildBrowserImportUrl(src,id||Number($('mangaId')?.value));if(!src||!target||target==='#')return showToast('ใส่ URL หน้าหลักของเรื่องก่อน',true);if(!directOpenUrl(target))showToast('เปิดแท็บใหม่ไม่สำเร็จ กรุณาอนุญาต Pop-up',true)};
}
async function pushBookmarkChapters(mangaId,sourceUrl){
 const b=window.__bmImport;if(!b||!mangaId||b.url!==sourceUrl)return;window.__bmImport=null;
 if(!b.chapters.length)return;
 try{const r=await api('browser_import',{manga_id:Number(mangaId),source_url:b.url,title:'',cover_url:'',chapters:b.chapters});showToast(`นำเข้า/อัปเดต ${r.chapter_count||b.chapters.length} Chapter จากเบราว์เซอร์แล้ว`)}
 catch(e){showToast('บันทึกเรื่องแล้ว แต่นำเข้า Chapter ไม่สำเร็จ: '+e.message,true)}
}
function applyBookmarkImport(){
 const m=String(window.__mmHash||'').match(/^#mmimport=(.+)$/);if(!m)return;window.__mmHash='';
 let p;try{p=JSON.parse(decodeURIComponent(escape(atob(decodeURIComponent(m[1])))))}catch{return showToast('อ่านข้อมูลจากบุ๊กมาร์กไม่สำเร็จ',true)}
 openModal();$('source').value=p.u||'';$('title').value=p.t||'';$('cover').value=p.c||'';$('autoImport').checked=false;
 const chs=Array.isArray(p.ch)?p.ch:[];window.__bmImport={url:p.u||'',chapters:chs.map(x=>({chapter_url:x[0],chapter:x[1]}))};
 $('importStatus').textContent=`ได้ข้อมูลจากเบราว์เซอร์แล้ว • ชื่อ ${p.t?'✓':'✗'} • ปก ${p.c?'✓':'✗'} • ${chs.length} Chapter • เลือกประเภทหลักแล้วกดบันทึก`;
 showToast('รับข้อมูลจากบุ๊กมาร์กแล้ว • เลือกประเภทหลักแล้วกดบันทึก');
}
async function importPreview(){
 const url=$('source').value.trim();if(!url)return showToast('ใส่ URL ก่อน',true);$('importStatus').textContent='กำลังดึง metadata/Chapter...';
 try{const d=await api('import_source',{source_url:url}),imp=d.import||{};window.__importPreview={url,chapter_count:Number(imp.chapter_count||0),total:Number(imp.total_chapters||0),last:(imp.chapters||[]).slice(-1)[0]?.chapter||imp.last_chapter||'',genres:imp.genres||[],cover:imp.cover_url||'',title:imp.title||''};if(imp.title&&!$('title').value.trim())$('title').value=imp.title;if(imp.cover_url&&!$('cover').value.trim())$('cover').value=imp.cover_url;$('importStatus').textContent=`${imp.adapter||'generic'} • พบ ${imp.chapter_count||0}${imp.total_chapters?`/${imp.total_chapters}`:''} Chapter • สแกน ${imp.pages_scanned||1} หน้า${imp.import_complete===false?' • ยังขาดบางตอน':''}`;
  if(Array.isArray(imp.genres)){const selectedNow=[...document.querySelectorAll('#genrePicker [data-pick-genre].selected')].map(b=>Number(b.dataset.pickGenre));for(const name of imp.genres){const g=state.genres.find(v=>v.name.toLowerCase()===String(name).toLowerCase());if(g)selectedNow.push(Number(g.id))}renderTagsSelector('genrePicker','genre',state.genres,[...new Set(selectedNow)],o=>genreLabel(o.name))}
 }catch(e){$('importStatus').textContent=`Server Import: ${e.message} • เว็บที่บล็อกบอทให้กด “นำเข้าผ่านเบราว์เซอร์” ด้วยตนเอง`;showToast(e.message,true)}
}
function openTaxonomy(){$('taxonomyModal').classList.remove('hidden');renderManagersBindings()}
function closeTaxonomy(){$('taxonomyModal').classList.add('hidden')}
function openTimeline(){$('timelineModal').classList.remove('hidden');renderTimeline()}
function closeTimeline(){$('timelineModal').classList.add('hidden')}
function clearFilters(){$('search').value='';$('typeFilter').value='all';$('genreFilter').value='all';if($('leadFilter'))$('leadFilter').value='all';if($('sourceFilter'))$('sourceFilter').value='all';$('statusFilter').value='all';$('readFilter').value='all';$('sortFilter').value='updated';if($('ratingFilter'))$('ratingFilter').value='all';$('collectionFilter').value='all';if($('oneshotFilter')){$('oneshotFilter').value='separate';try{localStorage.setItem('mmt_oneshot_mode','separate')}catch{}}render()}
async function exportBackup(){try{const d=await api('export_all');const blob=new Blob([JSON.stringify(d.backup,null,2)],{type:'application/json'});download(blob,`MyManga_Backup_${new Date().toISOString().slice(0,10)}.json`);showToast('สร้าง Backup JSON แล้ว')}catch(e){showToast(e.message,true)}}
async function exportCSV(){try{const d=await api('export_all');const rows=[['title','alt_title','type','status','current_chapter','last_chapter','rating','favorite','source_url']];for(const x of d.backup.manga||[]){const t=state.types.find(v=>Number(v.id)===Number(x.type_id??x.category_id));rows.push([x.title,x.alt_title||'',t?.name||'',statusName(x.status),x.current_chapter,x.last_chapter||'',x.rating||'',x.favorite?'yes':'no',x.source_url])}const csv='\ufeff'+rows.map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');download(new Blob([csv],{type:'text/csv;charset=utf-8'}),`MyManga_${new Date().toISOString().slice(0,10)}.csv`);showToast('Export CSV แล้ว')}catch(e){showToast(e.message,true)}}
function download(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
async function restoreBackup(file){try{const data=JSON.parse(await file.text());if(data.format!=='mymanga-tracker')return showToast('ไฟล์ Backup ไม่ถูกต้อง',true);if(!confirm(`Restore Backup ${data.exported_at||''}?\nระบบจะเพิ่ม/อัปเดตโดยไม่ลบข้อมูลเดิม`))return;const d=await api('import_backup',{backup:data});showToast(`Restore สำเร็จ • เรื่อง ${d.manga} • Chapter ${d.chapters}`);await refreshAll()}catch(e){showToast(e.message,true)}}
function setupFilterLayout(){
 const root=$('filterTools');if(!root||root.dataset.compactReady)return;root.dataset.compactReady='1';
 const advanced=['genreFilter','sourceFilter','leadFilter','statusFilter','readFilter','sortFilter','ratingFilter','collectionFilter','oneshotFilter'];
 const details=document.createElement('details');details.className='advanced-filters';details.id='advancedFiltersDetails';
 details.innerHTML='<summary>ตัวกรองขั้นสูง <span>แนว · เว็บต้นทาง · ตัวเอก · สถานะ · Collection · Oneshot</span></summary><div class="advanced-filter-grid" id="advancedFilterGrid"></div>';
 const grid=details.querySelector('#advancedFilterGrid');for(const id of advanced){const el=$(id);if(el)grid.appendChild(el)}
 const view=$('viewBtn');root.insertBefore(details,view||null);
}
function renderActiveFilterChips(){
 const host=$('activeFilterChips');if(!host)return;const entries=[];const q=$('search')?.value?.trim();if(q)entries.push(['search',`ค้นหา: ${q}`]);
 [['typeFilter','ประเภท'],['genreFilter','แนว'],['sourceFilter','เว็บ'],['leadFilter','ตัวเอก'],['statusFilter','สถานะ'],['readFilter','รายการ'],['ratingFilter','คะแนน'],['collectionFilter','Collection']].forEach(([id,label])=>{const e=$(id);if(e&&e.value!=='all')entries.push([id,`${label}: ${e.selectedOptions?.[0]?.textContent?.trim()||e.value}`])});
 host.innerHTML=entries.map(([id,label])=>`<button type="button" class="filter-chip" data-clear-filter="${id}" title="ล้างตัวกรองนี้">${esc(label)} <b>×</b></button>`).join('');
}
function renderBulkToolbar(){
 const bar=$('bulkToolbar');if(!bar)return;const n=state.selectedIds.size;if(!n){bar.classList.add('hidden');bar.innerHTML='';return}bar.classList.remove('hidden');bar.innerHTML=`<div><b>เลือกแล้ว ${n} เรื่อง</b><small>การเปลี่ยนเว็บต้นทางจะแสดง URL ให้ตรวจทีละเรื่องก่อนบันทึก</small></div><div class="bulk-actions"><button class="btn ghost" data-bulk-select-visible>เลือกผลค้นหาทั้งหมด</button><button class="red btn" data-bulk-edit>แก้ไขที่เลือก</button><button class="btn ghost" data-bulk-sync>ซิงก์ที่เลือก</button><button class="btn ghost" data-bulk-clear>ยกเลิกเลือก</button><button class="btn danger" data-bulk-delete>ลบที่เลือก</button></div>`;
}
function fullUpdatePayload(x,patch={}){return {id:Number(x.id),title:x.title,alt_title:x.alt_title||'',source_url:patch.source_url??x.source_url,cover_url:x.cover_url||'',type_id:Number(x.type_id??x.category_id)||preferredDefaultTypeId(),lead_type:normalizeLeadType(x.lead_type),status:x.status||'reading',rating:x.rating??'',note:x.note||'',genre_ids:genreIds(x),collection_ids:collectionIds(x),completion_status:x.completion_status||'ongoing',...patch}}
function openBulkEdit(){
 const ids=[...state.selectedIds],items=ids.map(id=>state.items.find(x=>Number(x.id)===id)).filter(Boolean);if(!items.length)return showToast('กรุณาเลือกเรื่องก่อน',true);
 const modal=document.createElement('div');modal.className='modal';modal.id='bulkEditModal';
 modal.innerHTML=`<div class="modal-box large-modal"><div class="modal-head"><div><div class="section-kicker">BULK EDIT</div><h2>แก้ไข ${items.length} เรื่องพร้อมกัน</h2><p class="modal-note">ติ๊กเฉพาะช่องที่ต้องการเปลี่ยน ค่าอื่นของแต่ละเรื่องจะคงเดิม</p></div><button class="close-btn" data-close-modal>×</button></div><form id="bulkEditForm"><div class="bulk-form-grid"><label class="bulk-change"><input type="checkbox" id="applyBulkType"> เปลี่ยนประเภทหลัก</label><select id="bulkType">${state.types.map(t=>`<option value="${t.id}">${esc(typeIcon(t.name)+' '+t.name)}</option>`).join('')}</select><label class="bulk-change"><input type="checkbox" id="applyBulkLead"> เปลี่ยนลักษณะตัวเอก/คู่หลัก</label><select id="bulkLead"><option value="">ไม่ระบุ</option><option value="male">Male — ตัวเอกชาย</option><option value="female">Female — ตัวเอกหญิง</option><option value="gay">(Gay) เกย์</option><option value="lesbian">(Lesbian) เลสเบี้ยน</option></select><label class="bulk-change"><input type="checkbox" id="applyBulkStatus"> เปลี่ยนสถานะการอ่าน</label><select id="bulkStatus"><option value="reading">กำลังอ่าน</option><option value="planned">วางแผนอ่าน</option><option value="completed">อ่านจบแล้ว</option><option value="paused">พักการอ่าน</option><option value="dropped">เลิกอ่าน</option></select><label class="bulk-change"><input type="checkbox" id="applyBulkCompletion"> เปลี่ยนสถานะเรื่องต้นทาง</label><select id="bulkCompletion"><option value="ongoing">ยังไม่จบ</option><option value="completed">จบแล้ว</option></select><label class="bulk-change"><input type="checkbox" id="applyBulkGenres"> แทนที่แนวของทุกรายการด้วยแนวที่เลือก</label><select id="bulkGenres" multiple size="5">${state.genres.map(g=>`<option value="${g.id}">${esc(genreLabel(g.name))}</option>`).join('')}</select><label class="bulk-change"><input type="checkbox" id="applyBulkCols"> แทนที่ Collection ของทุกรายการด้วยกลุ่มที่เลือก</label><select id="bulkCols" multiple size="5">${state.collections.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div><div class="review-safe-note">ข้อควรระวัง: การติ๊กแทนที่แนวหรือ Collection จะใช้ชุดเดียวกันกับทุกเรื่องที่เลือก</div><div class="modal-actions"><button type="button" class="btn ghost" data-close-modal>ยกเลิก</button><button type="submit" class="red btn">บันทึกการเปลี่ยนแปลง</button></div></form></div>`;
 document.body.appendChild(modal);const close=()=>modal.remove();modal.querySelectorAll('[data-close-modal]').forEach(b=>b.onclick=close);modal.onclick=e=>{if(e.target===modal)close()};
 $('bulkEditForm').onsubmit=async e=>{e.preventDefault();const patch={};if($('applyBulkType').checked)patch.type_id=Number($('bulkType').value);if($('applyBulkLead').checked)patch.lead_type=$('bulkLead').value;if($('applyBulkStatus').checked)patch.status=$('bulkStatus').value;if($('applyBulkCompletion').checked)patch.completion_status=$('bulkCompletion').value;if($('applyBulkGenres').checked)patch.genre_ids=[...$('bulkGenres').selectedOptions].map(o=>Number(o.value));if($('applyBulkCols').checked)patch.collection_ids=[...$('bulkCols').selectedOptions].map(o=>Number(o.value));if(!Object.keys(patch).length)return showToast('เลือกช่องที่ต้องการเปลี่ยนอย่างน้อย 1 รายการ',true);if(!confirm(`ยืนยันเปลี่ยนข้อมูล ${items.length} เรื่องหรือไม่?`))return;const btn=modal.querySelector('[type=submit]');btn.disabled=true;let ok=0,fail=[];for(const x of items){try{await api('update_manga',fullUpdatePayload(x,patch));ok++}catch(err){fail.push(`${x.title}: ${err.message}`)}}close();state.selectedIds.clear();await refreshAll();showToast(`แก้ไขสำเร็จ ${ok}/${items.length} เรื่อง${fail.length?` • ผิดพลาด ${fail.length} เรื่อง`:''}`,!!fail.length);if(fail.length)alert(fail.slice(0,10).join('\n'))};
}
function readSourceUrlHistory(){try{const h=JSON.parse(localStorage.getItem('manga_source_url_history')||'[]');return Array.isArray(h)?h:[]}catch{return []}}
function recordSourceUrlHistory(item,from,to){try{const h=readSourceUrlHistory();h.unshift({id:Number(item.id),title:String(item.title||''),from:String(from||''),to:String(to||''),at:new Date().toISOString()});localStorage.setItem('manga_source_url_history',JSON.stringify(h.slice(0,300)))}catch{}}
function renderSourceUrlHistory(){const host=$('sourceMgrHistory');if(!host)return;const h=readSourceUrlHistory();host.innerHTML=h.slice(0,20).map(v=>`<div class="source-history-row"><div><b>${esc(v.title||`เรื่อง #${v.id||'?'}`)}</b><small>${v.at?esc(new Date(v.at).toLocaleString('th-TH')):''}</small></div><div class="source-history-urls"><span title="URL เดิม">เดิม: ${esc(v.from||'-')}</span><span title="URL ใหม่">ใหม่: ${esc(v.to||'-')}</span></div></div>`).join('')||'<div class="empty">ยังไม่มีประวัติการเปลี่ยน URL</div>'}
function openSourceManager(defaultHost='all'){
 const modal=document.createElement('div');modal.className='modal';modal.id='sourceManagerModal';let drafts={};let host=defaultHost;let query='';
 const hosts=[...new Set(state.items.map(x=>sourceHost(x.source_url)).filter(Boolean))].sort();if(host!=='all'&&!hosts.includes(host))host='all';
 modal.innerHTML=`<div class="modal-box source-manager-box"><div class="modal-head"><div><div class="section-kicker">SOURCE MANAGER</div><h2>ศูนย์จัดการเว็บต้นทาง</h2><p class="modal-note">ค้นหาเรื่องจากโดเมนเดียวกัน ตรวจสาเหตุซิงก์ และแก้ URL แบบรายเรื่อง</p></div><button type="button" class="close-btn" data-sm-close>×</button></div><div class="source-manager-tools"><select id="sourceMgrHost"><option value="all">ทุกเว็บต้นทาง (${state.items.length})</option>${hosts.map(h=>`<option value="${esc(h)}">${esc(h)} (${state.items.filter(x=>sourceHost(x.source_url)===h).length})</option>`).join('')}</select><input id="sourceMgrSearch" placeholder="ค้นหาชื่อเรื่อง / URL"><span id="sourceMgrCount"></span></div><div id="sourceMgrRows" class="source-manager-rows"></div><details class="source-url-history"><summary>ประวัติ URL ต้นทางที่เปลี่ยนล่าสุด</summary><div id="sourceMgrHistory" class="source-history-list"></div></details><div class="modal-actions"><button type="button" class="btn ghost" data-sm-close>ปิด</button><button type="button" id="sourceMgrSave" class="red btn">บันทึก URL ที่แก้ไข</button></div></div>`;
 document.body.appendChild(modal);$('sourceMgrHost').value=host;const close=()=>modal.remove();modal.querySelectorAll('[data-sm-close]').forEach(b=>b.onclick=close);modal.onclick=e=>{if(e.target===modal)close()};
 const paint=()=>{host=$('sourceMgrHost').value;query=$('sourceMgrSearch').value.trim().toLowerCase();const rows=state.items.filter(x=>(host==='all'||sourceHost(x.source_url)===host)&&(!query||`${x.title} ${x.source_url}`.toLowerCase().includes(query))).sort((a,b)=>sourceHost(a.source_url).localeCompare(sourceHost(b.source_url))||String(a.title).localeCompare(String(b.title),'th'));$('sourceMgrCount').textContent=`${rows.length} เรื่อง`;$('sourceMgrRows').innerHTML=rows.map(x=>{const status=x.sync_status==='blocked'?'Browser Import':x.sync_status==='error'?'ซิงก์ล้มเหลว':x.sync_status==='partial'?'ดึงไม่ครบ':x.sync_status==='unverifiable'?'ยืนยันจำนวนไม่ได้':x.sync_status==='review'?'ผลซิงก์ต้องตรวจสอบ':x.sync_status==='running'?'กำลังดึงตอน':x.sync_status==='success'?'ปกติ':'ยังไม่เคยซิงก์';const cls=['blocked','error','partial','unverifiable','review'].includes(x.sync_status)?'warning':x.sync_status==='running'?'info':x.sync_status==='success'?'success':'';return `<div class="source-manager-row"><div class="source-manager-info"><strong>${esc(x.title)}</strong><small>${esc(sourceHost(x.source_url)||'ไม่ทราบโดเมน')} · ล่าสุด ${esc(x.last_chapter||x.latest_chapter||'-')} · <span class="source-state ${cls}" title="${esc(x.sync_error||'')}">${esc(status)}</span></small>${x.sync_error?`<small class="source-error">${esc(x.sync_error)}</small>`:''}<div class="source-row-links"><a href="${esc(x.source_url)}" target="_blank" rel="noopener noreferrer">เปิดเว็บต้นทาง ↗</a><a href="${esc(buildBrowserImportUrl(x.source_url,x.id))}" target="_blank" rel="noopener noreferrer">Browser Import ↗</a></div></div><input type="url" data-source-url="${x.id}" aria-label="URL ใหม่ของ ${esc(x.title)}" value="${esc(drafts[x.id]??x.source_url)}"></div>`}).join('')||'<div class="empty">ไม่พบเรื่องตามเงื่อนไข</div>'};
 $('sourceMgrHost').onchange=paint;$('sourceMgrSearch').oninput=paint;$('sourceMgrRows').addEventListener('input',e=>{const el=e.target.closest('[data-source-url]');if(el)drafts[el.dataset.sourceUrl]=el.value});
 $('sourceMgrSave').onclick=async()=>{[...$('sourceMgrRows').querySelectorAll('[data-source-url]')].forEach(el=>{drafts[el.dataset.sourceUrl]=el.value});const changed=state.items.map(x=>({id:Number(x.id),url:String(drafts[x.id]??x.source_url).trim()})).filter(v=>{const x=state.items.find(a=>Number(a.id)===v.id);return x&&v.url&&v.url!==x.source_url});if(!changed.length)return showToast('ไม่มี URL ที่แก้ไข',true);for(const row of changed){try{const u=new URL(row.url);if(!['http:','https:'].includes(u.protocol))throw new Error('รองรับเฉพาะ HTTP/HTTPS')}catch{return showToast('มี URL ไม่ถูกต้อง กรุณาตรวจสอบก่อนบันทึก',true)}}if(!confirm(`กำลังแก้ URL ต้นทาง ${changed.length} เรื่อง ระบบจะเก็บ Chapter เดิมไว้จนกว่าจะซิงก์จาก URL ใหม่ ยืนยันหรือไม่?`))return;const btn=$('sourceMgrSave');btn.disabled=true;let ok=0,failed=[];for(const row of changed){const x=state.items.find(a=>Number(a.id)===row.id);try{await api('update_manga',fullUpdatePayload(x,{source_url:row.url}));recordSourceUrlHistory(x,x.source_url,row.url);ok++}catch(e){failed.push(`${x.title}: ${e.message}`)}}await refreshAll();renderSourceUrlHistory();showToast(`เปลี่ยน URL สำเร็จ ${ok}/${changed.length} เรื่อง${failed.length?` • ผิดพลาด ${failed.length}`:''}`,!!failed.length);if(failed.length)alert(failed.slice(0,10).join('\n'));if(!failed.length)close();else paint()};paint();renderSourceUrlHistory();
}
function openSettingsCenter(){
 const old=document.getElementById('settingsCenterModal');if(old)old.remove();const history=(()=>{try{return JSON.parse(localStorage.getItem('manga_sync_history')||'[]')}catch{return []}})();const problems=state.items.filter(x=>['error','blocked','partial','unverifiable','review'].includes(x.sync_status));
 const modal=document.createElement('div');modal.className='modal';modal.id='settingsCenterModal';modal.innerHTML=`<div class="modal-box settings-center-box"><div class="modal-head"><div><div class="section-kicker">APP SETTINGS</div><h2>ตั้งค่าและสถานะระบบ</h2><p class="modal-note">จัดการการเชื่อมต่อ การสำรองข้อมูล และตรวจข้อผิดพลาดล่าสุด</p></div><button type="button" class="close-btn" data-settings-close>×</button></div><div class="settings-cards"><div><small>เรื่องในคลัง</small><b>${state.items.length}</b></div><div><small>ต้องตรวจสอบ</small><b>${problems.length}</b></div><div><small>Sync log</small><b>${history.length}</b></div></div><label class="settings-token-label">API Token <input id="settingsTokenInput" type="password" autocomplete="off" value="${esc(getStoredToken())}" placeholder="ใส่ API Token"></label><div class="settings-actions"><button class="btn ghost" id="saveSettingsToken">บันทึก Token</button><button class="btn ghost" id="checkApiBtn">ตรวจสอบ API/ฐานข้อมูล</button><button class="red btn" id="openSettingsSources">ดูเว็บที่มีปัญหา</button></div><section class="settings-data-tools"><div class="settings-data-heading"><h3>สำรองและจัดการข้อมูล</h3><p>ใช้ Backup JSON เพื่อย้ายเครื่องหรือกู้ข้อมูล • CSV เหมาะกับการเปิดใน Excel</p></div><div class="settings-actions"><button class="btn ghost" id="settingsBackupBtn">↓ Backup JSON</button><button class="btn ghost" id="settingsExportCsvBtn">↓ Export CSV</button><button class="btn ghost" id="settingsRestoreBtn">↑ Restore JSON</button></div></section><section class="settings-data-tools settings-performance-tools"><div class="settings-data-heading"><h3>โหมดประหยัดเครื่อง</h3><p>ลดแสงสะท้อน แอนิเมชันและการเคลื่อนไหวของการ์ด เหมาะกับมือถือที่ต้องการความลื่นไหลและประหยัดแบต</p></div><label class="settings-performance-toggle"><input type="checkbox" id="settingsPerformanceToggle"> เปิดโหมดลดเอฟเฟกต์</label></section><div id="settingsApiStatus" class="settings-api-status">ยังไม่ได้ตรวจสอบการเชื่อมต่อ</div><div class="settings-log-head"><h3>ประวัติซิงก์ล่าสุด</h3><button type="button" class="text-link" id="clearSyncHistory">ล้างประวัติ</button></div><div class="settings-sync-history">${history.slice(0,12).map(h=>`<div class="settings-history-row"><span class="history-dot ${esc(h.status||'')} "></span><div><b>${esc(h.title||'เรื่องที่ถูกลบ')}</b><small>${esc(h.message||h.status||'')} · ${h.at?esc(new Date(h.at).toLocaleString('th-TH')):''}</small></div><span>${h.found!=null?`${esc(h.found)}/${h.expected||'?'} ตอน`:''}</span></div>`).join('')||'<div class="empty">ยังไม่มีประวัติซิงก์</div>'}</div><div class="review-safe-note">Auto Backup จะเก็บสำเนาไว้ในเบราว์เซอร์นี้ หากเปลี่ยนอุปกรณ์ให้ดาวน์โหลด Backup JSON เก็บไว้ด้วย</div></div>`;
 document.body.appendChild(modal);const close=()=>modal.remove();modal.querySelectorAll('[data-settings-close]').forEach(b=>b.onclick=close);modal.onclick=e=>{if(e.target===modal)close()};
 const perfToggle=$('settingsPerformanceToggle');if(perfToggle){perfToggle.checked=document.documentElement.classList.contains('mmt-performance-mode');perfToggle.addEventListener('change',()=>{setMmtPerformanceMode(perfToggle.checked);showToast(perfToggle.checked?'เปิดโหมดลดเอฟเฟกต์แล้ว':'คืนค่าเอฟเฟกต์เดิมแล้ว')})}
 $('saveSettingsToken').onclick=async()=>{localStorage.setItem('manga_token',$('settingsTokenInput').value.trim());$('settingsApiStatus').textContent='บันทึก Token แล้ว กำลังทดสอบ...';try{await api('list');$('settingsApiStatus').textContent='เชื่อมต่อ API และฐานข้อมูลสำเร็จ';$('settingsApiStatus').className='settings-api-status success';await load()}catch(e){$('settingsApiStatus').textContent=`เชื่อมต่อไม่สำเร็จ: ${e.message}`;$('settingsApiStatus').className='settings-api-status error'}};
 $('checkApiBtn').onclick=async()=>{const out=$('settingsApiStatus');out.textContent='กำลังตรวจสอบ...';try{const d=await api('list');out.textContent=`เชื่อมต่อสำเร็จ • API ตอบกลับ ${new Date().toLocaleTimeString('th-TH')} • ${d.items?.length??state.items.length} เรื่อง`;out.className='settings-api-status success'}catch(e){out.textContent=`ตรวจสอบไม่สำเร็จ: ${e.message}`;out.className='settings-api-status error'}};
 $('settingsBackupBtn').onclick=exportBackup;$('settingsExportCsvBtn').onclick=exportCSV;$('settingsRestoreBtn').onclick=()=> $('importFile')?.click();$('openSettingsSources').onclick=()=>{close();openSourceIssues();};$('clearSyncHistory').onclick=()=>{if(confirm('ล้างประวัติซิงก์ที่เก็บในเบราว์เซอร์นี้หรือไม่?')){localStorage.removeItem('manga_sync_history');close();openSettingsCenter()}};
}
function openSourceIssues(){openSourceManager('all');const select=$('sourceMgrHost');if(select){const bad=state.items.find(x=>['error','blocked','partial','unverifiable','review'].includes(x.sync_status));if(bad)select.value=sourceHost(bad.source_url)||'all';select.dispatchEvent(new Event('change'))}}
function setupBulkControls(){
 $('sourceManagerBtn')?.addEventListener('click',()=>openSourceManager());$('bulkEditBtn')?.addEventListener('click',()=>{const visible=filteredItems();visible.forEach(x=>state.selectedIds.add(Number(x.id)));render();showToast(`เลือกผลค้นหาแล้ว • ${visible.length} เรื่อง`)});
 $('libraryGrid')?.addEventListener('change',e=>{const cb=e.target.closest('[data-bulk-select]');if(!cb)return;const id=Number(cb.dataset.bulkSelect);if(cb.checked)state.selectedIds.add(id);else state.selectedIds.delete(id);render()});
 $('bulkToolbar')?.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-bulk-select-visible')){filteredItems().forEach(x=>state.selectedIds.add(Number(x.id)));render();return}if(b.hasAttribute('data-bulk-clear')){state.selectedIds.clear();render();return}if(b.hasAttribute('data-bulk-edit')){openBulkEdit();return}const items=[...state.selectedIds].map(id=>state.items.find(x=>Number(x.id)===id)).filter(Boolean);if(b.hasAttribute('data-bulk-delete')){if(!confirm(`ลบ ${items.length} เรื่องพร้อม Chapter และประวัติการอ่านหรือไม่?`))return;let ok=0,failed=[];for(const x of items){try{await api('delete_manga',{id:Number(x.id)});ok++}catch(err){failed.push(`${x.title}: ${err.message}`)}}state.selectedIds.clear();await refreshAll();showToast(`ลบสำเร็จ ${ok}/${items.length} เรื่อง${failed.length?` • ล้มเหลว ${failed.length}`:''}`,!!failed.length);if(failed.length)alert(failed.slice(0,10).join('\n'));return}if(b.hasAttribute('data-bulk-sync')){for(const x of items){const r=await syncOneForQueue(x,true);if(!r.ok&&!r.skipped)showToast(`${x.title}: ${r.message}`,true)}await refreshAll();showToast(`ประมวลผลซิงก์ ${items.length} เรื่องแล้ว`);return}});
 document.addEventListener('click',e=>{const b=e.target.closest('[data-clear-filter]');if(!b)return;const id=b.dataset.clearFilter;if(id==='search')$('search').value='';else if($(id))$(id).value='all';render()});
}
function setupFilters(){try{const m=localStorage.getItem('mmt_oneshot_mode');if(m&&$('oneshotFilter')&&[...$('oneshotFilter').options].some(o=>o.value===m))$('oneshotFilter').value=m}catch{}$('oneshotFilter')?.addEventListener('change',()=>{try{localStorage.setItem('mmt_oneshot_mode',$('oneshotFilter').value)}catch{}});setupOneshotShelf();buildThemeSwatches();['search','typeFilter','genreFilter','leadFilter','sourceFilter','statusFilter','readFilter','sortFilter','ratingFilter','collectionFilter','oneshotFilter'].forEach(id=>$(id)?.addEventListener('change',render));$('search').addEventListener('input',render);$('copySourceBtn')?.addEventListener('click',copySourceList)}
function setupView(){ $('viewBtn').onclick=()=>{state.libraryListMode=!state.libraryListMode;localStorage.setItem('manga_view_mode',state.libraryListMode?'list':'grid');$('viewBtn').textContent=state.libraryListMode?'▤':'▦';render()};$('viewBtn').textContent=state.libraryListMode?'▤':'▦'}
function autoBackupLocal(){if(!localStorage.getItem('manga_token'))return;const today=new Date().toISOString().slice(0,10),key='manga_auto_backup_day';if(localStorage.getItem(key)===today)return;api('export_all').then(d=>{localStorage.setItem(key,today);localStorage.setItem('manga_auto_backup',JSON.stringify(d.backup))}).catch(()=>{})}

function setupPrimaryNavigation(){
 const links=[...document.querySelectorAll('.desktop-nav a[href^="#"],.bottom-nav a[href^="#"]')];
 const ids=['home','library','continue','sync-center','categories','completed','rewards'];
 const activate=href=>links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')===href));
 let lockUntil=0,ticking=false,idleT=null;
 // เลือกหัวข้อจากตำแหน่งจริงบนหน้าจอ: หัวข้อที่ขอบบนผ่านเส้นอ้างอิงมาแล้ว และอยู่ใกล้เส้นที่สุด (ไม่ขึ้นกับลำดับใน DOM)
 function spy(){
  ticking=false;
  if(Date.now()<lockUntil)return;
  if($('newChapterModal')&&!$('newChapterModal').classList.contains('hidden'))return;
  const probe=(document.querySelector('.header')?.offsetHeight||64)+Math.round(window.innerHeight*.18);
  let best=null,bestTop=-Infinity;
  ids.forEach(id=>{const el=document.getElementById(id);if(!el||el.offsetParent===null&&getComputedStyle(el).position!=='fixed')return;const r=el.getBoundingClientRect();if(r.bottom<=probe)return;if(r.top<=probe&&r.top>bestTop){best=id;bestTop=r.top}});
  if(!best){// ยังไม่มีหัวข้อไหนผ่านเส้น: เลือกอันที่อยู่ใกล้ใต้เส้นที่สุด
   let min=Infinity;ids.forEach(id=>{const el=document.getElementById(id);if(!el)return;const t=el.getBoundingClientRect().top;if(t>probe&&t<min){min=t;best=id}});
  }
  const last=document.getElementById('rewards');if(last&&last.getBoundingClientRect().bottom<=window.innerHeight+6&&last.getBoundingClientRect().top<probe)best='rewards';
  if(best)activate('#'+best);
 }
 const onScroll=()=>{if(Date.now()<lockUntil){clearTimeout(idleT);idleT=setTimeout(()=>{lockUntil=0;spy()},160);return}if(!ticking){ticking=true;requestAnimationFrame(spy)}};
 document.addEventListener('scroll',onScroll,{passive:true,capture:true});
 window.addEventListener('resize',onScroll);
 // คลิกเมนู: เลือกทันทีและหยุด scroll-spy จนกว่าการเลื่อนจะจบ กันไม่ให้เด้งกลับ
 links.forEach(a=>a.addEventListener('click',()=>{activate(a.getAttribute('href'));lockUntil=Date.now()+3000;clearTimeout(idleT);idleT=setTimeout(()=>{lockUntil=0;spy()},3100)}));
 window.addEventListener('hashchange',()=>{if(location.hash)activate(location.hash)});
 if(location.hash)activate(location.hash);else spy();
}

function setupCoverTilt(){
 const finePointer=window.matchMedia?.('(hover: hover) and (pointer: fine)').matches;
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 if(!finePointer||reduced)return;
 let active=null;
 const reset=el=>{if(!el)return;el.style.setProperty('--mmt-cover-rx','0deg');el.style.setProperty('--mmt-cover-ry','0deg');el.style.setProperty('--mmt-cover-x','50%');el.style.setProperty('--mmt-cover-y','50%');el.classList.remove('is-tilting')};
 document.addEventListener('pointermove',e=>{
  if(e.pointerType!=='mouse')return;
  const cover=e.target instanceof Element?e.target.closest('.card-cover.cover-3d'):null;
  if(active&&active!==cover)reset(active);
  active=cover;
  if(!cover)return;
  const r=cover.getBoundingClientRect();if(!r.width||!r.height)return;
  const x=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),y=Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
  cover.style.setProperty('--mmt-cover-rx',`${((.5-y)*9).toFixed(2)}deg`);
  cover.style.setProperty('--mmt-cover-ry',`${((x-.5)*10).toFixed(2)}deg`);
  cover.style.setProperty('--mmt-cover-x',`${(x*100).toFixed(1)}%`);
  cover.style.setProperty('--mmt-cover-y',`${(y*100).toFixed(1)}%`);
  cover.classList.add('is-tilting');
 },{passive:true});
 document.addEventListener('pointerout',e=>{if(active&&e.target instanceof Node&&active.contains(e.target)&&(!e.relatedTarget||!active.contains(e.relatedTarget))){reset(active);active=null}},{passive:true});
}

document.addEventListener('DOMContentLoaded',async()=>{
 setupPrimaryNavigation();setupCoverTilt();setupRatingControl();
 initTheme();
 $('addBtn').onclick=()=>openModal();$('heroAdd').onclick=()=>openModal();$('mobileAdd').onclick=()=>openModal();$('heroNewChapters')?.addEventListener('click',openNewChapterCenter);$('timelineBtn').onclick=openTimeline;$('showFavBtn').onclick=()=>{ $('collectionFilter').value='all';$('readFilter').value='favorite';document.querySelector('#libraryGrid')?.scrollIntoView({behavior:'smooth',block:'start'});render()};$('manageTaxonomyBtn').onclick=openTaxonomy;$('clearFilters').onclick=clearFilters;$('exportBtn')?.addEventListener('click',exportBackup);$('csvBtn')?.addEventListener('click',exportCSV);$('importBtn')?.addEventListener('click',()=>$('importFile')?.click());$('importFile').onchange=e=>{const f=e.target.files?.[0];if(f)restoreBackup(f);e.target.value=''};$('settingsBtn').onclick=openSettingsCenter;$('librarySettingsBtn')?.addEventListener('click',openSettingsCenter);
 $('form').onsubmit=saveManga;const preview=$('previewImportBtn');if(preview)preview.onclick=importPreview;const bi=$('browserImportBtn');if(bi)bi.onclick=()=>openBrowserImport(Number($('mangaId').value||0),$('source').value.trim());
 const bgBrowser=$('backgroundImportBrowser');if(bgBrowser)bgBrowser.onclick=()=>openBrowserImport(Number(bgBrowser.dataset.id||0),bgBrowser.dataset.url||'');const bgDismiss=$('backgroundImportDismiss');if(bgDismiss)bgDismiss.onclick=hideBackgroundImportPanel;
 document.querySelectorAll('[data-close]').forEach(b=>b.onclick=closeModal);document.querySelectorAll('[data-close-taxonomy]').forEach(b=>b.onclick=closeTaxonomy);document.querySelectorAll('[data-close-timeline]').forEach(b=>b.onclick=closeTimeline);document.querySelectorAll('.manager-tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.manager-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('typeManager').classList.toggle('hidden',b.dataset.tab!=='types');$('genreManager').classList.toggle('hidden',b.dataset.tab!=='genres');$('collectionManager').classList.toggle('hidden',b.dataset.tab!=='collections')});
 $('themeBtn').onclick=()=>applyTheme(document.documentElement.dataset.theme==='light'?'dark':'light',true);
 const syncStart=$('syncStartBtn');if(syncStart)syncStart.onclick=()=>startBulkSync(false);
 const syncPreview=$('syncQueuePreview');if(syncPreview)syncPreview.addEventListener('click',async e=>{const b=e.target.closest('[data-sync-preview-one]');if(!b)return;if(syncState.running){showToast('กำลังซิงก์แบบชุดอยู่ กรุณารอให้จบหรือหยุดก่อน',true);return}const id=Number(b.dataset.syncPreviewOne);b.disabled=true;b.textContent='กำลังซิงก์…';try{await syncOne(id)}finally{b.disabled=false;b.textContent='↻ ซิงก์เรื่องนี้'}});
 const syncRetry=$('syncRetryBtn');if(syncRetry)syncRetry.onclick=()=>startBulkSync(true);
  const syncScopeEl=$('syncScope');if(syncScopeEl)syncScopeEl.onchange=()=>{localStorage.setItem('manga_sync_scope',syncScopeEl.value);renderSyncPanel()};
  const syncHostEl=$('syncHost');if(syncHostEl)syncHostEl.onchange=()=>{localStorage.setItem('manga_sync_host',syncHostEl.value);renderSyncPanel()};
  const syncAutoEl=$('syncAuto');if(syncAutoEl)syncAutoEl.onchange=()=>{localStorage.setItem('manga_sync_auto',syncAutoEl.checked?'1':'0');showToast(syncAutoEl.checked?'เปิดซิงก์อัตโนมัติเมื่อเปิดเว็บ (สูงสุด 15 เรื่อง ห่างกันอย่างน้อย 30 นาที)':'ปิดซิงก์อัตโนมัติแล้ว')};
  const syncStrictEl=$('syncStrict');if(syncStrictEl)syncStrictEl.onchange=()=>{localStorage.setItem('manga_sync_strict',syncStrictEl.checked?'1':'0');showToast(syncStrictEl.checked?'ซิงก์หลายเรื่อง: จะเก็บเรื่องที่ดึงไม่ครบไว้ตรวจสอบก่อนบันทึก':'ซิงก์หลายเรื่อง: เรื่องที่ดึงไม่ครบจะบันทึกแบบเพิ่มอย่างเดียว (ไม่ลบของเดิม)')};
  const syncReviewBtn=$('syncReviewBtn');if(syncReviewBtn)syncReviewBtn.onclick=runSyncReviews;
  const syncIssuesBtn=$('syncIssuesBtn');if(syncIssuesBtn)syncIssuesBtn.onclick=()=>openSourceIssues();
 const syncPause=$('syncPauseBtn');if(syncPause)syncPause.onclick=()=>{if(!syncState.running&&syncState.results.length){syncState.results=[];syncState.reviews=[];renderSyncProgress();return}syncState.paused=!syncState.paused;renderSyncProgress()};
 const syncStop=$('syncStopBtn');if(syncStop)syncStop.onclick=()=>{syncState.stop=true;syncState.paused=false;renderSyncProgress()};
 const openNew=$('openNewChapterBtn');if(openNew)openNew.onclick=openNewChapterCenter;
 const closeNew=$('newChapterClose');if(closeNew)closeNew.onclick=closeNewChapterCenter;
 const markAll=$('markAllNewBtn');if(markAll)markAll.onclick=markAllNewSeen;
 const newFilter=$('newChapterFilter');if(newFilter)newFilter.onchange=renderNewChapterCenter;
 const newModal=$('newChapterModal');if(newModal)newModal.addEventListener('click',e=>{if(e.target===newModal)closeNewChapterCenter()});
 document.querySelectorAll('a[href="#new-chapters"]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();openNewChapterCenter()}));
 const cfgBtn=$('syncSaveCfgBtn');if(cfgBtn)cfgBtn.onclick=()=>{setSyncCfg('manga_sync_cooldown_hours',Math.max(0,Number($('syncCooldown').value||6)));setSyncCfg('manga_sync_delay_ms',Math.max(0,Number($('syncDelay').value||1.5)*1000));setSyncCfg('manga_sync_block_limit',Math.max(1,Number($('syncBlockLimit').value||3)));renderSyncPanel();showToast('บันทึกค่าการซิงก์แล้ว')};
 $('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});$('taxonomyModal').addEventListener('click',e=>{if(e.target===$('taxonomyModal'))closeTaxonomy()});$('timelineModal').addEventListener('click',e=>{if(e.target===$('timelineModal'))closeTimeline()});
 if(location.hash==='#new-chapters')openNewChapterCenter();
 applyBookmarkImport();
 $('typePicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick-type]');if(!b)return;document.querySelectorAll('[data-pick-type]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});$('genrePicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick-genre]');if(b)toggleTagsSelector('genrePicker','genre',Number(b.dataset.pickGenre))});$('collectionPicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick-collection]');if(b)toggleTagsSelector('collectionPicker','collection',Number(b.dataset.pickCollection))});$('leadPicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick-lead]');if(!b)return;document.querySelectorAll('[data-pick-lead]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});$('completionPicker').addEventListener('click',e=>{const b=e.target.closest('[data-pick-completion]');if(!b)return;document.querySelectorAll('[data-pick-completion]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
 $('status').onchange=()=>{}; $('importStatus').addEventListener('dblclick',importPreview); if($('rewardClose'))$('rewardClose').onclick=closeRewardModal; if($('rewardModal'))$('rewardModal').addEventListener('click',e=>{if(e.target===$('rewardModal'))closeRewardModal()}); if($('rewardModalKeep'))$('rewardModalKeep').onclick=closeRewardModal; if($('viewRewardsBtn'))$('viewRewardsBtn').onclick=()=>location.hash='rewards';
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)load()});setInterval(()=>{if(!document.hidden)load()},45000);
 setupFilterLayout();setupBulkControls();setupView();setupFilters();await load();setTimeout(autoBackupLocal,1600);setTimeout(maybeAutoSync,2600);
});

;(function(){
 document.addEventListener('click',e=>{const l=e.target.closest('a[href="#home"]');if(l){e.preventDefault();window.scrollTo({top:0,behavior:'smooth'});return}const r=e.target.closest('a[href="#recent"]');if(r){e.preventDefault();$('continue')?.scrollIntoView({behavior:'smooth',block:'start'})}});
})();

/* v17.3: Mobile Dock (พอร์ตแนวคิดจาก 21st.dev dock-two) — ป้ายชื่อของปุ่มที่ใช้งานอยู่ + tooltip เมื่อแตะค้าง/โฮเวอร์ */
(function(){
 function init(){
  document.querySelectorAll('.bottom-nav > a, .bottom-nav > button').forEach(el=>{
   const label=(el.querySelector('small')?.textContent||el.getAttribute('aria-label')||'').trim();
   if(label){el.dataset.label=label;if(!el.getAttribute('aria-label'))el.setAttribute('aria-label',label)}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* v17.4: Search suggestions — รายการเรื่องที่ชื่อคล้าย/ใกล้เคียงใต้ช่องค้นหา (แนวคิดจาก 21st.dev action-search-bar)
   รองรับพิมพ์ผิดเล็กน้อย พิมพ์คำไม่ครบ สลับลำดับคำ ทั้งมือถือและคอมพิวเตอร์ */
(function(){
 const MAX_DESK=8,MAX_MOB=6;
 let box=null,activeIdx=-1,list=[],timer=null;
 const norm=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/[’'`´]/g,'').replace(/[^\p{L}\p{N}\p{M}]+/gu,' ').trim();
 function lev(a,b,max){ // Levenshtein แบบตัดเร็วเมื่อเกิน max
  if(Math.abs(a.length-b.length)>max)return max+1;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++){const cur=[i];let rowMin=i;for(let j=1;j<=b.length;j++){const v=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));cur[j]=v;if(v<rowMin)rowMin=v}if(rowMin>max)return max+1;prev=cur}
  return prev[b.length];
 }
 function subseq(q,t){let i=0;for(const c of t){if(c===q[i])i++;if(i===q.length)return true}return false}
 function scoreText(q,qt,text){
  if(!text)return 0;
  if(text===q)return 1000;
  if(text.startsWith(q))return 900-Math.min(text.length-q.length,60)*.5;
  const words=text.split(' ');
  if(words.some(w=>w.startsWith(q)))return 800-text.indexOf(q);
  const pos=text.indexOf(q);if(pos>=0)return 700-Math.min(pos,100)*.5;
  // ทุกคำที่พิมพ์ต้องเจอ (ลำดับใดก็ได้ / พิมพ์ผิดได้เล็กน้อย)
  let total=0;
  for(const t of qt){
   let best=0;
   for(const w of words){
    if(w.startsWith(t)){best=Math.max(best,300);continue}
    if(w.includes(t)){best=Math.max(best,240);continue}
    if(t.length>=3){
     const max=t.length>=7?2:1;
     const d=Math.min(lev(t,w,max),lev(t,w.slice(0,t.length),max));
     if(d<=max)best=Math.max(best,200-d*50);
    }
   }
   if(!best&&t.length>=5&&subseq(t,text.replace(/ /g,'')))best=90;
   if(!best)return 0;
   total+=best;
  }
  return 400+total/qt.length;
 }
 function suggest(query){
  const q=norm(query);if(q.length<1)return [];
  const qt=q.split(' ').filter(Boolean);
  const out=[];
  for(const x of (state.items||[])){
   const s=Math.max(scoreText(q,qt,norm(x.title)),scoreText(q,qt,norm(x.alt_title))*.97);
   if(s>0)out.push({x,s:s+(Number(x.favorite)?3:0)});
  }
  return out.sort((a,b)=>b.s-a.s||String(a.x.title).length-String(b.x.title).length);
 }
 function hl(text,query){
  const t=String(text||''),q=String(query||'').trim();if(!q)return esc(t);
  const i=t.toLowerCase().indexOf(q.toLowerCase());
  if(i<0)return esc(t);
  return esc(t.slice(0,i))+'<mark>'+esc(t.slice(i,i+q.length))+'</mark>'+esc(t.slice(i+q.length));
 }
 function ensureBox(){
  if(box)return box;
  box=document.createElement('div');box.id='searchSuggest';box.className='search-suggest hidden';box.setAttribute('role','listbox');
  document.body.appendChild(box);
  box.addEventListener('mousedown',e=>e.preventDefault());
  return box;
 }
 function place(){
  const input=$('search');if(!input||!box)return;
  const r=(input.closest('.search-box')||input).getBoundingClientRect();
  const vw=window.innerWidth,mobile=vw<=780;
  const top=Math.round(r.bottom+8);
  box.style.top=top+'px';
  if(mobile){box.style.left='10px';box.style.right='10px';box.style.width='auto'}
  else{const w=Math.min(560,vw-24);const left=Math.max(12,Math.min(r.left,vw-w-12));box.style.left=left+'px';box.style.right='auto';box.style.width=w+'px'}
  box.style.maxHeight=Math.max(200,window.innerHeight-top-(mobile?96:24))+'px';
 }
 function close(){if(box){box.classList.add('hidden');box.innerHTML=''}activeIdx=-1;list=[]}
 function row(m,q,i){
  const x=m.x,ch=x.last_chapter||x.latest_chapter||'',g=(typeof genreNames==='function'?genreNames(x):[]).slice(0,4).join(', ');
  const cover=isVideoCover(x.cover_url)?videoCoverHtml(x.cover_url,'','autoplay'):x.cover_url?`<img src="${esc(x.cover_url)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'ss-ph',textContent:'${esc(String(x.title||'?').trim().charAt(0)).replace(/'/g,'')}'}))">`:`<span class="ss-ph">${esc(String(x.title||'?').trim().charAt(0))}</span>`;
  const badge=Number(x.new_chapter_count||0)>0?`<b class="ss-new">+${Number(x.new_chapter_count)} ตอนใหม่</b>`:'';
  return `<a class="ss-item${i===activeIdx?' active':''}" style="animation-delay:${i*45}ms" role="option" href="manga.html?id=${Number(x.id)}" data-ss="${i}"><span class="ss-cover">${cover}</span><span class="ss-body"><span class="ss-title">${hl(x.title,q)}</span><span class="ss-meta">${ch?`<i>Ch. ${esc(ch)}</i>`:''}${badge}${Number(x.favorite)?'<i>★</i>':''}</span>${g?`<span class="ss-genres">${esc(g)}</span>`:''}</span></a>`;
 }
 function render(){
  const input=$('search');if(!input)return;
  const query=input.value;
  if(!norm(query)){close();return}
  ensureBox();
  const res=suggest(query);
  const max=window.innerWidth<=780?MAX_MOB:MAX_DESK;
  list=res.slice(0,max);
  place();
  box.classList.remove('hidden');
  if(!list.length){box.innerHTML=`<div class="ss-empty">ไม่พบเรื่องที่ใกล้เคียงกับ “${esc(query.trim())}”<small>ลองพิมพ์ชื่อบางส่วน หรือสะกดต่างออกไป</small></div>`;return}
  const more=res.length>list.length?`<button type="button" class="ss-more" data-ss-all>ดูทั้งหมด ${res.length} เรื่องในคลัง</button>`:`<button type="button" class="ss-more" data-ss-all>ดูผลลัพธ์ ${res.length} เรื่องในคลัง</button>`;
  box.innerHTML=list.map((m,i)=>row(m,query.trim(),i)).join('')+more;
 }
 function setActive(i){
  activeIdx=i;
  box?.querySelectorAll('.ss-item').forEach((el,k)=>{el.classList.toggle('active',k===i);if(k===i)el.scrollIntoView({block:'nearest'})});
 }
 function init(){
  const input=$('search');if(!input||input.dataset.ssBound)return;input.dataset.ssBound='1';
  input.setAttribute('autocomplete','off');input.setAttribute('aria-autocomplete','list');
  input.addEventListener('input',()=>{input.closest('.search-box')?.classList.toggle('has-q',!!input.value.trim());clearTimeout(timer);timer=setTimeout(render,70)});
  input.addEventListener('focus',()=>{if(norm(input.value))render()});
  input.addEventListener('keydown',e=>{
   if(!box||box.classList.contains('hidden')){return}
   if(e.key==='ArrowDown'){e.preventDefault();setActive(Math.min(list.length-1,activeIdx+1))}
   else if(e.key==='ArrowUp'){e.preventDefault();setActive(Math.max(0,activeIdx-1))}
   else if(e.key==='Enter'){if(activeIdx>=0&&list[activeIdx]){e.preventDefault();location.href='manga.html?id='+Number(list[activeIdx].x.id)}else{close();input.blur();$('library')?.scrollIntoView({behavior:'smooth',block:'start'})}}
   else if(e.key==='Escape'){close()}
  });
  document.addEventListener('click',e=>{
   if(e.target.closest('[data-ss-all]')){close();$('search')?.blur();$('library')?.scrollIntoView({behavior:'smooth',block:'start'});return}
   if(e.target===input||e.target.closest('#searchSuggest'))return;
   close();
  });
  window.addEventListener('resize',()=>{if(box&&!box.classList.contains('hidden'))place()});
  window.addEventListener('scroll',()=>{if(box&&!box.classList.contains('hidden'))place()},{passive:true});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


/* ===== v17.3: Semantic Duplicate Guard ===== */
function dupNorm(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim()}
function dupLev(a,b){if(a===b)return 0;if(!a.length)return b.length;if(!b.length)return a.length;let p=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const c=[i];for(let j=1;j<=b.length;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c}return p[b.length]}
function dupSim(a,b){const m=Math.max(a.length,b.length);return m?1-dupLev(a,b)/m:0}
function dupUrl(u){try{const x=new URL(String(u).trim()),host=x.hostname.toLowerCase().replace(/^www\./,''),path=decodeURIComponent(x.pathname).replace(/\/+$/,'').toLowerCase(),segs=path.split('/').filter(Boolean);let slug=segs[segs.length-1]||'';if(/^\d+(?:\.\d+)?$/.test(slug)&&segs.length>1)slug=segs[segs.length-2];slug=slug.replace(/\.(html?|php)$/,'').replace(/-?(?:chapter|ch|episode|ep)-?\d+.*$/,'').replace(/[-_]+/g,' ').replace(/\s+\d{4,}$/,'').trim();return{host,path,slug:dupNorm(slug),key:host+path}}catch{return{host:'',path:'',slug:'',key:''}}}
function dupCoverKey(u){try{const x=new URL(String(u).trim());return{full:(x.hostname+x.pathname).toLowerCase(),file:(x.pathname.split('/').pop()||'').toLowerCase().replace(/[-_]?\d{2,4}x\d{2,4}/,'')}}catch{return{full:'',file:''}}}
function dupSeason(t){const s=dupNorm(t),m=s.match(/(?:season|ss|part|ภาค|ซีซั่น|ซีซัน)\s*(\d+)|\b(?:ii|iii|iv)\b|\s(\d{1,2})$/);if(!m)return 1;if(m[1])return Number(m[1]);if(m[2])return Number(m[2]);return({ii:2,iii:3,iv:4}[m[0].trim()]||1)}
function dupStripSeason(t){return dupNorm(t).replace(/(?:season|ss|part|ภาค|ซีซั่น|ซีซัน)\s*\d+|\b(?:ii|iii|iv)\b|\s\d{1,2}$/g,'').replace(/\s+/g,' ').trim()}
const DUP_STOP_WORDS=new Set('a an and are as at be been being by for from has have had he her hers him his i in into is it its me my of on or our ours she that the their theirs them they this those to was we were what when where which who with you your yours manga manhwa webtoon comic story official'.split(' '));
function dupMeaningTokens(value){return dupNorm(value).split(/\s+/).filter(Boolean).map(w=>w==='wives'?'wife':w.length>4&&w.endsWith('ies')?w.slice(0,-3)+'y':w.length>4&&w.endsWith('s')&&!w.endsWith('ss')?w.slice(0,-1):w).filter(w=>w.length>1&&!DUP_STOP_WORDS.has(w)&&!/^\d+$/.test(w))}
function dupTokenScore(a,b){const A=[...new Set(dupMeaningTokens(a))],B=[...new Set(dupMeaningTokens(b))];if(!A.length||!B.length)return{score:0,equal:false,common:0,jaccard:0,aTokens:A,bTokens:B};const common=A.filter(w=>B.includes(w)),jaccard=common.length/(A.length+B.length-common.length),equal=A.length===B.length&&common.length===A.length;let score=equal?.995:(common.length?2*common.length/(A.length+B.length):0);if(!equal&&common.length>=3&&Math.min(A.length,B.length)>=3&&jaccard>=.5)score=Math.max(score,Math.min(.93,.7+jaccard*.28));if(!equal&&common.length>=2&&Math.min(A.length,B.length)>=2&&jaccard>=.67)score=Math.max(score,.74);return{score,equal,common:common.length,jaccard,aTokens:A,bTokens:B}}
function dupTitleSim(a,b){const ra=dupNorm(a),rb=dupNorm(b);if(!ra||!rb)return{s:0,kind:''};if(ra===rb)return{s:1,kind:'ชื่อเหมือนกัน'};const sa=dupStripSeason(ra),sb=dupStripSeason(rb),tokens=dupTokenScore(sa,sb);let s=dupSim(sa,sb),kind='ชื่อคล้ายกัน';if(tokens.equal&&tokens.aTokens.length>=2){s=Math.max(s,.99);kind='คำหลักเดียวกันแม้เรียงคำต่างกัน'}else if(tokens.common>=3&&tokens.jaccard>=.5){s=Math.max(s,tokens.score);kind='คำหลักของชื่อเรื่องตรงกันหลายคำ'}else if(tokens.common>=2&&tokens.jaccard>=.67){s=Math.max(s,Math.min(.79,tokens.score));kind='ชื่อมีคำหลักร่วมกัน'}const ta=sa.split(' ').filter(w=>w.length>1),tb=sb.split(' ').filter(w=>w.length>1);if(ta.length>=2&&tb.length>=2){const small=ta.length<=tb.length?ta:tb,big=ta.length<=tb.length?tb:ta,hit=small.filter(w=>big.some(v=>v===w||(w.length>3&&dupSim(w,v)>=.82))).length,c=hit/small.length;if(c>=.99&&s<.9){s=Math.max(s,.82);kind='ชื่อหนึ่งอยู่ในอีกชื่อ'}else if(c>=.75)s=Math.max(s,.6+c*.2)}if(sa===sb&&ra!==rb){s=Math.max(s,.9);kind='ชื่อเหมือนกันต่างเลขภาค'}return{s,kind}}
function dupTitleFields(obj,slug){const raw=[obj?.title,obj?.alt_title,obj?.source_title,obj?.imported_title,slug].filter(Boolean),all=[];for(const v of raw)for(const bit of String(v).split(/[|;\n]+/).map(t=>t.trim()).filter(Boolean))if(!all.some(a=>dupNorm(a)===dupNorm(bit)))all.push(bit);return all}
function dupAnalyze(c,x){
 const reasons=[],pts=[],cu=dupUrl(c.source_url),xu=dupUrl(x.source_url);
 if(cu.key&&xu.key&&cu.key===xu.key){pts.push(100);reasons.push('URL เดียวกัน')}
 else if(cu.host&&cu.host===xu.host&&cu.slug&&cu.slug===xu.slug){pts.push(92);reasons.push('เว็บเดียวกันและ slug ตรงกัน')}
 else if(cu.slug&&xu.slug){const us=dupTokenScore(cu.slug,xu.slug);if(us.equal&&us.aTokens.length>=2){pts.push(88);reasons.push('คำหลักใน URL ตรงกันแม้ต่างเว็บ/เรียงคำต่างกัน')}else if(us.common>=3&&us.jaccard>=.5){pts.push(58);reasons.push('คำหลักใน URL ใกล้เคียงกัน')}else{const sm=dupSim(cu.slug,xu.slug);if(sm>=.85&&Math.min(cu.slug.length,xu.slug.length)>=8){pts.push(48);reasons.push('slug ใน URL คล้ายกัน')}}}
 const ca=dupTitleFields(c,cu.slug),xa=dupTitleFields(x,xu.slug);let best={s:0,kind:''};for(const a of ca)for(const b of xa){const v=dupTitleSim(a,b);if(v.s>best.s)best=v}
 if(best.s>=.97){pts.push(66);reasons.push(best.kind||'ชื่อเรื่องตรงกัน')}else if(best.s>=.85){pts.push(54);reasons.push(best.kind||'ชื่อเรื่องใกล้เคียงมาก')}else if(best.s>=.7){pts.push(34);reasons.push(best.kind||'ชื่อคล้ายกัน')}
 const cc=dupCoverKey(c.cover_url),xc=dupCoverKey(x.cover_url);if(cc.full&&cc.full===xc.full){pts.push(72);reasons.push('ใช้รูปปกเดียวกัน')}else if(cc.file&&cc.file.length>=14&&cc.file===xc.file){pts.push(50);reasons.push('ชื่อไฟล์รูปปกตรงกัน')}
 const n1=Number(c.chapter_count||c.total_chapters||0),n2=Number(x.chapter_count||x.total_chapters||0),l1=chapterNum(c.last_chapter||c.latest_chapter),l2=chapterNum(x.last_chapter||x.latest_chapter);if(n1>=5&&n2>=5&&Math.abs(n1-n2)<=Math.max(2,Math.round(Math.max(n1,n2)*.08))&&l1>0&&l2>0&&Math.abs(l1-l2)<=Math.max(2,Math.round(Math.max(l1,l2)*.08))){pts.push(22);reasons.push(`จำนวนตอนใกล้เคียง (${n1}/${n2})`)}
 const g1=new Set((c.genre_names||[]).map(dupNorm)),g2=new Set(genreNames(x).map(dupNorm));if(g1.size&&g2.size){let cm=0;for(const v of g1)if(g2.has(v))cm++;const j=cm/(g1.size+g2.size-cm);if(j>=.6&&cm>=2){pts.push(12);reasons.push('แนวเรื่องตรงกัน')}}
 if(!pts.length)return{score:0,level:'',reasons:[]};pts.sort((a,b)=>b-a);let score=pts[0]+.35*pts.slice(1).reduce((a,b)=>a+b,0);const s1=dupSeason(c.title||cu.slug),s2=dupSeason(x.title||xu.slug);if(s1!==s2&&!(cu.key&&cu.key===xu.key)){score-=28;reasons.push(`เลขภาคต่างกัน (${s1}/${s2})`)}score=Math.max(0,Math.min(100,Math.round(score)));const level=score>=85?'sure':score>=62?'likely':score>=42?'maybe':'';return{score,level,reasons:[...new Set(reasons)]}
}
function dupFind(c,excludeId=0){const out=[];for(const x of state.items||[]){if(excludeId&&Number(x.id)===Number(excludeId))continue;const r=dupAnalyze(c,x);if(r.level)out.push({x,...r})}return out.sort((a,b)=>b.score-a.score).slice(0,5)}
const DUP_LABEL={sure:'น่าจะเป็นเรื่องเดียวกัน',likely:'มีโอกาสซ้ำ',maybe:'ควรตรวจสอบ'};
function dupCardHTML(m,index=0){const x=m.x,ch=x.last_chapter||x.latest_chapter,cover=isVideoCover(x.cover_url)?videoCoverHtml(x.cover_url,'','autoplay'):x.cover_url?`<img src="${esc(x.cover_url)}" alt="" referrerpolicy="no-referrer" loading="lazy" onerror="this.style.visibility='hidden'">`:'';return `<div class="dup-card dup-${m.level}"><span class="dup-cover">${cover}</span><div class="dup-body"><div class="dup-top"><b>${esc(x.title)}</b><em class="dup-badge">${DUP_LABEL[m.level]} • ${m.score}/100</em></div><small>${esc(sourceHost(x.source_url)||'')}${ch?` • Ch. ${esc(ch)}`:''}${Number(x.chapter_count)?` • ${Number(x.chapter_count)} ตอนในคลัง`:''}</small><div class="dup-reasons">${m.reasons.map(r=>`<span>${esc(r)}</span>`).join('')}</div><div class="dup-card-actions"><label class="dup-match-choice"><input type="radio" name="dupMatch" value="${Number(x.id)}" ${index===0?'checked':''}><span>เลือกเรื่องนี้</span></label><a class="dup-open" href="manga.html?id=${Number(x.id)}" target="_blank" rel="noopener">ดูรายละเอียด ↗</a></div></div></div>`}
function dupDialog({title,intro,matches,primary,secondary,tertiary}){return new Promise(resolve=>{const modal=document.createElement('div');modal.className='modal dup-modal';modal.style.zIndex=300;modal.innerHTML=`<div class="modal-box dup-box" role="dialog" aria-modal="true"><div class="section-kicker">DUPLICATE GUARD</div><h2>${esc(title)}</h2><p class="modal-note">${intro}</p><div class="dup-semantic-note">ตรวจชื่อหลัก/ชื่อรอง, URL slug จากต่างเว็บ, คำหลักหลังตัดคำเติมและสลับลำดับ, ปก, จำนวนตอน/ตอนล่าสุด และแนวเรื่อง ระบบใช้คะแนนช่วยตัดสินใจ ไม่ใช่การยืนยันอัตโนมัติ 100%</div><div class="dup-list">${matches.map(dupCardHTML).join('')}</div><div class="dup-actions">${tertiary?`<button type="button" class="btn ghost" data-dup="tertiary">${esc(tertiary)}</button>`:''}<button type="button" class="btn ghost" data-dup="secondary">${esc(secondary)}</button><button type="button" class="btn dup-primary" data-dup="primary">${esc(primary)}</button></div></div>`;document.body.appendChild(modal);const done=action=>{const matchId=Number(modal.querySelector('input[name=dupMatch]:checked')?.value||matches[0]?.x?.id||0);modal.remove();document.removeEventListener('keydown',onKey);resolve({action,matchId})};const onKey=e=>{if(e.key==='Escape')done(tertiary?'tertiary':'secondary')};document.addEventListener('keydown',onKey);modal.addEventListener('click',e=>{const b=e.target.closest('[data-dup]');if(b)done(b.dataset.dup);else if(e.target===modal)done(tertiary?'tertiary':'secondary')})})}
async function duplicateGuardBeforeAdd(payload){
 const pv=window.__importPreview&&window.__importPreview.url===payload.source_url?window.__importPreview:null,cand={title:payload.title||pv?.title||'',alt_title:payload.alt_title,source_title:pv?.title||'',source_url:payload.source_url,cover_url:payload.cover_url||pv?.cover||'',chapter_count:pv?.chapter_count||0,total_chapters:pv?.total||0,last_chapter:pv?.last||'',genre_names:[...(pv?.genres||[])]};
 const matches=dupFind(cand).filter(m=>m.score>=42);if(!matches.length)return{action:'add'};const sure=matches.some(m=>m.level==='sure');
 const r=await dupDialog({title:sure?'พบเรื่องที่น่าจะซ้ำในคลัง':'พบเรื่องที่อาจซ้ำในคลัง',intro:'ระบบจะตรวจจากชื่อ, ชื่อรอง, slug, ปก, จำนวนตอน และแนว ก่อนบันทึกกรุณาเลือกว่าจะใช้เรื่องเดิม เพิ่มเป็นอีกเรื่อง หรือยกเลิก',matches,primary:'ใช้เรื่องเดิม + เปลี่ยน URL ต้นทาง',secondary:'เป็นคนละเรื่อง • เพิ่มใหม่',tertiary:'ยกเลิก'});const match=matches.find(m=>Number(m.x.id)===r.matchId)||matches[0];
 if(r.action==='primary')return{action:'reuse',match:match.x};if(r.action==='secondary'){markDuplicateAcknowledgement(payload.source_url);return{action:'add',acknowledged:true}}return{action:'cancel'};
}
async function resolveImportedDuplicate(id,url,imp,meta={}){
 if(meta.skipDuplicatePrompt||hasDuplicateAcknowledgement(url))return{action:'continue'};const current=(state.items||[]).find(v=>Number(v.id)===Number(id));const cand={...(current||{}),title:current?.title||meta.title||imp?.title||'',alt_title:appendTitleAliases(current?.alt_title,current?.title,meta.title,meta.alt_title,imp?.title),source_title:imp?.title||'',imported_title:imp?.title||'',source_url:url,cover_url:imp?.cover_url||current?.cover_url||'',chapter_count:Number(imp?.chapter_count||imp?.chapters?.length||current?.chapter_count||0),total_chapters:Number(imp?.total_chapters||0),last_chapter:importChapterLabel(imp)||current?.last_chapter||'',genre_names:Array.isArray(imp?.genres)?imp.genres:genreNames(current||{})};
 const matches=dupFind(cand,Number(id)).filter(m=>m.score>=42);if(!matches.length)return{action:'continue'};const result=await dupDialog({title:'หลังอ่านเว็บต้นทาง พบว่าอาจเป็นเรื่องซ้ำ',intro:`ระบบพบรายการที่อาจเป็นเรื่องเดียวกับ “${esc(cand.title)}” ก่อนบันทึก Chapter เลือกว่าจะรวมเรื่อง เก็บทั้งสอง หรือยกเลิกรายการใหม่`,matches,primary:'รวมเข้ากับเรื่องเดิม',secondary:'เก็บทั้งสองเรื่อง',tertiary:'ยกเลิกรายการใหม่'});const match=matches.find(m=>Number(m.x.id)===result.matchId)||matches[0];
 if(result.action==='primary')return{action:'reuse',match:match.x};if(result.action==='secondary'){markDuplicateAcknowledgement(url);return{action:'continue'}}return{action:'cancel'};
}
async function runNewMangaBackgroundImport(id,url,meta={}){return _runNewMangaBackgroundImportCore(id,url,meta)}



/* v17.7.0 — keep cover motion light by animating visible covers only. */
(function initMmtVisibleCoverMotion(){
  if(!('IntersectionObserver' in window))return;
  const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce)return;
  const selector='.card-cover, .new-chapter-cover, .tcg-art-layer, .tcg-back-art-cover';
  const observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>entry.target.classList.toggle('mmt-motion-visible',entry.isIntersecting));
    entries.forEach(entry=>{const perf=document.documentElement.classList.contains('mmt-performance-mode');entry.target.querySelectorAll('video[data-cover-video]').forEach(v=>{try{if(entry.isIntersecting&&!perf)v.play().catch(()=>{});else v.pause()}catch{}})});
  },{rootMargin:'80px 0px',threshold:0.01});
  const scan=root=>{
    if(!root)return;
    if(root.nodeType===1&&root.matches&&root.matches(selector))observer.observe(root);
    if(root.querySelectorAll)root.querySelectorAll(selector).forEach(el=>observer.observe(el));
  };
  scan(document);
  const mutations=new MutationObserver(records=>records.forEach(record=>record.addedNodes.forEach(node=>{if(node.nodeType===1)scan(node)})));
  if(document.body)mutations.observe(document.body,{childList:true,subtree:true});
})();


// =====================================================================
// v17.17.10 — Sync Manage: แยกเรื่อง รอซิงก์ / ต้องตรวจสอบ / ซิงก์แล้ว (ตั้งค่าได้)
// =====================================================================
const SM_KEYS={unv:'manga_sync_unv_ok',group:'manga_sync_group_host',page:'manga_sync_page_size',tab:'manga_sync_tab',sort:'manga_sync_sort'};
function smUnvOk(){return localStorage.getItem(SM_KEYS.unv)!=='0'}
function smGroupHost(){return localStorage.getItem(SM_KEYS.group)==='1'}
function smPageSize(){const n=Number(localStorage.getItem(SM_KEYS.page)||30);return [20,30,50,100].includes(n)?n:30}
function smIsIssue(x){const s=x.sync_status;return ['error','blocked','partial','review'].includes(s)||(s==='unverifiable'&&!smUnvOk())}
const SM_CAUSE={
  blocked:{icon:'⛔',label:'เว็บบล็อก',tip:'เว็บต้นทางปฏิเสธ (403/429) → ใช้ ⚡ Browser Import'},
  error:{icon:'✖',label:'ล้มเหลว',tip:'ซิงก์ไม่สำเร็จ → ลองซิงก์ซ้ำ หรือใช้ ⚡ Browser Import'},
  partial:{icon:'🔸',label:'ดึงไม่ครบ',tip:'ดึงตอนได้น้อยกว่าที่เว็บแจ้ง → ซิงก์ซ้ำภายหลัง'},
  review:{icon:'⚠',label:'เลขตอนผิดปกติ',tip:'เปิดดูและเทียบกับเว็บต้นทาง ถ้าตรงให้กด ✔ ปกติ'},
  unverifiable:{icon:'❔',label:'ยืนยันจำนวนไม่ได้',tip:'เว็บไม่บอกจำนวนตอนทั้งหมด มักไม่เป็นไร ถ้าตอนครบแล้วกด ✔ ปกติ'}
};
const smState={tab:localStorage.getItem(SM_KEYS.tab)||'due',cat:'all',limit:0,q:''};
function smItems(){const p=syncPrefs();return syncScopeItems(p.scope,syncActiveHost())}
function smBuckets(){
  const c=syncCfg(),all=smItems(),issue=[],due=[],synced=[];
  all.forEach(x=>{if(smIsIssue(x))issue.push(x);else if(syncDue(x,c.cooldownHours))due.push(x);else synced.push(x)});
  return {issue,due,synced,c};
}
function smSortList(list,tab){
  const mode=localStorage.getItem(SM_KEYS.sort)||'recent';
  const ts=x=>{const v=x.last_sync_at?new Date(String(x.last_sync_at).replace(' ','T')).getTime():0;return Number.isFinite(v)?v:0};
  const a=[...list];
  if(mode==='title')a.sort((x,y)=>String(x.title).localeCompare(String(y.title),'th'));
  else if(mode==='new')a.sort((x,y)=>newCount(y)-newCount(x)||ts(y)-ts(x));
  else if(tab==='due')return orderSyncQueue(a);
  else a.sort((x,y)=>ts(y)-ts(x));
  return a;
}
function smWhen(x){if(!x.last_sync_at)return 'ยังไม่เคยซิงก์';return 'ซิงก์ '+timeAgo(x.last_sync_at)}
function smRowHTML(x,tab){
  const id=Number(x.id),host=sourceHost(x.source_url)||'ไม่ทราบเว็บ',nc=newCount(x),cause=SM_CAUSE[x.sync_status];
  const meta=[esc(host),esc(smWhen(x)),`ล่าสุด ${esc(x.last_chapter||x.latest_chapter||'-')}`].join(' · ');
  const warn=tab==='issue'&&cause?`<div class="sm-warn"><b>${cause.icon} ${esc(cause.label)}</b>${x.sync_error?` — ${esc(String(x.sync_error).slice(0,160))}`:''}<small>${esc(cause.tip)}</small></div>`:'';
  const note=tab==='synced'&&x.sync_status==='unverifiable'?'<span class="sm-tag">ยืนยันจำนวนไม่ได้</span>':'';
  const badge=nc>0?`<span class="sm-new">🆕 +${nc}</span>`:'';
  const canImport=['blocked','error','unverifiable','partial'].includes(x.sync_status);
  const canOk=tab==='issue'&&x.sync_status!=='blocked';
  const acts=`<button class="btn ghost" type="button" data-sm-sync="${id}">↻ ซิงก์</button>`
    +(tab==='issue'&&canImport?`<button class="btn ghost" type="button" data-sm-import="${id}">⚡ Browser Import</button>`:'')
    +(canOk?`<button class="btn ghost" type="button" data-sm-ok="${id}">✔ ปกติ</button>`:'')
    +(x.source_url?`<a class="btn ghost" href="${esc(x.source_url)}" target="_blank" rel="noopener">↗ ต้นทาง</a>`:'');
  return `<div class="sm-row sm-${tab}"><div class="sm-main"><i class="sync-queue-dot ${x.status==='reading'?'reading':''}"></i><div class="sm-text"><a class="sm-title" href="manga.html?id=${id}" title="${esc(x.title)}">${esc(x.title)}</a>${badge}${note}<small>${meta}</small>${warn}</div></div><div class="sm-actions">${acts}</div></div>`;
}
function renderSyncManage(){
  const box=$('syncManage');if(!box)return;
  const B=smBuckets(),tab=['due','issue','synced'].includes(smState.tab)?smState.tab:'due';
  const cnt={due:B.due.length,issue:B.issue.length,synced:B.synced.length};
  Object.entries({due:'smCntDue',issue:'smCntIssue',synced:'smCntSynced'}).forEach(([k,id])=>{if($(id))$(id).textContent=String(cnt[k])});
  box.querySelectorAll('[data-sm-tab]').forEach(b=>{const on=b.dataset.smTab===tab;b.classList.toggle('on',on);b.setAttribute('aria-selected',on?'true':'false')});
  const hrs=B.c.cooldownHours;
  const desc={
    due:`เรื่องที่ถึงเวลาซิงก์ (ยังไม่เคยซิงก์ หรือเกิน ${hrs} ชม.) — กด “เริ่มซิงก์” ด้านบนเพื่อซิงก์ทั้งคิว`,
    issue:'เรื่องที่ซิงก์แล้วแต่มีปัญหา เลือกจัดการทีละเรื่อง หรือกดปุ่มด้านล่างจัดการทั้งกลุ่ม',
    synced:`เรื่องที่ซิงก์สำเร็จภายใน ${hrs} ชม.ล่าสุด — ระบบจะข้ามในรอบถัดไป (ปรับชั่วโมงได้ที่ “ตั้งค่าการแยกเรื่อง”)`
  }[tab];
  if($('smDesc'))$('smDesc').textContent=desc;
  // settings fields (do not overwrite while typing)
  const act=document.activeElement;
  if($('smDoneHours')&&act!==$('smDoneHours'))$('smDoneHours').value=hrs;
  if($('smUnvOk'))$('smUnvOk').checked=smUnvOk();
  if($('smGroupHost'))$('smGroupHost').checked=smGroupHost();
  if($('smPageSize'))$('smPageSize').value=String(smPageSize());
  if($('smSort'))$('smSort').value=localStorage.getItem(SM_KEYS.sort)||'recent';
  // list
  let list=B[tab];
  const chipsEl=$('smChips');
  if(tab==='issue'){
    const causes={};list.forEach(x=>{causes[x.sync_status]=(causes[x.sync_status]||0)+1});
    if(smState.cat!=='all'&&!causes[smState.cat])smState.cat='all';
    const keys=Object.keys(causes).sort((a,b)=>causes[b]-causes[a]);
    chipsEl.classList.toggle('hidden',!keys.length);
    chipsEl.innerHTML=keys.length?`<button type="button" class="sm-chip${smState.cat==='all'?' on':''}" data-sm-cat="all">ทั้งหมด ${list.length}</button>`+keys.map(k=>`<button type="button" class="sm-chip${smState.cat===k?' on':''}" data-sm-cat="${k}">${SM_CAUSE[k]?.icon||'•'} ${esc(SM_CAUSE[k]?.label||k)} ${causes[k]}</button>`).join(''):'';
    if(smState.cat!=='all')list=list.filter(x=>x.sync_status===smState.cat);
  }else{chipsEl.classList.add('hidden');chipsEl.innerHTML=''}
  const q=smState.q.trim().toLowerCase();
  if(q)list=list.filter(x=>`${x.title||''} ${x.alt_title||''} ${sourceHost(x.source_url)||''}`.toLowerCase().includes(q));
  list=smSortList(list,tab);
  if($('syncPreviewCount'))$('syncPreviewCount').textContent=`${list.length} เรื่อง`;
  // bulk actions
  const bulk=$('smBulk');
  if(bulk){
    const parts=[];
    if(list.length&&!syncState.running)parts.push(`<button type="button" class="btn ghost" data-sm-bulk-sync>↻ ซิงก์ทั้งหมดในรายการนี้ (${list.length})</button>`);
    if(tab==='issue'){const okable=list.filter(x=>x.sync_status!=='blocked');if(okable.length)parts.push(`<button type="button" class="btn ghost" data-sm-bulk-ok>✔ ยืนยันว่าปกติทั้งกลุ่ม (${okable.length})</button>`)}
    bulk.innerHTML=parts.join('');
  }
  const host=$('syncQueuePreview');if(!host)return;
  if(!list.length){host.innerHTML=`<div class="sync-queue-empty">${tab==='issue'?'🎉 ไม่มีเรื่องที่ต้องตรวจสอบ':tab==='synced'?'ยังไม่มีเรื่องที่ซิงก์แล้วในช่วงเวลานี้':'✅ ไม่มีเรื่องถึงคิวซิงก์'}<br><small>${tab==='synced'?'ลองเพิ่มชั่วโมงที่ถือว่าซิงก์แล้ว':'ปรับขอบเขตหรือเว็บต้นทางด้านล่างได้'}</small></div>`;return}
  const limit=Math.max(smState.limit||0,smPageSize());
  const shown=list.slice(0,limit);
  let html='';
  if(smGroupHost()){
    const groups=new Map();shown.forEach(x=>{const h=sourceHost(x.source_url)||'ไม่ทราบเว็บ';if(!groups.has(h))groups.set(h,[]);groups.get(h).push(x)});
    html=[...groups.entries()].map(([h,arr])=>`<div class="sm-group"><div class="sm-group-head"><b>${esc(h)}</b><span>${arr.length}</span></div>${arr.map(x=>smRowHTML(x,tab)).join('')}</div>`).join('');
  }else html=shown.map(x=>smRowHTML(x,tab)).join('');
  if(list.length>shown.length)html+=`<button type="button" class="btn ghost sm-more" data-sm-more>แสดงเพิ่ม (อีก ${list.length-shown.length} เรื่อง)</button>`;
  host.innerHTML=html;
}
function smGoTab(tab,scroll){smState.tab=tab;smState.cat='all';smState.limit=0;try{localStorage.setItem(SM_KEYS.tab,tab)}catch{}renderSyncManage();if(scroll)$('syncManage')?.scrollIntoView({behavior:'smooth',block:'start'})}
function smCurrentList(){
  const B=smBuckets();let list=B[smState.tab]||[];
  if(smState.tab==='issue'&&smState.cat!=='all')list=list.filter(x=>x.sync_status===smState.cat);
  const q=smState.q.trim().toLowerCase();if(q)list=list.filter(x=>`${x.title||''} ${x.alt_title||''} ${sourceHost(x.source_url)||''}`.toLowerCase().includes(q));
  return list;
}
async function smMarkOk(ids){
  try{const r=await api('mark_sync_ok',{ids});await refreshAll();showToast(`ยืนยันว่าปกติแล้ว ${Number(r.updated||0)} เรื่อง`)}
  catch(e){showToast(e.message||'บันทึกไม่สำเร็จ',true)}
}
(function setupSyncManage(){
  const box=document.getElementById('syncManage');if(!box)return;
  box.addEventListener('click',async e=>{
    const t=e.target.closest('[data-sm-tab],[data-sm-cat],[data-sm-sync],[data-sm-import],[data-sm-ok],[data-sm-more],[data-sm-bulk-sync],[data-sm-bulk-ok]');if(!t)return;
    if(t.dataset.smTab){smGoTab(t.dataset.smTab,false);return}
    if(t.dataset.smCat){smState.cat=t.dataset.smCat;smState.limit=0;renderSyncManage();return}
    if(t.hasAttribute('data-sm-more')){smState.limit=Math.max(smState.limit||0,smPageSize())+smPageSize();renderSyncManage();return}
    if(t.dataset.smSync){
      if(syncState.running){showToast('กำลังซิงก์แบบชุดอยู่ กรุณารอให้จบหรือหยุดก่อน',true);return}
      t.disabled=true;const old=t.textContent;t.textContent='กำลังซิงก์…';
      try{await syncOne(Number(t.dataset.smSync))}finally{t.disabled=false;t.textContent=old}return}
    if(t.dataset.smImport){const x=state.items.find(v=>Number(v.id)===Number(t.dataset.smImport));if(x)openBrowserImport(Number(x.id),x.source_url);return}
    if(t.dataset.smOk){await smMarkOk([Number(t.dataset.smOk)]);return}
    if(t.hasAttribute('data-sm-bulk-ok')){const ids=smCurrentList().filter(x=>x.sync_status!=='blocked').map(x=>Number(x.id));if(!ids.length)return;if(!confirm(`ยืนยันว่า ${ids.length} เรื่องนี้ปกติ?\nระบบจะล้างสถานะ ⚠ (ไม่แก้ไขตอนหรือความคืบหน้าการอ่าน)`))return;await smMarkOk(ids);return}
    if(t.hasAttribute('data-sm-bulk-sync')){if(syncState.running){showToast('กำลังซิงก์แบบชุดอยู่',true);return}const ids=new Set(smCurrentList().map(x=>Number(x.id)));if(!ids.size)return;startBulkSync(false,{ids});return}
  });
  const on=(id,ev,fn)=>{const el=document.getElementById(id);if(el)el.addEventListener(ev,fn)};
  on('smSearch','input',e=>{smState.q=e.target.value;smState.limit=0;renderSyncManage()});
  on('smSort','change',e=>{localStorage.setItem(SM_KEYS.sort,e.target.value);renderSyncManage()});
  on('smDoneHours','change',e=>{const v=Math.max(0,Number(e.target.value||6));setSyncCfg('manga_sync_cooldown_hours',v);renderSyncPanel()});
  on('smUnvOk','change',e=>{localStorage.setItem(SM_KEYS.unv,e.target.checked?'1':'0');renderSyncPanel()});
  on('smGroupHost','change',e=>{localStorage.setItem(SM_KEYS.group,e.target.checked?'1':'0');renderSyncManage()});
  on('smPageSize','change',e=>{localStorage.setItem(SM_KEYS.page,e.target.value);smState.limit=0;renderSyncManage()});
  on('smReset','click',()=>{Object.values(SM_KEYS).forEach(k=>localStorage.removeItem(k));setSyncCfg('manga_sync_cooldown_hours',6);smState.tab='due';smState.cat='all';smState.limit=0;renderSyncPanel();showToast('คืนค่าการแยกเรื่องเป็นค่าเริ่มต้นแล้ว')});
  document.querySelectorAll('[data-sm-go]').forEach(c=>{const go=()=>smGoTab(c.dataset.smGo,true);c.addEventListener('click',go);c.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}})});
})();

// v17.17.11 — แผงเปอร์เซ็นต์ตอนซิงก์ (ใช้แผงเดียวกับตอนเพิ่มเรื่อง)
// ขั้นตอนจริง: เริ่ม → อ่านเว็บต้นทาง → ตรวจรายการ → บันทึก → เสร็จ  ช่วงรอเว็บตอบจะค่อยๆ ไต่เปอร์เซ็นต์ให้เห็นว่ายังทำงานอยู่
function mmtSyncProgress(title,subtitle){
 let pct=0,timer=0,label='',stage=title,name=subtitle||'',sub='';const detail=()=>name?(sub?`${name} · ${sub}`:name):sub;
 const paint=(state='downloading',extra={})=>setBackgroundImportPanel({state,progress:pct,title:stage,detail:detail(),percentLabel:`${Math.round(pct)}% · ${label}`,...extra});
 const stop=()=>{if(timer){clearInterval(timer);timer=0}};
 return {
  step(p,t,l,d){stop();pct=Math.max(pct,p);if(t)stage=t;if(l)label=l;if(d!==undefined)sub=d;paint()},
  creep(to,t,l,d){stop();if(t)stage=t;if(l)label=l;if(d!==undefined)sub=d;paint();timer=setInterval(()=>{pct+=(to-pct)*.09;paint()},450)},
  done(state,t,d,extra){stop();pct=100;stage=t;if(d!==undefined)sub=d;label=state==='success'?'เสร็จแล้ว':state==='error'?'ไม่สำเร็จ':'เสร็จแล้ว · ควรตรวจสอบ';paint(state,extra||{})},
  hide(){stop();hideBackgroundImportPanel(true)}
 };
}
function mmtSyncResultState(status){return ['partial','unverifiable','review'].includes(status)?'partial':'success'}
