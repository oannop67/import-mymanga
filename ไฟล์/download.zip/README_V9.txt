MyManga Tracker PRO V10.1

Highlights
- Server importer remains available for normal public HTML pages.
- When server import receives 403/429 or cannot fetch a site, Browser Import becomes the fallback.
- Universal Chrome extension can inspect any HTTP/HTTPS page that the user's browser can open.
- Auto-import link uses #mymanga_import=<ID>; the fragment is removed after import.
- Browser extraction reads title, OG/Twitter image, lazy-loaded images, chapter links/buttons, and SPA-rendered content after a short delay.
- Source chapter links are opened with referrerpolicy=no-referrer to reduce hotlink/referrer blocks.
- Do NOT replace your existing InfinityFree api/config.php with the local config in this zip. Keep your hosting DB credentials/token there.

V10.1.1 patch: online API defaults restored; Browser Import button added to the add/edit UI.
